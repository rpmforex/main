-- Add password-reset token fields to Affiliate
-- NOTE: this repo's migrations dir is stale relative to the live DB
-- (the Affiliate table itself was created via `prisma db push`, not a migration).
-- Apply this change with `prisma db push` (preferred, matches existing workflow)
-- or run this SQL manually. Do NOT run `prisma migrate deploy` blindly — it will
-- attempt to replay the init migration against a DB that already has these tables.

-- AlterTable
ALTER TABLE "Affiliate" ADD COLUMN "resetToken" TEXT,
ADD COLUMN "resetTokenExpiry" TIMESTAMP(3);

-- CreateIndex
CREATE UNIQUE INDEX "Affiliate_resetToken_key" ON "Affiliate"("resetToken");
