-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "stripeReceiptUrl" TEXT;
