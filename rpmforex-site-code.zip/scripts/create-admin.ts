import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";
import bcrypt from "bcryptjs";

function createPrismaClient() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error("DATABASE_URL is not set");
  }
  const pool = new Pool({ connectionString, ssl: { rejectUnauthorized: false } });
  const adapter = new PrismaPg(pool);
  return new PrismaClient({ adapter });
}

const prisma = createPrismaClient();

async function main() {
  const email = process.argv[2];
  const password = process.argv[3];
  const name = process.argv[4] || "Admin";

  if (!email || !password) {
    console.error("Usage: npx tsx scripts/create-admin.ts <email> <password> [name]");
    console.error("Example: npx tsx scripts/create-admin.ts admin@rpmforex.com mypassword Admin");
    process.exit(1);
  }

  const hashedPassword = await bcrypt.hash(password, 12);

  try {
    const user = await prisma.adminUser.upsert({
      where: { email: email.toLowerCase() },
      update: {
        password: hashedPassword,
        name,
      },
      create: {
        email: email.toLowerCase(),
        password: hashedPassword,
        name,
      },
    });

    console.log(`✓ Admin user created/updated successfully!`);
    console.log(`  Email: ${user.email}`);
    console.log(`  Name: ${user.name}`);
    console.log(`\nYou can now login at /admin/login`);
  } catch (error) {
    console.error("Error creating admin user:", error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();
