export type RateLimitOptions = {
  windowMs: number;
  max: number;
};

export type RateLimitResult = {
  ok: boolean;
  limit: number;
  remaining: number;
  reset: number; // unix ms
  retryAfterSeconds: number;
};

type Bucket = { count: number; reset: number };

const UPSTASH_EVAL_RATE_LIMIT_SCRIPT = `
local current = redis.call("GET", KEYS[1])
if not current then
  redis.call("SET", KEYS[1], 1, "PX", ARGV[1])
  return {1, tonumber(ARGV[1])}
end
local count = redis.call("INCR", KEYS[1])
local ttl = redis.call("PTTL", KEYS[1])
return {count, ttl}
`.trim();

function getBucketStore(): Map<string, Bucket> {
  const globalForRateLimit = globalThis as unknown as {
    __rpm_rate_limit_store?: Map<string, Bucket>;
  };

  if (!globalForRateLimit.__rpm_rate_limit_store) {
    globalForRateLimit.__rpm_rate_limit_store = new Map<string, Bucket>();
  }

  return globalForRateLimit.__rpm_rate_limit_store;
}

export function getClientIp(headers: Headers): string {
  const forwardedFor = headers.get("x-forwarded-for");
  if (forwardedFor) return forwardedFor.split(",")[0]?.trim() || "unknown";

  const realIp = headers.get("x-real-ip");
  if (realIp) return realIp;

  return "unknown";
}

function checkRateLimitLocal(key: string, options: RateLimitOptions): RateLimitResult {
  const store = getBucketStore();
  const now = Date.now();

  const existing = store.get(key);
  if (!existing || existing.reset <= now) {
    const reset = now + options.windowMs;
    store.set(key, { count: 1, reset });
    return {
      ok: true,
      limit: options.max,
      remaining: Math.max(0, options.max - 1),
      reset,
      retryAfterSeconds: 0,
    };
  }

  if (existing.count >= options.max) {
    return {
      ok: false,
      limit: options.max,
      remaining: 0,
      reset: existing.reset,
      retryAfterSeconds: Math.max(0, Math.ceil((existing.reset - now) / 1000)),
    };
  }

  existing.count += 1;
  store.set(key, existing);

  return {
    ok: true,
    limit: options.max,
    remaining: Math.max(0, options.max - existing.count),
    reset: existing.reset,
    retryAfterSeconds: 0,
  };
}

async function checkRateLimitUpstash(key: string, options: RateLimitOptions): Promise<RateLimitResult | null> {
  const url = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
  if (!url || !token) return null;

  const now = Date.now();

  try {
    const response = await fetch(`${url}/pipeline`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify([
        ["EVAL", UPSTASH_EVAL_RATE_LIMIT_SCRIPT, "1", key, String(options.windowMs)],
      ]),
      cache: "no-store",
    });

    if (!response.ok) return null;

    const json = (await response.json()) as unknown;
    const first =
      Array.isArray(json) && json.length > 0
        ? (json[0] as { result?: unknown })
        : null;
    const result = first && "result" in first ? (first as { result?: unknown }).result : null;

    if (!Array.isArray(result) || result.length < 2) return null;

    const count = Number(result[0]);
    const ttl = Number(result[1]);
    if (!Number.isFinite(count) || !Number.isFinite(ttl)) return null;

    const reset = now + Math.max(0, ttl);
    const remaining = Math.max(0, options.max - count);
    const ok = count <= options.max;

    return {
      ok,
      limit: options.max,
      remaining: ok ? remaining : 0,
      reset,
      retryAfterSeconds: ok ? 0 : Math.max(0, Math.ceil((reset - now) / 1000)),
    };
  } catch {
    return null;
  }
}

export async function checkRateLimit(key: string, options: RateLimitOptions): Promise<RateLimitResult> {
  const upstashResult = await checkRateLimitUpstash(key, options);
  if (upstashResult) return upstashResult;
  return checkRateLimitLocal(key, options);
}

export function rateLimitHeaders(result: RateLimitResult): Headers {
  const headers = new Headers();
  headers.set("RateLimit-Limit", String(result.limit));
  headers.set("RateLimit-Remaining", String(result.remaining));
  headers.set("RateLimit-Reset", String(Math.ceil(result.reset / 1000)));

  if (!result.ok) {
    headers.set("Retry-After", String(result.retryAfterSeconds));
  }

  return headers;
}
