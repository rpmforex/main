import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

function createPrismaClient() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error("DATABASE_URL is not set");
  }

  // Neon requires rejectUnauthorized: false due to their custom certificate chain
  // This is their recommended configuration - see: https://neon.tech/docs/guides/prisma
  // Local dev/build against a non-SSL Postgres: add ?sslmode=disable to DATABASE_URL
  const ssl = connectionString.includes("sslmode=disable")
    ? undefined
    : { rejectUnauthorized: false };
  const pool = new Pool({ connectionString, ssl });
  const adapter = new PrismaPg(pool);
  return new PrismaClient({ adapter });
}

export const prisma = globalForPrisma.prisma ?? createPrismaClient();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
