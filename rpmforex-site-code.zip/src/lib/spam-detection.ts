import { parsePhoneNumberFromString, CountryCode } from "libphonenumber-js";

// Disposable email domains (common ones)
const DISPOSABLE_DOMAINS = new Set([
  "tempmail.com", "temp-mail.org", "guerrillamail.com", "guerrillamail.org",
  "sharklasers.com", "grr.la", "guerrillamail.biz", "guerrillamail.de",
  "guerrillamail.net", "mailinator.com", "maildrop.cc", "10minutemail.com",
  "10minutemail.net", "throwaway.email", "fakeinbox.com", "trashmail.com",
  "mailnesia.com", "tempinbox.com", "dispostable.com", "yopmail.com",
  "yopmail.fr", "cool.fr.nf", "jetable.fr.nf", "nospam.ze.tc", "nomail.xl.cx",
  "mega.zik.dj", "speed.1s.fr", "courriel.fr.nf", "moncourrier.fr.nf",
  "monemail.fr.nf", "monmail.fr.nf", "getnada.com", "getairmail.com",
  "mohmal.com", "tempail.com", "tempr.email", "discard.email", "discardmail.com",
  "spamgourmet.com", "mytrashmail.com", "mailexpire.com", "throwawaymail.com",
  "mintemail.com", "emailondeck.com", "anonymbox.com", "33mail.com",
  "spam4.me", "wegwerfmail.de", "wegwerfmail.net", "wegwerfmail.org",
  "trashmail.net", "trashmail.org", "trashmail.ws", "trash-mail.at",
  "mailcatch.com", "mail-temp.com", "tempsky.com", "inbox.ru", "mail.ru",
]);

// Spam keywords commonly found in spam messages
const SPAM_KEYWORDS = [
  "viagra", "cialis", "casino", "lottery", "winner", "prize",
  "nigerian prince", "inheritance", "million dollars", "bank transfer",
  "click here", "act now", "limited time", "free money", "make money fast",
  "work from home", "earn extra", "crypto investment", "bitcoin profit",
  "forex signal", "guaranteed return", "double your", "risk free",
  "no obligation", "apply now", "order now", "buy now", "special promotion",
  "incredible deal", "once in a lifetime", "congratulations", "you have been selected",
  "dear friend", "dear sir", "dear madam", "urgent response", "urgent reply",
  "webcam", "adult", "xxx", "porn", "sex", "nude",
  "weight loss", "lose weight", "diet pill", "miracle cure",
  "seo services", "web traffic", "backlinks", "ranking",
];

// Suspicious patterns
const SUSPICIOUS_PATTERNS = [
  /(.)\1{4,}/,                    // Same character repeated 5+ times
  /[A-Z]{10,}/,                   // 10+ uppercase letters in a row
  /\d{15,}/,                      // 15+ digits in a row
  /https?:\/\/[^\s]+/gi,          // URLs (we'll count these)
  /[\u0400-\u04FF]{5,}/,          // Cyrillic text (potential spam)
  /[\u4E00-\u9FFF]{5,}/,          // Chinese characters (if not expected)
  /[!?]{3,}/,                     // Multiple exclamation/question marks
  /\$\d+[,.]?\d*[kmb]?/gi,        // Money amounts ($1000, $1M, etc.)
];

interface ValidationResult {
  valid: boolean;
  error?: string;
  warnings?: string[];
}

interface SpamCheckResult {
  isSpam: boolean;
  score: number;
  reasons: string[];
}

/**
 * Validate email address
 */
export function validateEmail(email: string): ValidationResult {
  if (!email || typeof email !== "string") {
    return { valid: false, error: "Email is required" };
  }

  const trimmed = email.trim().toLowerCase();

  // Basic format check
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(trimmed)) {
    return { valid: false, error: "Please enter a valid email address" };
  }

  // Extract domain
  const domain = trimmed.split("@")[1];

  // Check for disposable email domains
  if (DISPOSABLE_DOMAINS.has(domain)) {
    return { valid: false, error: "Please use a permanent email address, not a disposable one" };
  }

  // Check for suspicious TLDs often used by spammers
  const suspiciousTLDs = [".xyz", ".top", ".click", ".link", ".gq", ".ml", ".cf", ".tk", ".ga"];
  if (suspiciousTLDs.some(tld => domain.endsWith(tld))) {
    return { valid: false, error: "Please use a valid email address from a trusted provider" };
  }

  // Check for obviously fake patterns. info@ / admin@ are NOT here: they are
  // ordinary business mailboxes and blocking them turned away real enquiries.
  if (/^(test|fake|spam|asdf|qwerty|1234|noreply)@/.test(trimmed)) {
    return { valid: false, error: "Please enter your real email address" };
  }

  // Check for keyboard mashing
  if (/^[asdfghjkl]+@|^[qwertyuiop]+@|^[zxcvbnm]+@/i.test(trimmed)) {
    return { valid: false, error: "Please enter a valid email address" };
  }

  return { valid: true };
}

/**
 * Validate phone number
 */
export function validatePhone(phone: string | undefined | null, countryCode: CountryCode = "GB"): ValidationResult {
  if (!phone || phone.trim() === "") {
    // Phone is optional, so empty is valid
    return { valid: true };
  }

  const trimmed = phone.trim();

  // Check minimum length
  if (trimmed.length < 7) {
    return { valid: false, error: "Phone number is too short" };
  }

  // Check for obviously fake numbers
  if (/^(\d)\1+$/.test(trimmed.replace(/\D/g, ""))) {
    return { valid: false, error: "Please enter a valid phone number" };
  }

  // Try to parse and validate with libphonenumber
  try {
    // Try with explicit country code first
    let phoneNumber = parsePhoneNumberFromString(trimmed, countryCode);

    // If that fails, try without country code (number might include it)
    if (!phoneNumber) {
      phoneNumber = parsePhoneNumberFromString(trimmed);
    }

    if (!phoneNumber) {
      return { valid: false, error: "Please enter a valid phone number" };
    }

    if (!phoneNumber.isValid()) {
      return { valid: false, error: "Please enter a valid phone number" };
    }

    // Check it's a possible number type (mobile or fixed-line)
    const type = phoneNumber.getType();
    if (type && !["MOBILE", "FIXED_LINE", "FIXED_LINE_OR_MOBILE", "PERSONAL_NUMBER", "VOIP"].includes(type)) {
      return { valid: false, error: "Please enter a valid contact phone number" };
    }

    return { valid: true };
  } catch {
    // If libphonenumber fails, do basic validation
    const digitsOnly = trimmed.replace(/\D/g, "");
    if (digitsOnly.length < 10 || digitsOnly.length > 15) {
      return { valid: false, error: "Please enter a valid phone number" };
    }
    return { valid: true };
  }
}

/**
 * Check text content for spam indicators
 */
export function checkForSpam(text: string, fieldName = "message"): SpamCheckResult {
  if (!text || typeof text !== "string") {
    return { isSpam: false, score: 0, reasons: [] };
  }

  const reasons: string[] = [];
  let score = 0;
  const lowerText = text.toLowerCase();

  // Check for spam keywords
  const foundKeywords = SPAM_KEYWORDS.filter(keyword => lowerText.includes(keyword));
  if (foundKeywords.length > 0) {
    score += foundKeywords.length * 15;
    reasons.push(`Contains spam keywords: ${foundKeywords.slice(0, 3).join(", ")}`);
  }

  // Count URLs
  const urlMatches = text.match(/https?:\/\/[^\s]+/gi) || [];
  if (urlMatches.length > 2) {
    score += 30;
    reasons.push("Contains too many URLs");
  } else if (urlMatches.length > 0) {
    score += urlMatches.length * 10;
  }

  // Check for excessive uppercase
  const uppercaseRatio = (text.match(/[A-Z]/g) || []).length / text.length;
  if (uppercaseRatio > 0.5 && text.length > 20) {
    score += 20;
    reasons.push("Excessive use of capital letters");
  }

  // Check suspicious patterns
  for (const pattern of SUSPICIOUS_PATTERNS) {
    if (pattern.test(text)) {
      score += 10;
    }
  }

  // Check for repeated characters (spammy)
  if (/(.)\1{4,}/.test(text)) {
    score += 15;
    reasons.push("Contains repeated characters");
  }

  // Check for very short messages with links (likely spam)
  if (text.length < 50 && urlMatches.length > 0) {
    score += 25;
    reasons.push("Short message with links");
  }

  // Check for email addresses in the message (harvesting protection)
  const emailsInText = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [];
  if (emailsInText.length > 1) {
    score += 20;
    reasons.push("Contains multiple email addresses");
  }

  // Check for gibberish (random character sequences) using our isGibberish function
  const words = text.split(/\s+/);
  const gibberishWords = words.filter(word => isGibberish(word));

  // If most of the message is gibberish, it's definitely spam
  const gibberishRatio = words.length > 0 ? gibberishWords.length / words.length : 0;
  if (gibberishRatio > 0.5) {
    score += 60; // High score - mostly gibberish
    reasons.push("Message appears to be gibberish");
  } else if (gibberishWords.length > 2) {
    score += 30;
    reasons.push("Contains gibberish text");
  } else if (gibberishWords.length > 0) {
    score += 15;
    reasons.push("Contains suspicious words");
  }

  // Check message length (too short might be spam)
  if (fieldName === "message" && text.trim().length < 10) {
    score += 10;
    reasons.push("Message too short");
  }

  return {
    isSpam: score >= 50,
    score,
    reasons,
  };
}

/**
 * Check if honeypot field was filled (bots fill hidden fields)
 */
export function checkHoneypot(value: string | undefined | null): boolean {
  // If honeypot has any value, it's likely a bot
  return !value || value.trim() === "";
}

/**
 * Check if a word looks like gibberish/keyboard mashing
 */
function isGibberish(word: string): boolean {
  if (word.length < 4) return false;

  const lowerWord = word.toLowerCase();

  // Keyboard row patterns (mashing)
  const keyboardRows = [
    /^[qwertyuiop]+$/,
    /^[asdfghjkl]+$/,
    /^[zxcvbnm]+$/,
  ];
  if (keyboardRows.some(row => row.test(lowerWord))) {
    return true;
  }

  // Check consonant clusters (no language has 4+ consonants in a row commonly)
  if (/[bcdfghjklmnpqrstvwxyz]{4,}/i.test(lowerWord)) {
    return true;
  }

  // Check vowel-to-consonant ratio
  const vowels = (lowerWord.match(/[aeiou]/g) || []).length;
  const consonants = (lowerWord.match(/[bcdfghjklmnpqrstvwxyz]/g) || []).length;

  // No vowels in a word longer than 4 chars is suspicious
  if (vowels === 0 && lowerWord.length > 4) {
    return true;
  }

  // Very low vowel ratio (less than 15% in words 6+ chars)
  if (lowerWord.length >= 6 && vowels / lowerWord.length < 0.15) {
    return true;
  }

  // Check for repeated patterns like "dfadfadfa"
  if (/(.{2,3})\1{2,}/.test(lowerWord)) {
    return true;
  }

  // Common gibberish patterns
  const gibberishPatterns = [
    /^[df]{2,}[as]+$/i,     // dfa, dfas, ddffa, etc
    /^[as]+[df]+$/i,        // asdf, aasdf, etc
    /^[fd]+[sa]+$/i,        // fdsa, ffdsa, etc
    /^[jk]+[l]+$/i,         // jkl patterns
    /^[asd]+f+$/i,          // asdf
  ];
  if (gibberishPatterns.some(p => p.test(lowerWord))) {
    return true;
  }

  return false;
}

/**
 * Validate name field
 */
export function validateName(name: string): ValidationResult {
  if (!name || typeof name !== "string") {
    return { valid: false, error: "Name is required" };
  }

  const trimmed = name.trim();

  if (trimmed.length < 2) {
    return { valid: false, error: "Name is too short" };
  }

  if (trimmed.length > 100) {
    return { valid: false, error: "Name is too long" };
  }

  // Check for numbers only
  if (/^\d+$/.test(trimmed)) {
    return { valid: false, error: "Please enter a valid name" };
  }

  // Check for obviously fake names
  if (/^(test|asdf|qwerty|1234|admin|user|name|fake)$/i.test(trimmed)) {
    return { valid: false, error: "Please enter your real name" };
  }

  // Check for repeated characters
  if (/^(.)\1+$/.test(trimmed)) {
    return { valid: false, error: "Please enter a valid name" };
  }

  // Should contain at least some letters
  if (!/[a-zA-Z]/.test(trimmed)) {
    return { valid: false, error: "Please enter a valid name" };
  }

  // Check each word for gibberish
  const words = trimmed.split(/\s+/);
  const gibberishWords = words.filter(w => isGibberish(w));
  if (gibberishWords.length > 0) {
    return { valid: false, error: "Please enter a valid name" };
  }

  // Names should have reasonable structure (at least one capital or be properly formatted)
  // Check if it looks like a real name (has vowels, reasonable length words)
  const allWords = trimmed.split(/\s+/);
  for (const word of allWords) {
    if (word.length > 3) {
      const vowelCount = (word.match(/[aeiouAEIOU]/g) || []).length;
      if (vowelCount === 0) {
        return { valid: false, error: "Please enter a valid name" };
      }
    }
  }

  return { valid: true };
}

/**
 * Full form validation
 */
export interface FormValidationInput {
  name: string;
  email: string;
  phone?: string;
  message?: string;
  honeypot?: string;
}

export interface FormValidationResult {
  valid: boolean;
  errors: Record<string, string>;
  isSpam: boolean;
  spamScore: number;
  spamReasons: string[];
}

export function validateForm(input: FormValidationInput): FormValidationResult {
  const errors: Record<string, string> = {};
  let isSpam = false;
  let totalSpamScore = 0;
  const allSpamReasons: string[] = [];

  // Check honeypot first
  if (!checkHoneypot(input.honeypot)) {
    isSpam = true;
    allSpamReasons.push("Bot detected (honeypot triggered)");
    return {
      valid: false,
      errors: { form: "Unable to process your submission" },
      isSpam: true,
      spamScore: 100,
      spamReasons: allSpamReasons,
    };
  }

  // Validate name
  const nameResult = validateName(input.name);
  if (!nameResult.valid && nameResult.error) {
    errors.name = nameResult.error;
  }

  // Check name for spam
  const nameSpam = checkForSpam(input.name, "name");
  totalSpamScore += nameSpam.score;
  allSpamReasons.push(...nameSpam.reasons);

  // Validate email
  const emailResult = validateEmail(input.email);
  if (!emailResult.valid && emailResult.error) {
    errors.email = emailResult.error;
  }

  // Validate phone
  const phoneResult = validatePhone(input.phone);
  if (!phoneResult.valid && phoneResult.error) {
    errors.phone = phoneResult.error;
  }

  // Check message for spam and gibberish
  if (input.message) {
    const messageSpam = checkForSpam(input.message, "message");
    totalSpamScore += messageSpam.score;
    allSpamReasons.push(...messageSpam.reasons);

    // If message is mostly gibberish, treat it as a validation error (not silent spam)
    // so the user gets feedback to fix their message
    if (messageSpam.reasons.some(r => r.includes("gibberish"))) {
      errors.message = "Please enter a valid message";
    }

    // Also check if message is too short to be meaningful
    if (input.message.trim().length < 10) {
      errors.message = "Please enter a more detailed message";
    }
  }

  // Determine if it's spam
  isSpam = totalSpamScore >= 50;

  return {
    valid: Object.keys(errors).length === 0 && !isSpam,
    errors,
    isSpam,
    spamScore: totalSpamScore,
    spamReasons: allSpamReasons,
  };
}
