import { cookies } from "next/headers";
import crypto from "crypto";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { prisma } from "./prisma";

function getJwtSecret(): string {
  const secret = process.env.AFFILIATE_JWT_SECRET || process.env.ADMIN_JWT_SECRET;
  if (!secret) {
    throw new Error("AFFILIATE_JWT_SECRET or ADMIN_JWT_SECRET environment variable must be set");
  }
  return secret;
}

interface AffiliateJWTPayload {
  affiliateId: string;
  email: string;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(
  password: string,
  hashedPassword: string
): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword);
}

export function generateAffiliateToken(payload: AffiliateJWTPayload): string {
  return jwt.sign(payload, getJwtSecret(), { expiresIn: "30d" });
}

export function verifyAffiliateToken(token: string): AffiliateJWTPayload | null {
  try {
    return jwt.verify(token, getJwtSecret()) as AffiliateJWTPayload;
  } catch {
    return null;
  }
}

export async function getAffiliateSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get("affiliate_token")?.value;

  if (!token) return null;

  const payload = verifyAffiliateToken(token);
  if (!payload) return null;

  const affiliate = await prisma.affiliate.findUnique({
    where: { id: payload.affiliateId },
    select: {
      id: true,
      email: true,
      name: true,
      referralCode: true,
      status: true,
      commissionRate: true,
      totalClicks: true,
      totalOrders: true,
      totalEarnings: true,
      pendingEarnings: true,
      paidEarnings: true,
    },
  });

  // Only return session if affiliate is approved
  if (!affiliate || affiliate.status !== "APPROVED") {
    return null;
  }

  return affiliate;
}

export function generateReferralCode(): string {
  // Generate a unique 8-character referral code
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export async function createAffiliate(
  email: string,
  password: string,
  name: string,
  paymentEmail?: string,
  paymentMethod?: string
) {
  const hashedPassword = await hashPassword(password);

  // Generate unique referral code
  let referralCode = generateReferralCode();
  let attempts = 0;

  // Make sure it's unique
  while (attempts < 10) {
    const existing = await prisma.affiliate.findUnique({
      where: { referralCode },
    });
    if (!existing) break;
    referralCode = generateReferralCode();
    attempts++;
  }

  return prisma.affiliate.create({
    data: {
      email,
      password: hashedPassword,
      name,
      referralCode,
      paymentEmail: paymentEmail || email,
      paymentMethod: paymentMethod || "paypal",
    },
  });
}

export async function authenticateAffiliate(email: string, password: string) {
  const affiliate = await prisma.affiliate.findUnique({
    where: { email },
  });

  if (!affiliate) {
    return { success: false, error: "Invalid email or password" };
  }

  const isValid = await verifyPassword(password, affiliate.password);
  if (!isValid) {
    return { success: false, error: "Invalid email or password" };
  }

  if (affiliate.status === "PENDING") {
    return { success: false, error: "Your application is still under review" };
  }

  if (affiliate.status === "REJECTED") {
    return { success: false, error: "Your application was not approved" };
  }

  if (affiliate.status === "SUSPENDED") {
    return { success: false, error: "Your account has been suspended" };
  }

  const token = generateAffiliateToken({
    affiliateId: affiliate.id,
    email: affiliate.email,
  });

  return {
    success: true,
    token,
    affiliate: {
      id: affiliate.id,
      email: affiliate.email,
      name: affiliate.name,
      referralCode: affiliate.referralCode,
    },
  };
}

// ============================================
// PASSWORD RESET
// ============================================

const RESET_TOKEN_TTL_MS = 60 * 60 * 1000; // 1 hour

/**
 * Generate and store a password reset token for the affiliate with this email.
 * Returns null if no affiliate exists (caller must NOT leak this to the client).
 */
export async function createPasswordResetToken(email: string) {
  const affiliate = await prisma.affiliate.findUnique({
    where: { email },
  });

  if (!affiliate) return null;

  const token = crypto.randomBytes(32).toString("hex");
  const expiry = new Date(Date.now() + RESET_TOKEN_TTL_MS);

  await prisma.affiliate.update({
    where: { id: affiliate.id },
    data: {
      resetToken: token,
      resetTokenExpiry: expiry,
    },
  });

  return {
    token,
    affiliate: {
      id: affiliate.id,
      email: affiliate.email,
      name: affiliate.name,
    },
  };
}

/**
 * Validate a reset token and set a new password.
 * Clears the token on success so it can only be used once.
 */
export async function resetPasswordWithToken(token: string, newPassword: string) {
  const affiliate = await prisma.affiliate.findUnique({
    where: { resetToken: token },
  });

  if (
    !affiliate ||
    !affiliate.resetTokenExpiry ||
    affiliate.resetTokenExpiry < new Date()
  ) {
    return {
      success: false,
      error: "This reset link is invalid or has expired. Please request a new one.",
    };
  }

  const hashedPassword = await hashPassword(newPassword);

  await prisma.affiliate.update({
    where: { id: affiliate.id },
    data: {
      password: hashedPassword,
      resetToken: null,
      resetTokenExpiry: null,
    },
  });

  return { success: true };
}
