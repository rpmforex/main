import { cookies } from "next/headers";
import { prisma } from "./prisma";

const AFFILIATE_COOKIE_NAME = "rpm_affiliate";
const COOKIE_DURATION_DAYS = 30;

/**
 * Get affiliate referral code from cookie
 */
export async function getAffiliateFromCookie(): Promise<string | null> {
  const cookieStore = await cookies();
  return cookieStore.get(AFFILIATE_COOKIE_NAME)?.value || null;
}

/**
 * Set affiliate cookie (called from middleware or client)
 * Returns cookie options for setting
 */
export function getAffiliateCookieOptions(referralCode: string) {
  const maxAge = COOKIE_DURATION_DAYS * 24 * 60 * 60; // 30 days in seconds

  return {
    name: AFFILIATE_COOKIE_NAME,
    value: referralCode,
    maxAge,
    path: "/",
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    httpOnly: true, // Server-side only, client JS doesn't need access
  };
}

/**
 * Track a referral click
 */
export async function trackReferralClick(
  referralCode: string,
  ipAddress?: string,
  userAgent?: string,
  landingPage?: string
) {
  // Find the affiliate
  const affiliate = await prisma.affiliate.findUnique({
    where: { referralCode },
  });

  if (!affiliate || affiliate.status !== "APPROVED") {
    return null;
  }

  // Check for duplicate click from same IP in last 24 hours
  const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

  if (ipAddress) {
    const existingClick = await prisma.referral.findFirst({
      where: {
        affiliateId: affiliate.id,
        ipAddress,
        createdAt: { gte: oneDayAgo },
      },
    });

    if (existingClick) {
      // Don't create duplicate, but return the affiliate info
      return { affiliate, duplicate: true };
    }
  }

  // Create referral record for click tracking
  await prisma.referral.create({
    data: {
      affiliateId: affiliate.id,
      ipAddress,
      userAgent,
      landingPage,
    },
  });

  // Increment affiliate's click count
  await prisma.affiliate.update({
    where: { id: affiliate.id },
    data: { totalClicks: { increment: 1 } },
  });

  return { affiliate, duplicate: false };
}

/**
 * Convert a referral (link order to affiliate)
 */
export async function convertReferral(
  orderId: string,
  orderAmount: number,
  referralCode: string
) {
  // Find the affiliate
  const affiliate = await prisma.affiliate.findUnique({
    where: { referralCode },
  });

  if (!affiliate || affiliate.status !== "APPROVED") {
    return null;
  }

  // Calculate commission
  const commissionRate = Number(affiliate.commissionRate);
  const commission = (orderAmount * commissionRate) / 100;

  // Find an unconverted referral to link (optional - creates new if none)
  let referral = await prisma.referral.findFirst({
    where: {
      affiliateId: affiliate.id,
      converted: false,
      orderId: null,
    },
    orderBy: { createdAt: "desc" },
  });

  if (referral) {
    // Update existing referral with conversion
    referral = await prisma.referral.update({
      where: { id: referral.id },
      data: {
        orderId,
        converted: true,
        commission,
        convertedAt: new Date(),
      },
    });
  } else {
    // Create new referral with conversion
    referral = await prisma.referral.create({
      data: {
        affiliateId: affiliate.id,
        orderId,
        converted: true,
        commission,
        convertedAt: new Date(),
      },
    });
  }

  // Update affiliate stats
  await prisma.affiliate.update({
    where: { id: affiliate.id },
    data: {
      totalOrders: { increment: 1 },
      totalEarnings: { increment: commission },
      pendingEarnings: { increment: commission },
    },
  });

  return {
    affiliate,
    referral,
    commission,
  };
}

/**
 * Get affiliate by referral code
 */
export async function getAffiliateByCode(referralCode: string) {
  return prisma.affiliate.findUnique({
    where: { referralCode },
    select: {
      id: true,
      name: true,
      email: true,
      referralCode: true,
      status: true,
      commissionRate: true,
    },
  });
}

/**
 * Reverse a referral conversion (for refunds)
 */
export async function reverseReferralConversion(orderId: string) {
  // Find the referral linked to this order
  const referral = await prisma.referral.findUnique({
    where: { orderId },
    include: { affiliate: true },
  });

  if (!referral || !referral.converted || !referral.commission) {
    return null;
  }

  const commission = Number(referral.commission);

  // Update referral to mark as not converted
  await prisma.referral.update({
    where: { id: referral.id },
    data: {
      converted: false,
      convertedAt: null,
      commission: null,
      orderId: null,
    },
  });

  // Reverse affiliate stats
  await prisma.affiliate.update({
    where: { id: referral.affiliateId },
    data: {
      totalOrders: { decrement: 1 },
      totalEarnings: { decrement: commission },
      pendingEarnings: { decrement: commission },
    },
  });

  return {
    affiliate: referral.affiliate,
    commission,
  };
}
