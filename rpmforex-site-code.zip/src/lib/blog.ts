import sanitizeHtml from "sanitize-html";
import { PrismaClient } from "@prisma/client";

export function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

export async function ensureUniqueSlug(
  prisma: PrismaClient,
  baseSlug: string,
  excludeId?: string
): Promise<string> {
  let slug = baseSlug;
  let counter = 1;

  while (true) {
    const existing = await prisma.blogPost.findUnique({
      where: { slug },
      select: { id: true },
    });

    if (!existing || existing.id === excludeId) return slug;

    counter++;
    slug = `${baseSlug}-${counter}`;
  }
}

export function calculateReadingTime(html: string): number {
  const text = html.replace(/<[^>]*>/g, "").trim();
  const wordCount = text.split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.ceil(wordCount / 200));
}

export function sanitizeContent(html: string): string {
  return sanitizeHtml(html, {
    allowedTags: [
      "h1", "h2", "h3", "h4", "h5", "h6",
      "p", "br", "hr",
      "strong", "em", "u", "s",
      "ul", "ol", "li",
      "blockquote",
      "a", "img",
      "pre", "code",
      "div", "span",
      "iframe", "video", "source",
    ],
    allowedAttributes: {
      a: ["href", "target", "rel"],
      img: ["src", "alt", "width", "height"],
      iframe: [
        "src", "width", "height", "frameborder", "allow",
        "allowfullscreen", "title", "loading", "referrerpolicy",
        "class", "style",
      ],
      video: ["src", "controls", "width", "height", "poster", "preload", "class"],
      source: ["src", "type"],
      "*": ["style"],
    },
    allowedIframeHostnames: ["www.youtube.com", "www.youtube-nocookie.com", "youtube.com", "youtube-nocookie.com"],
    allowedStyles: {
      "*": {
        "text-align": [/^left$/, /^right$/, /^center$/, /^justify$/],
      },
    },
    transformTags: {
      a: (_tagName: string, attribs: Record<string, string>) => ({
        tagName: "a",
        attribs: {
          ...attribs,
          target: "_blank",
          rel: "noopener noreferrer",
        },
      }),
    },
  });
}

export function generateExcerpt(html: string, maxLength: number = 160): string {
  const text = html.replace(/<[^>]*>/g, "").trim();
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength).replace(/\s+\S*$/, "") + "...";
}
