// Currency utilities. The site is single-currency USD: all stored/charged
// prices are USD-native and displayed in USD. (The GBP definitions and
// conversion helpers below are retained but unused by the live site.)

export type CurrencyCode = "GBP" | "USD";

export interface Currency {
  code: CurrencyCode;
  symbol: string;
  name: string;
  flag: string; // Emoji flag
  locale: string; // For number formatting
}

export const SUPPORTED_CURRENCIES: Record<CurrencyCode, Currency> = {
  GBP: {
    code: "GBP",
    symbol: "£",
    name: "British Pound",
    flag: "🇬🇧",
    locale: "en-GB",
  },
  USD: {
    code: "USD",
    symbol: "$",
    name: "US Dollar",
    flag: "🇺🇸",
    locale: "en-US",
  },
};

// Map country codes to currencies (based on Vercel geolocation header)
export const COUNTRY_TO_CURRENCY: Record<string, CurrencyCode> = {
  GB: "GBP",
  US: "USD",
};

// Default/only display currency for the site
export const DEFAULT_CURRENCY: CurrencyCode = "USD";

// Fallback rate if the exchange-rate API is unreachable
const FALLBACK_RATES: Record<string, number> = {
  GBP: 1,
  USD: 1.27,
};

/**
 * Get currency code from country code
 */
export function getCurrencyFromCountry(
  countryCode: string | undefined
): CurrencyCode {
  if (!countryCode) return DEFAULT_CURRENCY;
  return COUNTRY_TO_CURRENCY[countryCode.toUpperCase()] || DEFAULT_CURRENCY;
}

/**
 * Format a price in the given currency
 */
export function formatPrice(
  amount: number,
  currency: CurrencyCode = DEFAULT_CURRENCY
): string {
  const currencyInfo =
    SUPPORTED_CURRENCIES[currency] || SUPPORTED_CURRENCIES[DEFAULT_CURRENCY];

  return new Intl.NumberFormat(currencyInfo.locale, {
    style: "currency",
    currency: currencyInfo.code,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * Convert a GBP amount to the target currency using the given rates
 */
export function convertFromGbp(
  gbpAmount: number,
  currency: CurrencyCode,
  rates: Record<string, number>
): number {
  if (currency === "GBP") return gbpAmount;
  const rate = rates[currency] || FALLBACK_RATES[currency] || 1;
  return gbpAmount * rate;
}

/**
 * Fetch live exchange rates with GBP base, cached for 24 hours by Next.js.
 * Same source as OpsCon: ExchangeRate-API free endpoint.
 */
export async function getExchangeRates(): Promise<Record<string, number>> {
  try {
    const response = await fetch(
      "https://api.exchangerate-api.com/v4/latest/GBP",
      { next: { revalidate: 86400 } } // Cache for 24 hours
    );

    if (!response.ok) {
      throw new Error(`Exchange rate API returned ${response.status}`);
    }

    const data = await response.json();
    const usd = Number(data?.rates?.USD);

    return {
      GBP: 1,
      USD: Number.isFinite(usd) && usd > 0 ? usd : FALLBACK_RATES.USD,
    };
  } catch (error) {
    console.error("Failed to fetch exchange rates:", error);
    return { ...FALLBACK_RATES };
  }
}
