/**
 * RPM Forex Email Templates
 * Consistent, branded email templates for all notifications
 */

// Brand colors
const COLORS = {
  navy: "#0a1628",
  navyLight: "#122240",
  navyBorder: "#1a2d4a",
  gold: "#d4a84b",
  white: "#ffffff",
  gray: "#94a3b8",
  green: "#22c55e",
  red: "#ef4444",
  yellow: "#eab308",
};

// HTML escape function to prevent XSS in emails
function escapeHtml(unsafe: string | null | undefined): string {
  if (!unsafe) return "";
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function sanitizeHref(href: string): string {
  if (href.startsWith("mailto:")) return href;

  try {
    const url = new URL(href);
    if (url.protocol === "https:" || url.protocol === "http:") return url.toString();
  } catch {
    // ignore
  }

  return "https://rpmforex.com";
}

// Base email wrapper
function baseTemplate(content: string): string {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RPM Forex</title>
</head>
<body style="margin: 0; padding: 0; background-color: ${COLORS.navy}; font-family: Arial, sans-serif;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: ${COLORS.navy};">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="max-width: 600px; width: 100%;">
          <!-- Header -->
          <tr>
            <td align="center" style="padding-bottom: 30px;">
              <h1 style="margin: 0; color: ${COLORS.gold}; font-size: 28px; font-weight: bold;">RPM Forex</h1>
            </td>
          </tr>
          <!-- Content -->
          <tr>
            <td style="background-color: ${COLORS.navyLight}; border-radius: 12px; padding: 40px;">
              ${content}
            </td>
          </tr>
          <!-- Footer -->
          <tr>
            <td style="padding-top: 30px; text-align: center;">
              <p style="margin: 0 0 10px 0; color: ${COLORS.gray}; font-size: 14px;">
                Questions? Contact us at <a href="mailto:info@rpmforex.com" style="color: ${COLORS.gold}; text-decoration: none;">info@rpmforex.com</a>
              </p>
              <p style="margin: 0; color: ${COLORS.gray}; font-size: 12px;">
                &copy; ${new Date().getFullYear()} RPM Forex. All rights reserved.
              </p>
              <p style="margin: 10px 0 0 0; color: ${COLORS.gray}; font-size: 10px; max-width: 500px;">
                Trading Derivatives carries a high level of risk. Only trade with money you can afford to lose.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}

// Helper: Info box
function infoBox(content: string): string {
  return `
    <div style="background-color: ${COLORS.navy}; border-radius: 8px; padding: 20px; margin: 20px 0;">
      ${content}
    </div>
  `;
}

// Helper: Button
function button(text: string, href: string, color: string = COLORS.gold): string {
  const textColor = color === COLORS.gold ? COLORS.navy : COLORS.white;
  return `
    <table role="presentation" cellspacing="0" cellpadding="0" style="margin: 20px 0;">
      <tr>
        <td style="background-color: ${color}; border-radius: 8px;">
          <a href="${escapeHtml(sanitizeHref(href))}" style="display: inline-block; padding: 14px 28px; color: ${textColor}; text-decoration: none; font-weight: bold; font-size: 16px;">
            ${escapeHtml(text)}
          </a>
        </td>
      </tr>
    </table>
  `;
}

// Helper: Status badge
function badge(text: string, color: string): string {
  return `<span style="display: inline-block; background-color: ${color}20; color: ${color}; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold;">${text}</span>`;
}

// ============================================
// CUSTOMER EMAILS
// ============================================

interface OrderEmailData {
  orderRef: string;
  customerName: string;
  email: string;
  phone?: string | null;
  product: string;
  option: string;
  price: number;
  paidAmount?: number | null;
  discountCode?: string | null;
  discountAmount?: number | null;
  paymentMethod: "stripe" | "bitcoin";
  receiptUrl?: string | null;
  affiliateCode?: string | null;
}

/**
 * Order Confirmation - Sent when order is placed
 */
export function orderConfirmationEmail(data: OrderEmailData): string {
  const isBitcoin = data.paymentMethod === "bitcoin";
  const BITCOIN_ADDRESS = "1C6hG3zmipqzQmDpbioWCTHLabheL3EZGY";

  const content = `
    <h2 style="margin: 0 0 10px 0; color: ${COLORS.white}; font-size: 24px;">Order Confirmed!</h2>
    <p style="margin: 0 0 20px 0; color: ${COLORS.gray};">
      Thank you for your order, ${escapeHtml(data.customerName)}. ${isBitcoin ? "Please complete payment below." : "You'll be redirected to complete payment."}
    </p>

    ${infoBox(`
      <p style="margin: 0 0 8px 0; color: ${COLORS.gray};"><strong style="color: ${COLORS.gold};">Order Reference:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.orderRef)}</span></p>
      <p style="margin: 0; color: ${COLORS.gray};"><strong style="color: ${COLORS.gold};">Date:</strong> <span style="color: ${COLORS.white};">${new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}</span></p>
    `)}

    <h3 style="margin: 20px 0 15px 0; color: ${COLORS.white}; font-size: 18px;">Order Summary</h3>
    ${infoBox(`
      <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
        <tr>
          <td style="padding: 8px 0; color: ${COLORS.gray};">Product</td>
          <td style="padding: 8px 0; text-align: right; color: ${COLORS.white};">${escapeHtml(data.product)}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: ${COLORS.gray};">Option</td>
          <td style="padding: 8px 0; text-align: right; color: ${COLORS.white};">${escapeHtml(data.option)}</td>
        </tr>
        ${data.discountCode ? `
        <tr>
          <td style="padding: 8px 0; color: ${COLORS.gray};">Subtotal</td>
          <td style="padding: 8px 0; text-align: right; color: ${COLORS.gray}; text-decoration: line-through;">$${data.price.toFixed(2)}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: ${COLORS.green};">Discount (${escapeHtml(data.discountCode)})</td>
          <td style="padding: 8px 0; text-align: right; color: ${COLORS.green};">-$${(data.discountAmount ?? 0).toFixed(2)}</td>
        </tr>
        ` : ""}
        <tr style="border-top: 1px solid ${COLORS.navyBorder};">
          <td style="padding: 16px 0 0 0; color: ${COLORS.gray}; font-weight: bold;">Total</td>
          <td style="padding: 16px 0 0 0; text-align: right; color: ${COLORS.gold}; font-size: 24px; font-weight: bold;">$${(data.paidAmount ?? data.price).toFixed(2)}</td>
        </tr>
      </table>
    `)}

    ${isBitcoin ? `
      <div style="background: linear-gradient(135deg, ${COLORS.gold}20, ${COLORS.gold}10); border: 1px solid ${COLORS.gold}40; padding: 24px; border-radius: 8px; margin: 20px 0;">
        <h3 style="color: ${COLORS.gold}; margin: 0 0 16px 0; font-size: 18px;">₿ Pay with Bitcoin</h3>
        <p style="color: ${COLORS.gray}; margin: 0 0 16px 0; font-size: 14px;">Send exactly <strong style="color: ${COLORS.white};">$${(data.paidAmount ?? data.price).toFixed(2)}</strong> worth of Bitcoin to:</p>
        <div style="background: ${COLORS.navy}; padding: 16px; border-radius: 8px; margin-bottom: 16px;">
          <p style="margin: 0; font-family: monospace; color: ${COLORS.white}; word-break: break-all; font-size: 14px;">${BITCOIN_ADDRESS}</p>
        </div>
        <p style="color: ${COLORS.gray}; margin: 0; font-size: 12px;">Once payment is confirmed, you'll receive your Bot file and licence key within 24 hours.</p>
      </div>
    ` : `
      <p style="color: ${COLORS.gray}; margin: 20px 0;">
        Your payment is being processed. You'll receive a confirmation email once complete.
      </p>
    `}

    <p style="color: ${COLORS.gray}; font-size: 14px; margin-top: 20px;">
      <strong style="color: ${COLORS.white};">What happens next?</strong><br>
      Once payment is confirmed, you'll receive your RPM Forex Gold Bot file and unique licence key via email within 24 hours.
    </p>
  `;

  return baseTemplate(content);
}

/**
 * Payment Confirmed - Sent when payment is verified
 */
export function paymentConfirmedEmail(data: OrderEmailData): string {
  const content = `
    <div style="text-align: center; margin-bottom: 20px;">
      <div style="display: inline-block; background: ${COLORS.green}20; padding: 16px; border-radius: 50%;">
        <span style="font-size: 40px;">✓</span>
      </div>
    </div>

    <h2 style="margin: 0 0 10px 0; color: ${COLORS.white}; font-size: 24px; text-align: center;">Payment Successful!</h2>
    <p style="margin: 0 0 20px 0; color: ${COLORS.gray}; text-align: center;">
      Thank you, ${escapeHtml(data.customerName)}! Your payment has been received.
    </p>

    ${infoBox(`
      <p style="margin: 0 0 8px 0; color: ${COLORS.gray};"><strong style="color: ${COLORS.gold};">Order Reference:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.orderRef)}</span></p>
      <p style="margin: 0 0 8px 0; color: ${COLORS.gray};"><strong style="color: ${COLORS.gold};">Product:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.product)}</span></p>
      <p style="margin: 0 0 8px 0; color: ${COLORS.gray};"><strong style="color: ${COLORS.gold};">Option:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.option)}</span></p>
      ${data.discountCode ? `
      <p style="margin: 0 0 8px 0; color: ${COLORS.gray};"><strong style="color: ${COLORS.gold};">Original Price:</strong> <span style="color: ${COLORS.gray}; text-decoration: line-through;">$${data.price.toFixed(2)}</span></p>
      <p style="margin: 0 0 8px 0; color: ${COLORS.gray};"><strong style="color: ${COLORS.gold};">Discount (${escapeHtml(data.discountCode)}):</strong> <span style="color: ${COLORS.green};">-$${(data.discountAmount ?? 0).toFixed(2)}</span></p>
      ` : ""}
      <p style="margin: 0; color: ${COLORS.gray};"><strong style="color: ${COLORS.gold};">Amount Paid:</strong> <span style="color: ${COLORS.green}; font-weight: bold;">$${(data.paidAmount ?? data.price).toFixed(2)}</span></p>
    `)}

    ${data.receiptUrl ? `
      <div style="text-align: center;">
        ${button("View Payment Receipt", data.receiptUrl, COLORS.navyLight)}
      </div>
    ` : ""}

    <div style="background: ${COLORS.gold}20; border: 1px solid ${COLORS.gold}40; padding: 20px; border-radius: 8px; margin: 20px 0;">
      <h3 style="color: ${COLORS.gold}; margin: 0 0 12px 0;">What happens next?</h3>
      <p style="color: ${COLORS.gray}; margin: 0; font-size: 14px;">
        You'll receive your RPM Forex Gold Bot file and unique licence key via email within 24 hours. Our team will also reach out with setup instructions.
      </p>
    </div>
  `;

  return baseTemplate(content);
}

/**
 * Contact Form Confirmation - Sent to user
 */
export function contactConfirmationEmail(name: string): string {
  const content = `
    <h2 style="margin: 0 0 10px 0; color: ${COLORS.white}; font-size: 24px;">Message Received!</h2>
    <p style="margin: 0 0 20px 0; color: ${COLORS.gray};">
      Hi ${name}, thank you for getting in touch with RPM Forex.
    </p>

    <p style="color: ${COLORS.gray};">
      We've received your message and will get back to you as soon as possible, typically within 24 hours.
    </p>

    <p style="color: ${COLORS.gray}; margin-top: 20px;">
      In the meantime, you might find answers to common questions on our website.
    </p>

    <div style="text-align: center;">
      ${button("Visit Our Website", "https://rpmforex.com")}
    </div>
  `;

  return baseTemplate(content);
}

// ============================================
// ADMIN EMAILS
// ============================================

/**
 * New Order Alert - Sent to admin
 */
export function adminNewOrderEmail(data: OrderEmailData): string {
  const content = `
    <h2 style="margin: 0 0 10px 0; color: ${COLORS.gold}; font-size: 24px;">🛒 New Order Received</h2>

    ${infoBox(`
      <p style="margin: 0 0 12px 0;"><strong style="color: ${COLORS.gold};">Order Reference:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.orderRef)}</span></p>
      <p style="margin: 0 0 12px 0;"><strong style="color: ${COLORS.gold};">Date:</strong> <span style="color: ${COLORS.white};">${new Date().toLocaleString("en-GB")}</span></p>
      <p style="margin: 0;"><strong style="color: ${COLORS.gold};">Payment Method:</strong> <span style="color: ${COLORS.white};">${data.paymentMethod === "bitcoin" ? "Bitcoin (Pending)" : "Stripe"}</span></p>
    `)}

    <h3 style="margin: 20px 0 15px 0; color: ${COLORS.white};">Customer Details</h3>
    ${infoBox(`
      <p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.gray};">Name:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.customerName)}</span></p>
      <p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.gray};">Email:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.email)}</span></p>
      ${data.phone ? `<p style="margin: 0;"><strong style="color: ${COLORS.gray};">Phone:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.phone)}</span></p>` : ""}
    `)}

    <h3 style="margin: 20px 0 15px 0; color: ${COLORS.white};">Order Details</h3>
    ${infoBox(`
      <p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.gray};">Product:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.product)}</span></p>
      <p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.gray};">Option:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.option)}</span></p>
      ${data.discountCode ? `
      <p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.gray};">Original Price:</strong> <span style="color: ${COLORS.gray}; text-decoration: line-through;">$${data.price.toFixed(2)}</span></p>
      <p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.green};">Discount (${escapeHtml(data.discountCode)}):</strong> <span style="color: ${COLORS.green};">-$${(data.discountAmount ?? 0).toFixed(2)}</span></p>
      ` : ""}
      <p style="margin: 0; font-size: 24px; color: ${COLORS.gold};"><strong>Total: $${(data.paidAmount ?? data.price).toFixed(2)}</strong></p>
    `)}

    ${data.affiliateCode ? `
      <div style="background: ${COLORS.gold}20; border: 1px solid ${COLORS.gold}40; padding: 15px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0; color: ${COLORS.gold};">
          <strong>🤝 Referred by Affiliate:</strong> ${data.affiliateCode}
        </p>
      </div>
    ` : ""}

    <div style="text-align: center;">
      ${button("View in Admin Panel", "https://rpmforex.com/admin/orders")}
    </div>
  `;

  return baseTemplate(content);
}

/**
 * Payment Received Alert - Sent to admin
 */
export function adminPaymentReceivedEmail(data: OrderEmailData): string {
  const content = `
    <h2 style="margin: 0 0 10px 0; color: ${COLORS.green}; font-size: 24px;">💰 Payment Received!</h2>

    ${infoBox(`
      <p style="margin: 0 0 12px 0;"><strong style="color: ${COLORS.gold};">Order Reference:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.orderRef)}</span></p>
      <p style="margin: 0 0 12px 0;"><strong style="color: ${COLORS.gold};">Customer:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.customerName)} (${escapeHtml(data.email)})</span></p>
      <p style="margin: 0 0 12px 0;"><strong style="color: ${COLORS.gold};">Product:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.option)}</span></p>
      ${data.discountCode ? `
      <p style="margin: 0 0 12px 0;"><strong style="color: ${COLORS.gold};">Original Price:</strong> <span style="color: ${COLORS.gray}; text-decoration: line-through;">$${data.price.toFixed(2)}</span></p>
      <p style="margin: 0 0 12px 0;"><strong style="color: ${COLORS.green};">Discount (${escapeHtml(data.discountCode)}):</strong> <span style="color: ${COLORS.green};">-$${(data.discountAmount ?? 0).toFixed(2)}</span></p>
      ` : ""}
      <p style="margin: 0; font-size: 24px; color: ${COLORS.green};"><strong>Amount: $${(data.paidAmount ?? data.price).toFixed(2)}</strong></p>
    `)}

    <p style="color: ${COLORS.gray};">
      Payment confirmed. Please deliver the Bot to the customer and mark the order as Complete in the admin panel.
    </p>

    <div style="text-align: center;">
      ${button("View Order", "https://rpmforex.com/admin/orders")}
    </div>
  `;

  return baseTemplate(content);
}

/**
 * New Contact Submission - Sent to admin
 */
export function adminContactEmail(data: { name: string; email: string; phone?: string | null; message: string }): string {
  const content = `
    <h2 style="margin: 0 0 10px 0; color: ${COLORS.gold}; font-size: 24px;">📩 New Contact Form Submission</h2>

    ${infoBox(`
      <p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.gray};">Name:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.name)}</span></p>
      <p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.gray};">Email:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.email)}</span></p>
      ${data.phone ? `<p style="margin: 0;"><strong style="color: ${COLORS.gray};">Phone:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.phone)}</span></p>` : ""}
    `)}

    <h3 style="margin: 20px 0 15px 0; color: ${COLORS.white};">Message</h3>
    ${infoBox(`
      <p style="white-space: pre-wrap; margin: 0; color: ${COLORS.gray};">${escapeHtml(data.message)}</p>
    `)}

    <div style="text-align: center;">
      ${button(`Reply to ${data.name}`, `mailto:${encodeURIComponent(data.email)}`)}
    </div>
  `;

  return baseTemplate(content);
}

// ============================================
// AFFILIATE EMAILS
// ============================================

interface AffiliateData {
  name: string;
  email: string;
  referralCode?: string;
}

/**
 * Affiliate Application Received
 */
export function affiliateApplicationReceivedEmail(data: AffiliateData): string {
  const content = `
    <h2 style="margin: 0 0 10px 0; color: ${COLORS.white}; font-size: 24px;">Application Received!</h2>
    <p style="margin: 0 0 20px 0; color: ${COLORS.gray};">
      Hi ${escapeHtml(data.name)}, thank you for applying to the RPM Forex Affiliate Program.
    </p>

    <p style="color: ${COLORS.gray};">
      We've received your application and our team will review it shortly. You'll receive an email once your application has been processed.
    </p>

    ${infoBox(`
      <p style="margin: 0; color: ${COLORS.gray}; font-size: 14px;">
        <strong style="color: ${COLORS.gold};">What to expect:</strong><br>
        Applications are typically reviewed within 24-48 hours. Once approved, you'll receive your unique referral link and access to your affiliate dashboard.
      </p>
    `)}
  `;

  return baseTemplate(content);
}

/**
 * Affiliate Application Approved
 */
export function affiliateApprovedEmail(data: AffiliateData): string {
  const content = `
    <div style="text-align: center; margin-bottom: 20px;">
      <span style="font-size: 50px;">🎉</span>
    </div>

    <h2 style="margin: 0 0 10px 0; color: ${COLORS.white}; font-size: 24px; text-align: center;">Welcome to the Team!</h2>
    <p style="margin: 0 0 20px 0; color: ${COLORS.gray}; text-align: center;">
      Hi ${escapeHtml(data.name)}, your affiliate application has been approved!
    </p>

    ${infoBox(`
      <p style="margin: 0 0 12px 0; color: ${COLORS.gray};">
        <strong style="color: ${COLORS.gold};">Your Referral Code:</strong>
      </p>
      <p style="margin: 0; font-family: monospace; font-size: 24px; color: ${COLORS.white}; text-align: center; background: ${COLORS.navyBorder}; padding: 15px; border-radius: 8px;">
        ${escapeHtml(data.referralCode)}
      </p>
    `)}

    <p style="color: ${COLORS.gray}; margin: 20px 0;">
      <strong style="color: ${COLORS.white};">Your Referral Link:</strong><br>
      <span style="font-family: monospace; color: ${COLORS.gold};">https://rpmforex.com/?ref=${escapeHtml(data.referralCode)}</span>
    </p>

    <h3 style="margin: 20px 0 15px 0; color: ${COLORS.white};">How It Works</h3>
    <ul style="color: ${COLORS.gray}; padding-left: 20px;">
      <li style="margin-bottom: 8px;">Share your referral link with potential customers</li>
      <li style="margin-bottom: 8px;">When someone purchases using your link, you earn <strong style="color: ${COLORS.gold};">30% commission</strong></li>
      <li style="margin-bottom: 8px;">Track your earnings in your affiliate dashboard</li>
      <li>Request payouts once you've earned $50+</li>
    </ul>

    <div style="text-align: center;">
      ${button("Access Your Dashboard", "https://rpmforex.com/affiliate/dashboard")}
    </div>
  `;

  return baseTemplate(content);
}

/**
 * Affiliate Application Rejected
 */
export function affiliateRejectedEmail(data: AffiliateData): string {
  const content = `
    <h2 style="margin: 0 0 10px 0; color: ${COLORS.white}; font-size: 24px;">Application Update</h2>
    <p style="margin: 0 0 20px 0; color: ${COLORS.gray};">
      Hi ${escapeHtml(data.name)}, thank you for your interest in the RPM Forex Affiliate Program.
    </p>

    <p style="color: ${COLORS.gray};">
      After reviewing your application, we've decided not to proceed at this time. This could be for various reasons including application volume or fit with our program.
    </p>

    <p style="color: ${COLORS.gray}; margin-top: 20px;">
      If you have any questions, please don't hesitate to contact us.
    </p>
  `;

  return baseTemplate(content);
}

/**
 * Affiliate New Referral Conversion
 */
export function affiliateNewConversionEmail(data: {
  affiliateName: string;
  orderRef: string;
  orderAmount: number;
  commission: number;
  totalPending: number;
}): string {
  const content = `
    <div style="text-align: center; margin-bottom: 20px;">
      <span style="font-size: 50px;">💰</span>
    </div>

    <h2 style="margin: 0 0 10px 0; color: ${COLORS.green}; font-size: 24px; text-align: center;">New Referral Sale!</h2>
    <p style="margin: 0 0 20px 0; color: ${COLORS.gray}; text-align: center;">
      Great news, ${escapeHtml(data.affiliateName)}! You've earned a commission.
    </p>

    ${infoBox(`
      <p style="margin: 0 0 12px 0;"><strong style="color: ${COLORS.gold};">Order Reference:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.orderRef)}</span></p>
      <p style="margin: 0 0 12px 0;"><strong style="color: ${COLORS.gold};">Sale Amount:</strong> <span style="color: ${COLORS.white};">$${data.orderAmount.toFixed(2)}</span></p>
      <p style="margin: 0; font-size: 24px; color: ${COLORS.green};"><strong>Your Commission: $${data.commission.toFixed(2)}</strong></p>
    `)}

    <div style="background: ${COLORS.gold}20; border: 1px solid ${COLORS.gold}40; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
      <p style="margin: 0 0 5px 0; color: ${COLORS.gray}; font-size: 14px;">Your Pending Balance</p>
      <p style="margin: 0; color: ${COLORS.gold}; font-size: 32px; font-weight: bold;">$${data.totalPending.toFixed(2)}</p>
    </div>

    <div style="text-align: center;">
      ${button("View Dashboard", "https://rpmforex.com/affiliate/dashboard")}
    </div>
  `;

  return baseTemplate(content);
}

/**
 * Affiliate Payout Processed
 */
export function affiliatePayoutEmail(data: {
  affiliateName: string;
  amount: number;
  method: string;
  reference?: string;
}): string {
  const content = `
    <div style="text-align: center; margin-bottom: 20px;">
      <span style="font-size: 50px;">✅</span>
    </div>

    <h2 style="margin: 0 0 10px 0; color: ${COLORS.green}; font-size: 24px; text-align: center;">Payout Sent!</h2>
    <p style="margin: 0 0 20px 0; color: ${COLORS.gray}; text-align: center;">
      Hi ${escapeHtml(data.affiliateName)}, your affiliate payout has been processed.
    </p>

    ${infoBox(`
      <p style="margin: 0 0 12px 0; font-size: 24px; color: ${COLORS.green}; text-align: center;"><strong>$${data.amount.toFixed(2)}</strong></p>
      <p style="margin: 0 0 8px 0; text-align: center;"><strong style="color: ${COLORS.gold};">Payment Method:</strong> <span style="color: ${COLORS.white};">${data.method}</span></p>
      ${data.reference ? `<p style="margin: 0; text-align: center;"><strong style="color: ${COLORS.gold};">Reference:</strong> <span style="color: ${COLORS.white};">${data.reference}</span></p>` : ""}
    `)}

    <p style="color: ${COLORS.gray}; text-align: center; margin-top: 20px;">
      Thank you for being part of the RPM Forex Affiliate Program!
    </p>

    <div style="text-align: center;">
      ${button("View Dashboard", "https://rpmforex.com/affiliate/dashboard")}
    </div>
  `;

  return baseTemplate(content);
}

/**
 * Admin: New Affiliate Application
 */
export function adminNewAffiliateEmail(data: AffiliateData & { paymentEmail?: string; paymentMethod?: string }): string {
  const content = `
    <h2 style="margin: 0 0 10px 0; color: ${COLORS.gold}; font-size: 24px;">🤝 New Affiliate Application</h2>

    ${infoBox(`
      <p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.gray};">Name:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.name)}</span></p>
      <p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.gray};">Email:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.email)}</span></p>
      ${data.paymentEmail ? `<p style="margin: 0 0 8px 0;"><strong style="color: ${COLORS.gray};">Payment Email:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.paymentEmail)}</span></p>` : ""}
      ${data.paymentMethod ? `<p style="margin: 0;"><strong style="color: ${COLORS.gray};">Preferred Payout:</strong> <span style="color: ${COLORS.white};">${escapeHtml(data.paymentMethod)}</span></p>` : ""}
    `)}

    <p style="color: ${COLORS.gray}; margin: 20px 0;">
      Please review this application in the admin panel.
    </p>

    <div style="text-align: center;">
      ${button("Review Application", "https://rpmforex.com/admin/affiliates")}
    </div>
  `;

  return baseTemplate(content);
}

/**
 * Affiliate Password Reset
 */
export function affiliatePasswordResetEmail(data: {
  name: string;
  resetUrl: string;
}): string {
  const content = `
    <h2 style="margin: 0 0 10px 0; color: ${COLORS.white}; font-size: 24px;">Reset Your Password</h2>
    <p style="margin: 0 0 20px 0; color: ${COLORS.gray};">
      Hi ${escapeHtml(data.name)}, we received a request to reset the password for your RPM Forex affiliate account.
    </p>

    <p style="color: ${COLORS.gray};">
      Click the button below to choose a new password. This link is valid for <strong style="color: ${COLORS.white};">1 hour</strong>.
    </p>

    <div style="text-align: center;">
      ${button("Reset Password", data.resetUrl)}
    </div>

    ${infoBox(`
      <p style="margin: 0; color: ${COLORS.gray}; font-size: 14px;">
        <strong style="color: ${COLORS.gold};">Didn't request this?</strong><br>
        You can safely ignore this email — your password will not be changed. If you're concerned, contact us at info@rpmforex.com.
      </p>
    `)}

    <p style="color: ${COLORS.gray}; font-size: 12px; margin: 20px 0 0 0;">
      If the button doesn't work, copy and paste this link into your browser:<br>
      <span style="font-family: monospace; color: ${COLORS.gold}; word-break: break-all;">${escapeHtml(data.resetUrl)}</span>
    </p>
  `;

  return baseTemplate(content);
}
