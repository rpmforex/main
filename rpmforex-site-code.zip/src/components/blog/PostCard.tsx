import Link from "next/link";
import { Clock } from "lucide-react";

interface PostCardProps {
  post: {
    title: string;
    slug: string;
    excerpt: string | null;
    featuredImage: string | null;
    publishedAt: string | null;
    readingTime: number;
    category: { name: string; slug: string } | null;
  };
}

export function PostCard({ post }: PostCardProps) {
  return (
    <Link
      href={`/blog/${post.slug}`}
      className="group bg-navy-800/50 border border-navy-700 rounded-2xl overflow-hidden hover:border-gold-500/50 transition-all"
    >
      {/* Image */}
      <div className="aspect-video bg-gradient-to-br from-navy-800 to-navy-900 overflow-hidden">
        {post.featuredImage ? (
          <img
            src={post.featuredImage}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="w-16 h-16 bg-gold-500/10 rounded-full flex items-center justify-center">
              <span className="text-gold-500 text-2xl font-bold">RPM</span>
            </div>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-5">
        <div className="flex items-center gap-3 mb-3">
          {post.category && (
            <span className="text-gold-500 text-xs font-semibold uppercase tracking-wide">
              {post.category.name}
            </span>
          )}
          <span className="flex items-center gap-1 text-gray-500 text-xs">
            <Clock className="w-3 h-3" />
            {post.readingTime} min read
          </span>
        </div>
        <h3 className="text-lg font-semibold text-white mb-2 line-clamp-2 group-hover:text-gold-500 transition-colors">
          {post.title}
        </h3>
        {post.excerpt && (
          <p className="text-gray-400 text-sm line-clamp-3 mb-3">{post.excerpt}</p>
        )}
        {post.publishedAt && (
          <time className="text-gray-500 text-xs" dateTime={post.publishedAt}>
            {new Date(post.publishedAt).toLocaleDateString("en-GB", {
              day: "numeric",
              month: "long",
              year: "numeric",
            })}
          </time>
        )}
      </div>
    </Link>
  );
}
