export function BlogContent({ html }: { html: string }) {
  return (
    <article
      className="blog-content"
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
