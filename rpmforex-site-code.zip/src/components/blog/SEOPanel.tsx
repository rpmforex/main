"use client";

import { useState } from "react";
import { ChevronDown, ChevronUp, Search } from "lucide-react";

interface SEOPanelProps {
  metaTitle: string;
  metaDescription: string;
  ogImage: string;
  canonicalUrl: string;
  slug: string;
  postTitle: string;
  excerpt: string;
  onChange: (field: string, value: string) => void;
}

export function SEOPanel({
  metaTitle,
  metaDescription,
  ogImage,
  canonicalUrl,
  slug,
  postTitle,
  excerpt,
  onChange,
}: SEOPanelProps) {
  const [open, setOpen] = useState(true);

  const displayTitle = metaTitle || postTitle || "Post Title";
  const displayDesc = metaDescription || excerpt || "Post description will appear here...";
  const titleLen = (metaTitle || postTitle).length;
  const descLen = (metaDescription || excerpt).length;

  return (
    <div className="bg-navy-800/50 border border-navy-700 rounded-xl overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-4 hover:bg-navy-800/80 transition-colors"
      >
        <div className="flex items-center gap-2">
          <Search className="w-5 h-5 text-gold-500" />
          <span className="font-semibold text-white">SEO Settings</span>
        </div>
        {open ? (
          <ChevronUp className="w-5 h-5 text-gray-400" />
        ) : (
          <ChevronDown className="w-5 h-5 text-gray-400" />
        )}
      </button>

      {open && (
        <div className="p-4 pt-0 space-y-4">
          {/* Google Preview */}
          <div className="bg-white rounded-lg p-4">
            <p className="text-sm text-green-700 truncate">
              rpmforex.com/blog/{slug || "post-slug"}
            </p>
            <p className="text-lg text-blue-800 font-medium truncate">
              {displayTitle.substring(0, 60)}
            </p>
            <p className="text-sm text-gray-600 line-clamp-2">
              {displayDesc.substring(0, 160)}
            </p>
          </div>

          {/* Meta Title */}
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-sm font-medium text-gray-300">Meta Title</label>
              <span className={`text-xs ${titleLen > 60 ? "text-red-400" : titleLen > 40 ? "text-gold-500" : "text-gray-500"}`}>
                {titleLen}/60
              </span>
            </div>
            <input
              type="text"
              value={metaTitle}
              onChange={(e) => onChange("metaTitle", e.target.value)}
              placeholder={postTitle || "Custom meta title (optional)"}
              className="w-full bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:border-gold-500 focus:outline-none"
            />
          </div>

          {/* Meta Description */}
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-sm font-medium text-gray-300">Meta Description</label>
              <span className={`text-xs ${descLen > 160 ? "text-red-400" : descLen > 120 ? "text-gold-500" : "text-gray-500"}`}>
                {descLen}/160
              </span>
            </div>
            <textarea
              value={metaDescription}
              onChange={(e) => onChange("metaDescription", e.target.value)}
              placeholder={excerpt || "Custom meta description (optional)"}
              rows={3}
              className="w-full bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:border-gold-500 focus:outline-none resize-none"
            />
          </div>

          {/* OG Image */}
          <div>
            <label className="text-sm font-medium text-gray-300 block mb-1">OG Image URL</label>
            <input
              type="text"
              value={ogImage}
              onChange={(e) => onChange("ogImage", e.target.value)}
              placeholder="Custom Open Graph image URL (optional)"
              className="w-full bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:border-gold-500 focus:outline-none"
            />
          </div>

          {/* Canonical URL */}
          <div>
            <label className="text-sm font-medium text-gray-300 block mb-1">Canonical URL</label>
            <input
              type="text"
              value={canonicalUrl}
              onChange={(e) => onChange("canonicalUrl", e.target.value)}
              placeholder="Leave blank to use default"
              className="w-full bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:border-gold-500 focus:outline-none"
            />
          </div>
        </div>
      )}
    </div>
  );
}
