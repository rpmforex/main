interface StatCardProps {
  value: string;
  label: string;
  prefix?: string;
  suffix?: string;
}

export function StatCard({ value, label, prefix = "", suffix = "" }: StatCardProps) {
  return (
    <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-4 md:p-6 text-center">
      <div className="stat-value text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-1 md:mb-2">
        {prefix}{value}{suffix}
      </div>
      <div className="text-gray-400 text-xs sm:text-sm md:text-base">{label}</div>
    </div>
  );
}
