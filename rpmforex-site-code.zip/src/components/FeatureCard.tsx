import { LucideIcon } from "lucide-react";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

export function FeatureCard({ icon: Icon, title, description }: FeatureCardProps) {
  return (
    <div className="bg-navy-800/30 border border-navy-700 rounded-xl p-5 md:p-6 hover:border-gold-500/50 transition-colors">
      {/* Mobile: horizontal layout, Desktop: vertical */}
      <div className="flex items-start gap-4 md:block">
        <div className="w-10 h-10 md:w-12 md:h-12 bg-gold-500/10 rounded-lg flex items-center justify-center flex-shrink-0 md:mb-4">
          <Icon className="w-5 h-5 md:w-6 md:h-6 text-gold-500" />
        </div>
        <div>
          <h3 className="text-lg md:text-xl font-semibold text-white mb-1 md:mb-2">{title}</h3>
          <p className="text-gray-400 text-sm md:text-base">{description}</p>
        </div>
      </div>
    </div>
  );
}
