"use client";

import { createContext, useContext, ReactNode } from "react";
import { CurrencyCode, DEFAULT_CURRENCY } from "@/lib/currency";

interface CurrencyContextType {
  currency: CurrencyCode;
  setCurrency: (currency: CurrencyCode) => void;
  rates: Record<string, number>;
  isLoading: boolean;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(
  undefined
);

// The site displays USD only. USD is the base/charged currency, so the
// provider is pinned to a constant USD context — no cookie read, no geo
// detection, no live-rate fetch. setCurrency is a no-op (no switcher exists).
const USD_CONTEXT: CurrencyContextType = {
  currency: DEFAULT_CURRENCY,
  setCurrency: () => {},
  rates: { USD: 1 },
  isLoading: false,
};

export function CurrencyProvider({ children }: { children: ReactNode }) {
  return (
    <CurrencyContext.Provider value={USD_CONTEXT}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error("useCurrency must be used within a CurrencyProvider");
  }
  return context;
}
