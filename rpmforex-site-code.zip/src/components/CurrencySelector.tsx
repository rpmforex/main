"use client";

import { useState, useRef, useEffect, useSyncExternalStore } from "react";
import { ChevronDown, Check } from "lucide-react";
import { useCurrency } from "./CurrencyProvider";
import { SUPPORTED_CURRENCIES, CurrencyCode } from "@/lib/currency";

const emptySubscribe = () => () => {};

export function CurrencySelector() {
  const { currency, setCurrency } = useCurrency();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Hydration flag: false during SSR/hydration, true after
  const mounted = useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );

  const currentCurrency = SUPPORTED_CURRENCIES[currency];

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    }

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      return () =>
        document.removeEventListener("mousedown", handleClickOutside);
    }
  }, [isOpen]);

  // Placeholder during hydration to avoid a flash of the wrong currency
  if (!mounted) {
    return (
      <div className="relative">
        <button
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-navy-700 text-gray-300 text-sm font-medium opacity-0"
          aria-label="Select currency"
          disabled
        >
          <span>🇬🇧</span>
          <span>GBP</span>
          <ChevronDown size={14} />
        </button>
      </div>
    );
  }

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-navy-700 hover:border-gold-500/50 text-gray-300 hover:text-white text-sm font-medium transition-colors cursor-pointer"
        aria-label={`Select currency (currently ${currentCurrency.name})`}
        aria-expanded={isOpen}
        title={`${currentCurrency.code} - ${currentCurrency.name}`}
      >
        <span role="img" aria-label={currentCurrency.name}>
          {currentCurrency.flag}
        </span>
        <span>{currentCurrency.code}</span>
        <ChevronDown
          size={14}
          className={`transition-transform ${isOpen ? "rotate-180" : ""}`}
        />
      </button>

      {isOpen && (
        <div
          className="absolute right-0 mt-2 w-52 bg-navy-900 border border-navy-700 rounded-xl shadow-2xl py-2 z-[60]"
          role="menu"
          aria-label="Currency selection"
        >
          {Object.entries(SUPPORTED_CURRENCIES).map(([code, info]) => (
            <button
              key={code}
              onClick={() => {
                setCurrency(code as CurrencyCode);
                setIsOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors hover:bg-navy-800 ${
                currency === code ? "bg-navy-800" : ""
              }`}
              role="menuitem"
            >
              <span className="text-xl" role="img" aria-label={info.name}>
                {info.flag}
              </span>
              <div className="flex-1">
                <div
                  className={`font-semibold text-sm ${
                    currency === code ? "text-gold-500" : "text-white"
                  }`}
                >
                  {info.code}
                </div>
                <div className="text-xs text-gray-500">{info.name}</div>
              </div>
              {currency === code && (
                <Check size={16} className="text-gold-500" aria-hidden="true" />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
