import Link from "next/link";
import { Facebook, Send, MessageCircle } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-navy-900 border-t border-navy-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link href="/" className="inline-block">
              <span className="text-2xl font-bold text-white">
                RPM<span className="text-gold-500">Forex</span>
              </span>
            </Link>
            <p className="mt-4 text-gray-400 max-w-md">
              Professional automated gold trading with verified, transparent
              results. Trade smarter with RPM Forex&apos;s advanced Bot
              technology.
            </p>
            <div className="mt-4 space-y-2 text-sm text-gray-400">
              <p className="text-green-400 font-medium">
                All purchases are fully refundable.
              </p>
              <p>
                We also accept payments using PayPal, bank transfer and crypto.{" "}
                <Link href="/contact" className="text-gold-500 hover:text-gold-400">
                  Contact us
                </Link>{" "}
                for details.
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  Home
                </Link>
              </li>
              <li>
                <Link
                  href="/about-us"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  About
                </Link>
              </li>
              <li>
                <Link
                  href="/about"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  How It Works
                </Link>
              </li>
              <li>
                <Link
                  href="/results"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  Results
                </Link>
              </li>
              <li>
                <Link
                  href="/blog"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  Blog
                </Link>
              </li>
              <li>
                <Link
                  href="/buy"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  Buy Bot
                </Link>
              </li>
              <li>
                <Link
                  href="/contact"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  Contact
                </Link>
              </li>
              <li>
                <Link
                  href="/affiliate"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  Affiliates
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal & Contact */}
          <div>
            <h3 className="text-white font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/privacy"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link
                  href="/terms"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link
                  href="/disclaimer"
                  className="text-gray-400 hover:text-gold-500 transition-colors"
                >
                  Risk Disclaimer
                </Link>
              </li>
            </ul>
            <h3 className="text-white font-semibold mb-4 mt-6">Contact</h3>
            <a
              href="mailto:info@rpmforex.com"
              className="text-gray-400 hover:text-gold-500 transition-colors block mb-4"
            >
              info@rpmforex.com
            </a>
            <div className="flex gap-3">
              <a
                href="https://t.me/RPMTRADINCHANNEL"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-navy-800 hover:bg-gold-500 text-gray-400 hover:text-navy-900 rounded-lg flex items-center justify-center transition-colors"
                title="Telegram"
              >
                <Send className="w-5 h-5" />
              </a>
              <a
                href="https://www.facebook.com/RPMTrading"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-navy-800 hover:bg-gold-500 text-gray-400 hover:text-navy-900 rounded-lg flex items-center justify-center transition-colors"
                title="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="https://wa.me/447346914172"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-navy-800 hover:bg-gold-500 text-gray-400 hover:text-navy-900 rounded-lg flex items-center justify-center transition-colors"
                title="WhatsApp"
              >
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
            <a
              href="https://wa.me/447346914172"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 flex items-center justify-center gap-2 w-full py-3 bg-[#25D366] hover:bg-[#20BD5A] text-white font-semibold rounded-lg transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
              Contact us on WhatsApp
            </a>
          </div>
        </div>

        {/* Risk Warning */}
        <div className="mt-10 p-4 bg-navy-800/50 border border-navy-700 rounded-xl">
          <p className="text-xs text-gray-400 leading-relaxed">
            <span className="text-yellow-500 font-semibold">Risk Warning:</span>{" "}
            Trading Derivatives carries a high level of risk to your capital and you should only trade with money you can afford to lose as it can result in the loss of your invested capital in extreme cases. Trading Derivatives may not be suitable for all investors, so please ensure that you fully understand the risks involved and seek independent advice if necessary.
          </p>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-8 border-t border-navy-800">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500 text-sm">
              &copy; {currentYear} RPM Forex. All rights reserved.
            </p>
            <div className="flex gap-4 text-gray-500 text-xs">
              <Link href="/privacy" className="hover:text-gold-500 transition-colors">
                Privacy
              </Link>
              <Link href="/terms" className="hover:text-gold-500 transition-colors">
                Terms
              </Link>
              <Link href="/disclaimer" className="hover:text-gold-500 transition-colors">
                Disclaimer
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
