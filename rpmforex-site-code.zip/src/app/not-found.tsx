"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Home, ArrowLeft, Search, TrendingUp } from "lucide-react";

const tradingPuns = [
  "This page went short when it should have gone long.",
  "Looks like this page hit its stop-loss.",
  "This trade didn't execute as planned.",
  "The market moved, but this page didn't.",
  "404: Position liquidated.",
  "This page is experiencing a flash crash.",
  "Seems like this page got margin called.",
];

const suggestedLinks = [
  { href: "/", label: "Home", icon: Home },
  { href: "/results", label: "View Results", icon: TrendingUp },
  { href: "/buy", label: "Buy Bot", icon: Search },
];

export default function NotFound() {
  const [pun, setPun] = useState("");
  const [glitchText, setGlitchText] = useState("404");

  useEffect(() => {
    // Pick a random pun on mount
    setPun(tradingPuns[Math.floor(Math.random() * tradingPuns.length)]);

    // Glitch effect
    const glitchChars = "!@#$%^&*()_+-=[]{}|;:,.<>?";
    let interval: NodeJS.Timeout;
    let timeout: NodeJS.Timeout;

    const runGlitch = () => {
      let iterations = 0;
      interval = setInterval(() => {
        setGlitchText(
          "404"
            .split("")
            .map((char, index) => {
              if (index < iterations) return "404"[index];
              return glitchChars[Math.floor(Math.random() * glitchChars.length)];
            })
            .join("")
        );
        iterations += 1 / 3;
        if (iterations >= 4) {
          clearInterval(interval);
          setGlitchText("404");
        }
      }, 50);
    };

    runGlitch();
    timeout = setTimeout(() => {
      const recurringGlitch = setInterval(runGlitch, 5000);
      return () => clearInterval(recurringGlitch);
    }, 2000);

    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-b from-navy-900/50 to-navy-950">
      <div className="max-w-2xl w-full text-center">
        {/* Glitchy 404 */}
        <div className="relative mb-8">
          <h1
            className="text-[100px] sm:text-[130px] md:text-[180px] lg:text-[200px] font-bold text-transparent bg-clip-text bg-gradient-to-r from-gold-500 to-gold-600 leading-none select-none"
            style={{
              textShadow: "0 0 80px rgba(212, 175, 55, 0.3)",
            }}
          >
            {glitchText}
          </h1>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-32 h-32 bg-gold-500/10 rounded-full blur-3xl" />
          </div>
        </div>

        {/* Trading pun */}
        <p className="text-lg md:text-xl lg:text-2xl text-gold-500 font-medium mb-3 md:mb-4">
          {pun}
        </p>

        <p className="text-gray-400 text-base md:text-lg mb-8 md:mb-12">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </p>

        {/* Suggested links */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
          {suggestedLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="inline-flex items-center justify-center gap-2 bg-navy-800/50 hover:bg-navy-800 border border-navy-700 hover:border-gold-500/50 text-white px-6 py-3 rounded-lg font-medium transition-all"
            >
              <link.icon className="w-5 h-5 text-gold-500" />
              {link.label}
            </Link>
          ))}
        </div>

        {/* Back button */}
        <button
          onClick={() => window.history.back()}
          className="inline-flex items-center gap-2 text-gray-400 hover:text-gold-500 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Go back to previous page
        </button>

        {/* Decorative chart line */}
        <div className="mt-16 opacity-20">
          <svg
            viewBox="0 0 400 60"
            className="w-full h-16 text-gold-500"
            preserveAspectRatio="none"
          >
            <path
              d="M0,30 L20,25 L40,35 L60,20 L80,40 L100,15 L120,45 L140,25 L160,35 L180,10 L200,50 L220,20 L240,40 L260,15 L280,35 L300,25 L320,45 L340,20 L360,30 L380,25 L400,30"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>
    </div>
  );
}
