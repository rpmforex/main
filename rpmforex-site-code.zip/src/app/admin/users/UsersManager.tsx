"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  Plus,
  Users,
  Shield,
  FileText,
  Trash2,
  Edit3,
  CheckCircle,
  XCircle,
} from "lucide-react";

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  isActive: boolean;
  createdAt: string;
}

interface UsersManagerProps {
  users: User[];
  currentUserId: string;
}

const emptyForm = {
  name: "",
  email: "",
  password: "",
  role: "BLOG_MANAGER" as string,
  isActive: true,
};

const roleConfig: Record<string, { label: string; color: string; icon: typeof Shield }> = {
  SUPER_ADMIN: { label: "Super Admin", color: "bg-gold-500/20 text-gold-400", icon: Shield },
  BLOG_MANAGER: { label: "Blog Manager", color: "bg-blue-500/20 text-blue-400", icon: FileText },
};

export function UsersManager({ users: initialUsers, currentUserId }: UsersManagerProps) {
  const router = useRouter();
  const [users, setUsers] = useState(initialUsers);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function startCreate() {
    setSelectedUser(null);
    setIsCreating(true);
    setForm(emptyForm);
    setError("");
  }

  function startEdit(user: User) {
    setIsCreating(false);
    setSelectedUser(user);
    setForm({
      name: user.name,
      email: user.email,
      password: "",
      role: user.role,
      isActive: user.isActive,
    });
    setError("");
  }

  async function handleSave() {
    setSaving(true);
    setError("");

    try {
      if (isCreating) {
        if (!form.name || !form.email || !form.password) {
          setError("Name, email, and password are required");
          setSaving(false);
          return;
        }

        const res = await fetch("/api/admin/users", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: form.name,
            email: form.email,
            password: form.password,
            role: form.role,
          }),
        });

        const data = await res.json();
        if (!res.ok) {
          setError(data.error || "Failed to create user");
          return;
        }

        setUsers([data.user, ...users]);
        setSelectedUser(data.user);
        setIsCreating(false);
        router.refresh();
      } else if (selectedUser) {
        const payload: Record<string, unknown> = {
          id: selectedUser.id,
          name: form.name,
          email: form.email,
          role: form.role,
          isActive: form.isActive,
        };
        if (form.password) payload.password = form.password;

        const res = await fetch("/api/admin/users", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });

        const data = await res.json();
        if (!res.ok) {
          setError(data.error || "Failed to update user");
          return;
        }

        setUsers(users.map((u) => (u.id === data.user.id ? data.user : u)));
        setSelectedUser(data.user);
        router.refresh();
      }
    } catch {
      setError("An unexpected error occurred");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(userId: string) {
    if (!confirm("Are you sure you want to delete this user? This cannot be undone.")) return;

    try {
      const res = await fetch("/api/admin/users", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: userId }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to delete user");
        return;
      }

      setUsers(users.filter((u) => u.id !== userId));
      setSelectedUser(null);
      setIsCreating(false);
      router.refresh();
    } catch {
      setError("Failed to delete user");
    }
  }

  const isSelf = selectedUser?.id === currentUserId;

  return (
    <div className="min-h-screen pt-8 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link
              href="/admin"
              className="text-gray-400 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-white">Users</h1>
              <p className="text-gray-400">{users.length} admin user{users.length !== 1 ? "s" : ""}</p>
            </div>
          </div>
          <button
            onClick={startCreate}
            className="flex items-center gap-2 bg-gold-500 hover:bg-gold-400 text-navy-950 px-4 py-2 rounded-lg font-semibold transition-colors"
          >
            <Plus className="w-4 h-4" />
            New User
          </button>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* User List */}
          <div className="lg:col-span-1 space-y-3">
            {users.length === 0 && !isCreating && (
              <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-8 text-center">
                <Users className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                <p className="text-gray-500">No users yet</p>
              </div>
            )}
            {users.map((user) => {
              const cfg = roleConfig[user.role] || roleConfig.BLOG_MANAGER;
              return (
                <button
                  key={user.id}
                  onClick={() => startEdit(user)}
                  className={`w-full text-left bg-navy-800/50 border rounded-xl p-4 transition-colors ${
                    selectedUser?.id === user.id
                      ? "border-gold-500"
                      : "border-navy-700 hover:border-navy-600"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-white">{user.name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${cfg.color}`}>
                      {cfg.label}
                    </span>
                  </div>
                  <p className="text-gray-500 text-sm">{user.email}</p>
                  <div className="flex items-center justify-between mt-2 text-xs">
                    <span className={user.isActive ? "text-green-400" : "text-red-400"}>
                      {user.isActive ? "Active" : "Inactive"}
                    </span>
                    {user.id === currentUserId && (
                      <span className="text-gold-500">You</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Detail / Form Panel */}
          <div className="lg:col-span-2">
            {!selectedUser && !isCreating ? (
              <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-12 text-center">
                <Users className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-500 text-lg">Select a user to edit or create a new one</p>
              </div>
            ) : (
              <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    {isCreating ? (
                      <>
                        <Plus className="w-5 h-5 text-gold-500" />
                        Create User
                      </>
                    ) : (
                      <>
                        <Edit3 className="w-5 h-5 text-gold-500" />
                        Edit User
                        {isSelf && <span className="text-sm text-gold-500 font-normal">(You)</span>}
                      </>
                    )}
                  </h2>
                  {selectedUser && !isSelf && (
                    <button
                      onClick={() => handleDelete(selectedUser.id)}
                      className="flex items-center gap-1 text-red-400 hover:text-red-300 text-sm"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete
                    </button>
                  )}
                </div>

                {error && (
                  <div className="flex items-center gap-2 text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg p-3 mb-4">
                    <XCircle className="w-4 h-4 flex-shrink-0" />
                    <p className="text-sm">{error}</p>
                  </div>
                )}

                <div className="space-y-4">
                  {/* Name */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Name *</label>
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="Full name"
                      className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Email *</label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="admin@example.com"
                      className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                    />
                  </div>

                  {/* Password */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      Password {isCreating ? "*" : ""}
                    </label>
                    <input
                      type="password"
                      value={form.password}
                      onChange={(e) => setForm({ ...form, password: e.target.value })}
                      placeholder={isCreating ? "Min 8 characters" : "Leave blank to keep current"}
                      className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                    />
                  </div>

                  {/* Role */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Role *</label>
                    <select
                      value={form.role}
                      onChange={(e) => setForm({ ...form, role: e.target.value })}
                      disabled={isSelf}
                      className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent disabled:opacity-50"
                    >
                      <option value="SUPER_ADMIN">Super Admin — Full access</option>
                      <option value="BLOG_MANAGER">Blog Manager — Blog access only</option>
                    </select>
                    {isSelf && (
                      <p className="text-xs text-gray-500 mt-1">You cannot change your own role</p>
                    )}
                  </div>

                  {/* Active Toggle (edit only, not self) */}
                  {!isCreating && (
                    <div className="flex items-center justify-between bg-navy-900 rounded-lg p-3 border border-navy-700">
                      <div>
                        <span className="text-white font-medium">Active</span>
                        <p className="text-gray-500 text-xs">
                          {isSelf ? "You cannot deactivate yourself" : "Inactive users cannot log in"}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => !isSelf && setForm({ ...form, isActive: !form.isActive })}
                        disabled={isSelf}
                        className={`relative w-12 h-6 rounded-full transition-colors ${
                          form.isActive ? "bg-green-500" : "bg-navy-700"
                        } ${isSelf ? "opacity-50 cursor-not-allowed" : ""}`}
                      >
                        <span
                          className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                            form.isActive ? "left-7" : "left-1"
                          }`}
                        />
                      </button>
                    </div>
                  )}

                  {/* Created date (edit only) */}
                  {selectedUser && !isCreating && (
                    <div className="bg-navy-900 rounded-lg p-4 border border-navy-700">
                      <p className="text-sm text-gray-400">
                        Created {new Date(selectedUser.createdAt).toLocaleDateString("en-GB", {
                          day: "numeric",
                          month: "long",
                          year: "numeric",
                        })}
                      </p>
                    </div>
                  )}

                  {/* Save Button */}
                  <button
                    onClick={handleSave}
                    disabled={saving || !form.name || !form.email || (isCreating && !form.password)}
                    className="w-full flex items-center justify-center gap-2 bg-gold-500 hover:bg-gold-400 text-navy-950 px-6 py-3 rounded-lg font-semibold transition-colors disabled:opacity-50"
                  >
                    {saving ? (
                      "Saving..."
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4" />
                        {isCreating ? "Create User" : "Save Changes"}
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
