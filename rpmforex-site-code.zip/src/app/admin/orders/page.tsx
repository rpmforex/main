import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { OrdersManager } from "./OrdersManager";

export default async function OrdersPage() {
  const session = await getSession();

  if (!session) {
    redirect("/admin/login");
  }

  if (session.role !== "SUPER_ADMIN") {
    redirect("/admin");
  }

  const rawOrders = await prisma.order.findMany({
    orderBy: { createdAt: "desc" },
  });

  // Serialize Decimal to number for client component
  const orders = rawOrders.map((order: typeof rawOrders[number]) => ({
    ...order,
    price: Number(order.price),
    paidAmount: order.paidAmount ? Number(order.paidAmount) : null,
    discountAmount: order.discountAmount ? Number(order.discountAmount) : null,
  }));

  return <OrdersManager orders={orders} />;
}
