"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  Clock,
  CheckCircle,
  XCircle,
  Truck,
  Package,
  CreditCard,
  Search,
  ExternalLink,
  Trash2,
} from "lucide-react";
interface Order {
  id: string;
  orderRef: string;
  name: string;
  email: string;
  phone: string | null;
  brokerOption: string;
  brokerLabel: string;
  price: number | string;
  paidAmount: number | string | null;
  discountCode: string | null;
  discountAmount: number | string | null;
  paymentMethod: string;
  paymentStatus: string;
  stripeReceiptUrl: string | null;
  status: string;
  notes: string | null;
  createdAt: Date;
  paidAt: Date | null;
  shippedAt: Date | null;
  deliveredAt: Date | null;
}

const statusColors: Record<string, string> = {
  PENDING: "bg-yellow-500/10 text-yellow-500 border-yellow-500/30",
  COMPLETE: "bg-green-500/10 text-green-500 border-green-500/30",
  PAID: "bg-green-500/10 text-green-500 border-green-500/30",
  FAILED: "bg-red-500/10 text-red-500 border-red-500/30",
  REFUNDED: "bg-gray-500/10 text-gray-500 border-gray-500/30",
};

const statusIcons: Record<string, React.ReactNode> = {
  PENDING: <Clock className="w-4 h-4" />,
  COMPLETE: <CheckCircle className="w-4 h-4" />,
  PAID: <CheckCircle className="w-4 h-4" />,
  FAILED: <XCircle className="w-4 h-4" />,
};

export function OrdersManager({ orders: initialOrders }: { orders: Order[] }) {
  const router = useRouter();
  const [orders, setOrders] = useState(initialOrders);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [filterPayment, setFilterPayment] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [updating, setUpdating] = useState(false);
  const [receivedAmount, setReceivedAmount] = useState<string>("");

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      search === "" ||
      order.orderRef.toLowerCase().includes(search.toLowerCase()) ||
      order.name.toLowerCase().includes(search.toLowerCase()) ||
      order.email.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = filterStatus === "" || order.status === filterStatus;
    const matchesPayment =
      filterPayment === "" || order.paymentStatus === filterPayment;

    return matchesSearch && matchesStatus && matchesPayment;
  });

  async function updateOrder(id: string, data: Record<string, unknown>) {
    setUpdating(true);
    try {
      const response = await fetch("/api/admin/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, ...data }),
      });

      if (response.ok) {
        const { order } = await response.json();
        setOrders((prev) => prev.map((o) => (o.id === id ? order : o)));
        if (selectedOrder?.id === id) {
          setSelectedOrder(order);
        }
        router.refresh();
      }
    } catch (error) {
      console.error("Failed to update order:", error);
    } finally {
      setUpdating(false);
    }
  }

  async function deleteOrder(id: string) {
    if (!confirm("Are you sure you want to delete this pending order?")) return;
    setUpdating(true);
    try {
      const response = await fetch("/api/admin/orders", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (response.ok) {
        setOrders((prev) => prev.filter((o) => o.id !== id));
        setSelectedOrder(null);
        router.refresh();
      }
    } catch (error) {
      console.error("Failed to delete order:", error);
    } finally {
      setUpdating(false);
    }
  }

  return (
    <div className="min-h-screen pt-8 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link
            href="/admin"
            className="p-2 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-white">Orders</h1>
            <p className="text-gray-400">{orders.length} total orders</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Search orders..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-navy-800 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 bg-navy-800 border border-navy-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
          >
            <option value="">All Statuses</option>
            <option value="PENDING">Pending</option>
            <option value="COMPLETE">Complete</option>
          </select>
          <select
            value={filterPayment}
            onChange={(e) => setFilterPayment(e.target.value)}
            className="px-4 py-2 bg-navy-800 border border-navy-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
          >
            <option value="">All Payments</option>
            <option value="PENDING">Pending</option>
            <option value="PAID">Paid</option>
            <option value="FAILED">Failed</option>
          </select>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Orders List */}
          <div className="lg:col-span-2 space-y-4">
            {filteredOrders.map((order) => (
              <div
                key={order.id}
                onClick={() => {
                  setSelectedOrder(order);
                  setReceivedAmount(order.paidAmount ? String(Number(order.paidAmount)) : String(Number(order.price)));
                }}
                className={`bg-navy-800/50 border rounded-xl p-4 cursor-pointer transition-all ${
                  selectedOrder?.id === order.id
                    ? "border-gold-500"
                    : "border-navy-700 hover:border-navy-600"
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="font-mono text-white font-medium">
                      {order.orderRef}
                    </p>
                    <p className="text-gray-400 text-sm">{order.name}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-bold">
                      ${Number(order.paidAmount ?? order.price).toFixed(2)}
                    </p>
                    {order.discountCode && (
                      <p className="text-green-400 text-xs">
                        {order.discountCode}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${
                      statusColors[order.paymentStatus]
                    }`}
                  >
                    {statusIcons[order.paymentStatus]}
                    {order.paymentStatus}
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${
                      statusColors[order.status]
                    }`}
                  >
                    {statusIcons[order.status]}
                    {order.status}
                  </span>
                  <span className="text-gray-500 text-xs ml-auto">
                    {order.paymentMethod === "BITCOIN" ? "₿" : "💳"}{" "}
                    {new Date(order.createdAt).toLocaleDateString("en-GB")}
                  </span>
                </div>
              </div>
            ))}
            {filteredOrders.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                No orders found
              </div>
            )}
          </div>

          {/* Order Details Panel */}
          <div className="lg:col-span-1">
            {selectedOrder ? (
              <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-6 sticky top-8">
                {/* Payment Warning Banner */}
                {selectedOrder.paymentStatus !== "PAID" && (
                  <div className="mb-4 p-4 bg-red-500/20 border-2 border-red-500 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <XCircle className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="text-red-400 font-bold text-lg">AWAITING PAYMENT</p>
                        <p className="text-red-300 text-sm">
                          {selectedOrder.paymentMethod === "BITCOIN"
                            ? "Bitcoin payment not yet received"
                            : "Card payment not completed"}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Payment Confirmed Banner */}
                {selectedOrder.paymentStatus === "PAID" && (
                  <div className="mb-4 p-4 bg-green-500/20 border border-green-500/50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="text-green-400 font-bold">PAYMENT CONFIRMED</p>
                        {selectedOrder.paidAt && (
                          <p className="text-green-300 text-sm">
                            Paid {new Date(selectedOrder.paidAt).toLocaleString("en-GB")}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                <h2 className="text-xl font-bold text-white mb-4">
                  Order Details
                </h2>

                <div className="space-y-4">
                  <div>
                    <p className="text-gray-500 text-sm">Reference</p>
                    <p className="text-white font-mono">
                      {selectedOrder.orderRef}
                    </p>
                  </div>

                  <div>
                    <p className="text-gray-500 text-sm">Customer</p>
                    <p className="text-white">{selectedOrder.name}</p>
                    <p className="text-gray-400 text-sm">
                      {selectedOrder.email}
                    </p>
                    {selectedOrder.phone && (
                      <p className="text-gray-400 text-sm">
                        {selectedOrder.phone}
                      </p>
                    )}
                  </div>

                  <div>
                    <p className="text-gray-500 text-sm">Product</p>
                    <p className="text-white">RPM Forex Gold Bot</p>
                    <p className="text-gray-400 text-sm">{selectedOrder.brokerLabel}</p>
                  </div>

                  <div>
                    <p className="text-gray-500 text-sm">Amount</p>
                    {selectedOrder.discountCode ? (
                      <div>
                        <p className="text-gray-400 line-through text-sm">
                          ${Number(selectedOrder.price).toFixed(2)}
                        </p>
                        <p className="text-2xl font-bold text-gold-500">
                          ${Number(selectedOrder.paidAmount ?? selectedOrder.price).toFixed(2)}
                        </p>
                        <div className="mt-1 inline-flex items-center gap-1 px-2 py-1 bg-green-500/10 border border-green-500/30 rounded text-green-400 text-xs">
                          <span>{selectedOrder.discountCode}</span>
                          <span>(-${Number(selectedOrder.discountAmount ?? 0).toFixed(2)})</span>
                        </div>
                      </div>
                    ) : (
                      <p className="text-2xl font-bold text-gold-500">
                        ${Number(selectedOrder.paidAmount ?? selectedOrder.price).toFixed(2)}
                      </p>
                    )}
                  </div>

                  <div>
                    <p className="text-gray-500 text-sm">Payment Method</p>
                    <p className="text-white flex items-center gap-2">
                      {selectedOrder.paymentMethod === "BITCOIN" ? (
                        <>₿ Bitcoin</>
                      ) : (
                        <>
                          <CreditCard className="w-4 h-4" /> Card (Stripe)
                        </>
                      )}
                    </p>
                  </div>

                  {selectedOrder.stripeReceiptUrl && (
                    <a
                      href={selectedOrder.stripeReceiptUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 w-full px-4 py-2 bg-navy-700 hover:bg-navy-600 text-white rounded-lg transition-colors text-sm"
                    >
                      <ExternalLink className="w-4 h-4" />
                      View Stripe Receipt
                    </a>
                  )}

                  <hr className="border-navy-700" />

                  {/* Received Amount - for Bitcoin orders with pending payment */}
                  {selectedOrder.paymentMethod === "BITCOIN" && selectedOrder.paymentStatus === "PENDING" && (
                    <div>
                      <p className="text-gray-500 text-sm mb-2">Received Amount ($)</p>
                      <input
                        type="number"
                        step="0.01"
                        value={receivedAmount}
                        onChange={(e) => setReceivedAmount(e.target.value)}
                        className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        placeholder={`Default: $${Number(selectedOrder.price).toFixed(2)}`}
                      />
                      <p className="text-gray-500 text-xs mt-1">
                        Enter the actual amount received before marking as paid
                      </p>
                    </div>
                  )}

                  {/* Payment Status */}
                  <div>
                    <p className="text-gray-500 text-sm mb-2">Payment Status</p>
                    <select
                      value={selectedOrder.paymentStatus}
                      onChange={(e) => {
                        const newStatus = e.target.value;
                        const updateData: Record<string, unknown> = { paymentStatus: newStatus };

                        // Include received amount when marking Bitcoin order as paid
                        if (newStatus === "PAID" && selectedOrder.paymentMethod === "BITCOIN" && receivedAmount) {
                          updateData.paidAmount = parseFloat(receivedAmount);
                        }

                        updateOrder(selectedOrder.id, updateData);
                      }}
                      disabled={updating}
                      className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                    >
                      <option value="PENDING">Pending</option>
                      <option value="PAID">Paid</option>
                      <option value="FAILED">Failed</option>
                      <option value="REFUNDED">Refunded</option>
                    </select>
                  </div>

                  {/* Order Status */}
                  <div>
                    <p className="text-gray-500 text-sm mb-2">Order Status</p>
                    <select
                      value={selectedOrder.status === "COMPLETE" ? "COMPLETE" : "PENDING"}
                      onChange={(e) =>
                        updateOrder(selectedOrder.id, { status: e.target.value })
                      }
                      disabled={updating}
                      className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                    >
                      <option value="PENDING">Pending</option>
                      <option value="COMPLETE">Complete</option>
                    </select>
                  </div>

                  {/* Timestamps */}
                  <div className="text-xs text-gray-500 space-y-1">
                    <p>
                      Created:{" "}
                      {new Date(selectedOrder.createdAt).toLocaleString("en-GB")}
                    </p>
                    {selectedOrder.paidAt && (
                      <p>
                        Paid:{" "}
                        {new Date(selectedOrder.paidAt).toLocaleString("en-GB")}
                      </p>
                    )}
                    {selectedOrder.shippedAt && (
                      <p>
                        Shipped:{" "}
                        {new Date(selectedOrder.shippedAt).toLocaleString(
                          "en-GB"
                        )}
                      </p>
                    )}
                    {selectedOrder.deliveredAt && (
                      <p>
                        Delivered:{" "}
                        {new Date(selectedOrder.deliveredAt).toLocaleString(
                          "en-GB"
                        )}
                      </p>
                    )}
                  </div>

                  {/* Delete Pending Order */}
                  {selectedOrder.paymentStatus === "PENDING" && selectedOrder.status === "PENDING" && (
                    <button
                      onClick={() => deleteOrder(selectedOrder.id)}
                      disabled={updating}
                      className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 rounded-lg transition-colors text-sm disabled:opacity-50"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete Order
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-navy-800/30 border border-navy-700 rounded-xl p-6 text-center text-gray-500">
                Select an order to view details
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
