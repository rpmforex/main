import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { BlogCategoriesManager } from "./BlogCategoriesManager";

export default async function BlogCategoriesAdminPage() {
  const session = await getSession();
  if (!session) redirect("/admin/login");

  const rawCategories = await prisma.blogCategory.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { posts: true } } },
  });

  const categories = rawCategories.map((cat) => ({
    ...cat,
    createdAt: cat.createdAt.toISOString(),
    updatedAt: cat.updatedAt.toISOString(),
  }));

  return <BlogCategoriesManager initialCategories={categories} />;
}
