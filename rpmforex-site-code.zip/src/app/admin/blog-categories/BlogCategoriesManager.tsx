"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Plus, Trash2, Edit3, FolderOpen } from "lucide-react";
import Link from "next/link";

interface Category {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  _count: { posts: number };
  createdAt: string;
  updatedAt: string;
}

export function BlogCategoriesManager({ initialCategories }: { initialCategories: Category[] }) {
  const router = useRouter();
  const [categories, setCategories] = useState(initialCategories);
  const [selected, setSelected] = useState<Category | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const startCreate = () => {
    setSelected(null);
    setIsCreating(true);
    setName("");
    setDescription("");
    setError("");
  };

  const startEdit = (cat: Category) => {
    setIsCreating(false);
    setSelected(cat);
    setName(cat.name);
    setDescription(cat.description || "");
    setError("");
  };

  const handleSave = async () => {
    if (!name.trim()) { setError("Name is required"); return; }
    setSaving(true);
    setError("");

    try {
      const method = isCreating ? "POST" : "PATCH";
      const body = isCreating
        ? { name, description }
        : { id: selected!.id, name, description };

      const res = await fetch("/api/admin/blog-categories", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      router.refresh();
      if (isCreating) {
        setCategories([...categories, { ...data.category, _count: { posts: 0 }, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }]);
        setIsCreating(false);
      } else {
        setCategories(categories.map((c) => c.id === data.category.id ? { ...c, ...data.category } : c));
        setSelected({ ...selected!, ...data.category });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string, postCount: number) => {
    const msg = postCount > 0
      ? `This category has ${postCount} post(s). They will become uncategorized. Delete anyway?`
      : "Delete this category?";
    if (!confirm(msg)) return;

    try {
      const res = await fetch("/api/admin/blog-categories", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (!res.ok) throw new Error("Failed to delete");

      setCategories(categories.filter((c) => c.id !== id));
      if (selected?.id === id) { setSelected(null); setIsCreating(false); }
      router.refresh();
    } catch {
      setError("Failed to delete category");
    }
  };

  return (
    <div className="min-h-screen bg-navy-950 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/admin" className="text-gray-400 hover:text-white transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-2xl font-bold text-white">Blog Categories</h1>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* List */}
          <div className="lg:col-span-1 space-y-3">
            <button
              onClick={startCreate}
              className="w-full flex items-center justify-center gap-2 bg-gold-500 hover:bg-gold-400 text-navy-950 font-semibold py-3 rounded-lg transition-colors"
            >
              <Plus className="w-5 h-5" /> New Category
            </button>

            {categories.length === 0 && (
              <p className="text-gray-500 text-center py-8">No categories yet</p>
            )}

            {categories.map((cat) => (
              <div
                key={cat.id}
                onClick={() => startEdit(cat)}
                className={`p-4 rounded-xl border cursor-pointer transition-colors ${
                  selected?.id === cat.id
                    ? "bg-navy-800/80 border-gold-500"
                    : "bg-navy-800/30 border-navy-700 hover:border-navy-600"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FolderOpen className="w-4 h-4 text-gold-500" />
                    <span className="text-white font-medium">{cat.name}</span>
                  </div>
                  <span className="text-gray-500 text-xs">{cat._count.posts} posts</span>
                </div>
                {cat.description && (
                  <p className="text-gray-400 text-sm mt-1 truncate">{cat.description}</p>
                )}
              </div>
            ))}
          </div>

          {/* Form */}
          <div className="lg:col-span-2">
            {(isCreating || selected) ? (
              <div className="bg-navy-800/30 border border-navy-700 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Edit3 className="w-5 h-5 text-gold-500" />
                    {isCreating ? "New Category" : "Edit Category"}
                  </h2>
                  {selected && (
                    <button
                      onClick={() => handleDelete(selected.id, selected._count.posts)}
                      className="p-2 text-red-400 hover:text-red-300 hover:bg-red-400/10 rounded-lg transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  )}
                </div>

                {error && (
                  <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
                    {error}
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-1">Name</label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white focus:border-gold-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-1">Description (optional)</label>
                    <textarea
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={3}
                      className="w-full bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white focus:border-gold-500 focus:outline-none resize-none"
                    />
                  </div>
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="w-full bg-gold-500 hover:bg-gold-400 text-navy-950 font-semibold py-3 rounded-lg transition-colors disabled:opacity-50"
                  >
                    {saving ? "Saving..." : isCreating ? "Create Category" : "Update Category"}
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-64 text-gray-500">
                Select a category to edit or create a new one
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
