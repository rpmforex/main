"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Mail, MailOpen, Trash2, MessageSquare } from "lucide-react";

interface Contact {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  message: string;
  read: boolean;
  createdAt: Date;
}

export function ContactsManager({
  contacts: initialContacts,
}: {
  contacts: Contact[];
}) {
  const router = useRouter();
  const [contacts, setContacts] = useState(initialContacts);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);

  async function markAsRead(id: string, read: boolean) {
    try {
      const response = await fetch("/api/admin/contacts", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, read }),
      });

      if (response.ok) {
        setContacts((prev) =>
          prev.map((c) => (c.id === id ? { ...c, read } : c))
        );
        if (selectedContact?.id === id) {
          setSelectedContact({ ...selectedContact, read });
        }
        router.refresh();
      }
    } catch (error) {
      console.error("Failed to update contact:", error);
    }
  }

  async function deleteContact(id: string) {
    if (!confirm("Are you sure you want to delete this message?")) return;

    try {
      const response = await fetch("/api/admin/contacts", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });

      if (response.ok) {
        setContacts((prev) => prev.filter((c) => c.id !== id));
        if (selectedContact?.id === id) {
          setSelectedContact(null);
        }
        router.refresh();
      }
    } catch (error) {
      console.error("Failed to delete contact:", error);
    }
  }

  function handleSelectContact(contact: Contact) {
    setSelectedContact(contact);
    if (!contact.read) {
      markAsRead(contact.id, true);
    }
  }

  const unreadCount = contacts.filter((c) => !c.read).length;

  return (
    <div className="min-h-screen pt-8 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link
            href="/admin"
            className="p-2 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-white">Messages</h1>
            <p className="text-gray-400">
              {contacts.length} total, {unreadCount} unread
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Messages List */}
          <div className="lg:col-span-1 space-y-2">
            {contacts.map((contact) => (
              <div
                key={contact.id}
                onClick={() => handleSelectContact(contact)}
                className={`p-4 rounded-xl cursor-pointer transition-all ${
                  selectedContact?.id === contact.id
                    ? "bg-navy-700 border border-gold-500"
                    : contact.read
                    ? "bg-navy-800/30 border border-navy-700 hover:border-navy-600"
                    : "bg-navy-800/50 border border-gold-500/30 hover:border-gold-500/50"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`p-2 rounded-lg ${
                      contact.read ? "bg-navy-700" : "bg-gold-500/10"
                    }`}
                  >
                    {contact.read ? (
                      <MailOpen className="w-4 h-4 text-gray-400" />
                    ) : (
                      <Mail className="w-4 h-4 text-gold-500" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`font-medium truncate ${
                        contact.read ? "text-gray-300" : "text-white"
                      }`}
                    >
                      {contact.name}
                    </p>
                    <p className="text-gray-500 text-sm truncate">
                      {contact.email}
                    </p>
                    <p className="text-gray-600 text-xs mt-1">
                      {new Date(contact.createdAt).toLocaleDateString("en-GB")}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            {contacts.length === 0 && (
              <div className="text-center py-12">
                <MessageSquare className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-500">No messages yet</p>
              </div>
            )}
          </div>

          {/* Message Details */}
          <div className="lg:col-span-2">
            {selectedContact ? (
              <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-6">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">
                      {selectedContact.name}
                    </h2>
                    <a
                      href={`mailto:${selectedContact.email}`}
                      className="text-gold-500 hover:text-gold-400"
                    >
                      {selectedContact.email}
                    </a>
                    {selectedContact.phone && (
                      <p className="text-gray-400 mt-1">
                        {selectedContact.phone}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() =>
                        markAsRead(selectedContact.id, !selectedContact.read)
                      }
                      className="p-2 text-gray-400 hover:text-white transition-colors"
                      title={
                        selectedContact.read ? "Mark as unread" : "Mark as read"
                      }
                    >
                      {selectedContact.read ? (
                        <Mail className="w-5 h-5" />
                      ) : (
                        <MailOpen className="w-5 h-5" />
                      )}
                    </button>
                    <button
                      onClick={() => deleteContact(selectedContact.id)}
                      className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="bg-navy-900 rounded-xl p-6">
                  <p className="text-gray-300 whitespace-pre-wrap">
                    {selectedContact.message}
                  </p>
                </div>

                <div className="mt-6 flex items-center justify-between">
                  <p className="text-gray-500 text-sm">
                    Received:{" "}
                    {new Date(selectedContact.createdAt).toLocaleString("en-GB")}
                  </p>
                  <a
                    href={`mailto:${selectedContact.email}?subject=Re: Your message to RPM Forex`}
                    className="bg-gold-500 hover:bg-gold-400 text-navy-950 px-4 py-2 rounded-lg font-semibold transition-colors"
                  >
                    Reply
                  </a>
                </div>
              </div>
            ) : (
              <div className="bg-navy-800/30 border border-navy-700 rounded-xl p-12 text-center">
                <MessageSquare className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-500">Select a message to view</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
