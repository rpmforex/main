import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { AdminDashboard } from "./AdminDashboard";

export default async function AdminPage() {
  const session = await getSession();

  if (!session) {
    redirect("/admin/login");
  }

  const isSuperAdmin = session.role === "SUPER_ADMIN";

  const [stats, rawOrders] = isSuperAdmin
    ? await Promise.all([
        getStats(),
        prisma.order.findMany({
          take: 10,
          orderBy: { createdAt: "desc" },
        }),
      ])
    : [
        { totalOrders: 0, pendingPayments: 0, paidOrders: 0, totalRevenue: 0, unreadContacts: 0 },
        [] as Awaited<ReturnType<typeof prisma.order.findMany>>,
      ];

  // Serialize Decimal to number for client component
  const recentOrders = rawOrders.map((order: (typeof rawOrders)[number]) => ({
    ...order,
    price: Number(order.price),
    paidAmount: order.paidAmount ? Number(order.paidAmount) : null,
    discountAmount: order.discountAmount ? Number(order.discountAmount) : null,
  }));

  return <AdminDashboard user={session} stats={stats} recentOrders={recentOrders} />;
}

async function getStats() {
  const [totalOrders, pendingPayments, paidOrders, totalRevenue, unreadContacts] =
    await Promise.all([
      prisma.order.count(),
      prisma.order.count({ where: { paymentStatus: "PENDING" } }),
      prisma.order.count({ where: { paymentStatus: "PAID" } }),
      prisma.order.aggregate({
        where: { paymentStatus: "PAID" },
        _sum: { price: true },
      }),
      prisma.contactSubmission.count({ where: { read: false } }),
    ]);

  return {
    totalOrders,
    pendingPayments,
    paidOrders,
    totalRevenue: Number(totalRevenue._sum.price || 0),
    unreadContacts,
  };
}
