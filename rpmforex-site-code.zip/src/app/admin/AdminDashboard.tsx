"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ShoppingCart,
  CreditCard,
  DollarSign,
  MessageSquare,
  Package,
  LogOut,
  Clock,
  CheckCircle,
  XCircle,
  Truck,
  FileText,
  FolderOpen,
  Users,
  Tag,
  Handshake,
  ChevronRight,
} from "lucide-react";
interface User {
  id: string;
  email: string;
  name: string;
  role: string;
}

interface Stats {
  totalOrders: number;
  pendingPayments: number;
  paidOrders: number;
  totalRevenue: number;
  unreadContacts: number;
}

interface Order {
  id: string;
  orderRef: string;
  name: string;
  email: string;
  brokerLabel: string;
  price: number | string;
  paymentMethod: string;
  paymentStatus: string;
  status: string;
  createdAt: Date;
}

interface AdminDashboardProps {
  user: User;
  stats: Stats;
  recentOrders: Order[];
}

const statusColors: Record<string, string> = {
  PENDING: "bg-yellow-500/10 text-yellow-500",
  PROCESSING: "bg-blue-500/10 text-blue-500",
  SHIPPED: "bg-purple-500/10 text-purple-500",
  DELIVERED: "bg-green-500/10 text-green-500",
  CANCELLED: "bg-red-500/10 text-red-500",
  PAID: "bg-green-500/10 text-green-500",
  FAILED: "bg-red-500/10 text-red-500",
};

const statusIcons: Record<string, React.ReactNode> = {
  PENDING: <Clock className="w-4 h-4" />,
  PROCESSING: <Package className="w-4 h-4" />,
  SHIPPED: <Truck className="w-4 h-4" />,
  DELIVERED: <CheckCircle className="w-4 h-4" />,
  CANCELLED: <XCircle className="w-4 h-4" />,
  PAID: <CheckCircle className="w-4 h-4" />,
  FAILED: <XCircle className="w-4 h-4" />,
};

export function AdminDashboard({ user, stats, recentOrders }: AdminDashboardProps) {
  const router = useRouter();
  const isSuperAdmin = user.role === "SUPER_ADMIN";

  async function handleLogout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <div className="min-h-screen pt-8 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Dashboard</h1>
            <p className="text-gray-400">Welcome back, {user.name}</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <LogOut className="w-5 h-5" />
            Logout
          </button>
        </div>

        {/* Stats Grid — Super Admin only */}
        {isSuperAdmin && (
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
            <StatCard
              icon={<ShoppingCart className="w-6 h-6" />}
              label="Total Orders"
              value={stats.totalOrders.toString()}
            />
            <StatCard
              icon={<Clock className="w-6 h-6" />}
              label="Pending Payment"
              value={stats.pendingPayments.toString()}
              highlight={stats.pendingPayments > 0}
            />
            <StatCard
              icon={<CreditCard className="w-6 h-6" />}
              label="Paid Orders"
              value={stats.paidOrders.toString()}
            />
            <StatCard
              icon={<DollarSign className="w-6 h-6" />}
              label="Revenue"
              value={`$${stats.totalRevenue.toFixed(2)}`}
            />
            <StatCard
              icon={<MessageSquare className="w-6 h-6" />}
              label="Unread Messages"
              value={stats.unreadContacts.toString()}
              highlight={stats.unreadContacts > 0}
            />
          </div>
        )}

        {/* Navigation */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 mb-8">
          {isSuperAdmin && (
            <NavCard href="/admin/orders" icon={<ShoppingCart className="w-5 h-5" />} label="Orders" description="View & manage orders" accent />
          )}
          {isSuperAdmin && (
            <NavCard href="/admin/contacts" icon={<MessageSquare className="w-5 h-5" />} label="Messages" description="Customer enquiries" badge={stats.unreadContacts > 0 ? stats.unreadContacts : undefined} />
          )}
          {isSuperAdmin && (
            <NavCard href="/admin/affiliates" icon={<Handshake className="w-5 h-5" />} label="Affiliates" description="Partners & referrals" />
          )}
          {isSuperAdmin && (
            <NavCard href="/admin/coupons" icon={<Tag className="w-5 h-5" />} label="Coupons" description="Discount codes" />
          )}
          <NavCard href="/admin/blog" icon={<FileText className="w-5 h-5" />} label="Blog Posts" description="Create & edit posts" accent={!isSuperAdmin} />
          <NavCard href="/admin/blog-categories" icon={<FolderOpen className="w-5 h-5" />} label="Categories" description="Organise blog posts" />
          {isSuperAdmin && (
            <NavCard href="/admin/users" icon={<Users className="w-5 h-5" />} label="Users" description="Admin accounts & roles" />
          )}
        </div>

        {/* Recent Orders — Super Admin only */}
        {isSuperAdmin && (
        <div className="bg-navy-800/50 border border-navy-700 rounded-2xl overflow-hidden">
          <div className="p-6 border-b border-navy-700">
            <h2 className="text-xl font-bold text-white">Recent Orders</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-gray-400 text-sm border-b border-navy-700">
                  <th className="px-6 py-4 font-medium">Order</th>
                  <th className="px-6 py-4 font-medium">Customer</th>
                  <th className="px-6 py-4 font-medium">Product</th>
                  <th className="px-6 py-4 font-medium">Amount</th>
                  <th className="px-6 py-4 font-medium">Payment</th>
                  <th className="px-6 py-4 font-medium">Status</th>
                  <th className="px-6 py-4 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order) => (
                  <tr
                    key={order.id}
                    className="border-b border-navy-700/50 hover:bg-navy-800/30"
                  >
                    <td className="px-6 py-4">
                      <span className="font-mono text-white">{order.orderRef}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-white">{order.name}</p>
                        <p className="text-gray-500 text-sm">{order.email}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-300">{order.brokerLabel}</td>
                    <td className="px-6 py-4 text-white font-medium">
                      ${Number(order.price).toFixed(2)}
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                          statusColors[order.paymentStatus]
                        }`}
                      >
                        {statusIcons[order.paymentStatus]}
                        {order.paymentStatus}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                          statusColors[order.status]
                        }`}
                      >
                        {statusIcons[order.status]}
                        {order.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-400 text-sm">
                      {new Date(order.createdAt).toLocaleDateString("en-GB")}
                    </td>
                  </tr>
                ))}
                {recentOrders.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                      No orders yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
        )}
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  highlight = false,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div
      className={`bg-navy-800/50 border rounded-xl p-6 ${
        highlight ? "border-gold-500/50" : "border-navy-700"
      }`}
    >
      <div className={`mb-3 ${highlight ? "text-gold-500" : "text-gray-400"}`}>
        {icon}
      </div>
      <p className="text-2xl font-bold text-white mb-1">{value}</p>
      <p className="text-gray-400 text-sm">{label}</p>
    </div>
  );
}

function NavCard({
  href,
  icon,
  label,
  description,
  accent = false,
  badge,
}: {
  href: string;
  icon: React.ReactNode;
  label: string;
  description: string;
  accent?: boolean;
  badge?: number;
}) {
  return (
    <Link
      href={href}
      className={`group relative flex items-start gap-3 p-4 rounded-xl border transition-all hover:scale-[1.02] ${
        accent
          ? "bg-gold-500/10 border-gold-500/30 hover:border-gold-500/60"
          : "bg-navy-800/50 border-navy-700 hover:border-navy-600"
      }`}
    >
      <div className={`mt-0.5 ${accent ? "text-gold-500" : "text-gray-400 group-hover:text-white transition-colors"}`}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className={`font-semibold text-sm ${accent ? "text-gold-500" : "text-white"}`}>{label}</p>
        <p className="text-xs text-gray-500 mt-0.5">{description}</p>
      </div>
      {badge !== undefined && (
        <span className="absolute top-3 right-3 bg-gold-500 text-navy-950 text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
          {badge}
        </span>
      )}
      <ChevronRight className="w-4 h-4 text-gray-600 group-hover:text-gray-400 mt-0.5 transition-colors flex-shrink-0" />
    </Link>
  );
}
