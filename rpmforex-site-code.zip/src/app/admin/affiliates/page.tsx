"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface Affiliate {
  id: string;
  email: string;
  name: string;
  referralCode: string;
  status: "PENDING" | "APPROVED" | "REJECTED" | "SUSPENDED";
  commissionRate: number;
  totalClicks: number;
  totalOrders: number;
  totalEarnings: number;
  pendingEarnings: number;
  createdAt: string;
}

export default function AdminAffiliatesPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [filter, setFilter] = useState<string>("all");
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const fetchAffiliates = useCallback(async () => {
    try {
      const url =
        filter === "all"
          ? "/api/admin/affiliates"
          : `/api/admin/affiliates?status=${filter}`;
      const res = await fetch(url);

      if (!res.ok) {
        if (res.status === 401) { router.push("/admin/login"); return; }
        if (res.status === 403) { router.push("/admin"); return; }
        throw new Error("Failed to fetch affiliates");
      }

      const data = await res.json();
      setAffiliates(data.affiliates);
    } catch (error) {
      console.error("Error fetching affiliates:", error);
    } finally {
      setLoading(false);
    }
  }, [filter, router]);

  useEffect(() => {
    fetchAffiliates();
  }, [fetchAffiliates]);

  const handleAction = async (id: string, action: string) => {
    setActionLoading(id);
    try {
      const res = await fetch("/api/admin/affiliates", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action }),
      });

      if (res.ok) {
        fetchAffiliates();
      }
    } catch (error) {
      console.error("Error performing action:", error);
    } finally {
      setActionLoading(null);
    }
  };

  const getStatusBadge = (status: Affiliate["status"]) => {
    switch (status) {
      case "APPROVED":
        return (
          <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
            Approved
          </span>
        );
      case "PENDING":
        return (
          <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs rounded-full">
            Pending
          </span>
        );
      case "REJECTED":
        return (
          <span className="px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded-full">
            Rejected
          </span>
        );
      case "SUSPENDED":
        return (
          <span className="px-2 py-1 bg-gray-500/20 text-gray-400 text-xs rounded-full">
            Suspended
          </span>
        );
    }
  };

  const pendingCount = affiliates.filter((a) => a.status === "PENDING").length;

  if (loading) {
    return (
      <div className="min-h-screen bg-navy-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Affiliates</h1>
            <p className="text-gray-400">Manage your affiliate partners</p>
          </div>
          <Link
            href="/admin"
            className="px-4 py-2 bg-navy-700 text-white rounded-lg hover:bg-navy-600 transition-colors"
          >
            Back to Dashboard
          </Link>
        </div>

        {/* Pending Alert */}
        {pendingCount > 0 && (
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 mb-6">
            <p className="text-yellow-400">
              <span className="font-semibold">{pendingCount}</span> affiliate
              application{pendingCount !== 1 && "s"} pending review
            </p>
          </div>
        )}

        {/* Filter Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          {["all", "PENDING", "APPROVED", "REJECTED", "SUSPENDED"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                filter === f
                  ? "bg-gold-500 text-navy-900"
                  : "bg-navy-800 text-gray-400 hover:bg-navy-700"
              }`}
            >
              {f === "all" ? "All" : f.charAt(0) + f.slice(1).toLowerCase()}
            </button>
          ))}
        </div>

        {/* Affiliates Table */}
        <div className="bg-navy-800/50 border border-navy-700 rounded-2xl overflow-hidden">
          {affiliates.length === 0 ? (
            <p className="text-gray-400 text-center py-12">
              No affiliates found
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-gray-400 text-sm border-b border-navy-700">
                    <th className="p-4 font-medium">Affiliate</th>
                    <th className="p-4 font-medium">Status</th>
                    <th className="p-4 font-medium">Code</th>
                    <th className="p-4 font-medium text-right">Clicks</th>
                    <th className="p-4 font-medium text-right">Orders</th>
                    <th className="p-4 font-medium text-right">Earnings</th>
                    <th className="p-4 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-navy-700">
                  {affiliates.map((affiliate) => (
                    <tr key={affiliate.id} className="hover:bg-navy-800/50">
                      <td className="p-4">
                        <p className="text-white font-medium">
                          {affiliate.name}
                        </p>
                        <p className="text-gray-500 text-sm">
                          {affiliate.email}
                        </p>
                      </td>
                      <td className="p-4">{getStatusBadge(affiliate.status)}</td>
                      <td className="p-4">
                        <span className="font-mono text-gold-500 text-sm">
                          {affiliate.referralCode}
                        </span>
                      </td>
                      <td className="p-4 text-right text-gray-300">
                        {affiliate.totalClicks}
                      </td>
                      <td className="p-4 text-right text-gray-300">
                        {affiliate.totalOrders}
                      </td>
                      <td className="p-4 text-right">
                        <p className="text-green-500 font-medium">
                          ${affiliate.totalEarnings.toFixed(2)}
                        </p>
                        {affiliate.pendingEarnings > 0 && (
                          <p className="text-gray-500 text-xs">
                            ${affiliate.pendingEarnings.toFixed(2)} pending
                          </p>
                        )}
                      </td>
                      <td className="p-4">
                        <div className="flex gap-2">
                          {affiliate.status === "PENDING" && (
                            <>
                              <button
                                onClick={() =>
                                  handleAction(affiliate.id, "approve")
                                }
                                disabled={actionLoading === affiliate.id}
                                className="px-3 py-1 bg-green-500/20 text-green-400 text-xs rounded hover:bg-green-500/30 disabled:opacity-50"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() =>
                                  handleAction(affiliate.id, "reject")
                                }
                                disabled={actionLoading === affiliate.id}
                                className="px-3 py-1 bg-red-500/20 text-red-400 text-xs rounded hover:bg-red-500/30 disabled:opacity-50"
                              >
                                Reject
                              </button>
                            </>
                          )}
                          {affiliate.status === "APPROVED" && (
                            <button
                              onClick={() =>
                                handleAction(affiliate.id, "suspend")
                              }
                              disabled={actionLoading === affiliate.id}
                              className="px-3 py-1 bg-gray-500/20 text-gray-400 text-xs rounded hover:bg-gray-500/30 disabled:opacity-50"
                            >
                              Suspend
                            </button>
                          )}
                          {affiliate.status === "SUSPENDED" && (
                            <button
                              onClick={() =>
                                handleAction(affiliate.id, "reactivate")
                              }
                              disabled={actionLoading === affiliate.id}
                              className="px-3 py-1 bg-green-500/20 text-green-400 text-xs rounded hover:bg-green-500/30 disabled:opacity-50"
                            >
                              Reactivate
                            </button>
                          )}
                          <Link
                            href={`/admin/affiliates/${affiliate.id}`}
                            className="px-3 py-1 bg-navy-600 text-gray-300 text-xs rounded hover:bg-navy-500"
                          >
                            Details
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
