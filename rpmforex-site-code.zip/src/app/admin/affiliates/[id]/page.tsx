"use client";

import { useState, useEffect, useCallback, use } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface Affiliate {
  id: string;
  email: string;
  name: string;
  referralCode: string;
  status: "PENDING" | "APPROVED" | "REJECTED" | "SUSPENDED";
  commissionRate: number;
  paymentEmail: string | null;
  paymentMethod: string | null;
  totalClicks: number;
  totalOrders: number;
  totalEarnings: number;
  pendingEarnings: number;
  paidEarnings: number;
  createdAt: string;
}

interface Referral {
  id: string;
  createdAt: string;
  converted: boolean;
  convertedAt: string | null;
  commission: number | null;
  order: {
    orderRef: string;
    price: number;
  } | null;
}

export default function AffiliateDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [affiliate, setAffiliate] = useState<Affiliate | null>(null);
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [commissionRate, setCommissionRate] = useState<number>(20);
  const [actionLoading, setActionLoading] = useState(false);

  const fetchAffiliate = useCallback(async () => {
    try {
      // We need a specific endpoint for getting single affiliate
      // For now, we'll use the list and filter
      const res = await fetch("/api/admin/affiliates");

      if (!res.ok) {
        if (res.status === 401) {
          router.push("/admin/login");
          return;
        }
        throw new Error("Failed to fetch");
      }

      const data = await res.json();
      const found = data.affiliates.find(
        (a: Affiliate) => a.id === id
      );

      if (found) {
        setAffiliate(found);
        setCommissionRate(found.commissionRate);
      }
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  }, [id, router]);

  useEffect(() => {
    fetchAffiliate();
  }, [fetchAffiliate]);

  const handleAction = async (action: string) => {
    setActionLoading(true);
    try {
      const res = await fetch("/api/admin/affiliates", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action }),
      });

      if (res.ok) {
        fetchAffiliate();
      }
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setActionLoading(false);
    }
  };

  const updateCommission = async () => {
    setActionLoading(true);
    try {
      const res = await fetch("/api/admin/affiliates", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id,
          action: "updateCommission",
          commissionRate,
        }),
      });

      if (res.ok) {
        fetchAffiliate();
      }
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setActionLoading(false);
    }
  };

  const getStatusBadge = (status: Affiliate["status"]) => {
    switch (status) {
      case "APPROVED":
        return (
          <span className="px-3 py-1 bg-green-500/20 text-green-400 text-sm rounded-full">
            Approved
          </span>
        );
      case "PENDING":
        return (
          <span className="px-3 py-1 bg-yellow-500/20 text-yellow-400 text-sm rounded-full">
            Pending
          </span>
        );
      case "REJECTED":
        return (
          <span className="px-3 py-1 bg-red-500/20 text-red-400 text-sm rounded-full">
            Rejected
          </span>
        );
      case "SUSPENDED":
        return (
          <span className="px-3 py-1 bg-gray-500/20 text-gray-400 text-sm rounded-full">
            Suspended
          </span>
        );
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-navy-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold-500"></div>
      </div>
    );
  }

  if (!affiliate) {
    return (
      <div className="min-h-screen bg-navy-900 p-6">
        <div className="max-w-4xl mx-auto text-center py-20">
          <p className="text-gray-400">Affiliate not found</p>
          <Link
            href="/admin/affiliates"
            className="text-gold-500 hover:text-gold-400 mt-4 inline-block"
          >
            Back to Affiliates
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold text-white">{affiliate.name}</h1>
              {getStatusBadge(affiliate.status)}
            </div>
            <p className="text-gray-400">{affiliate.email}</p>
          </div>
          <Link
            href="/admin/affiliates"
            className="px-4 py-2 bg-navy-700 text-white rounded-lg hover:bg-navy-600 transition-colors"
          >
            Back to Affiliates
          </Link>
        </div>

        {/* Actions */}
        <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6 mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">Actions</h2>
          <div className="flex flex-wrap gap-3">
            {affiliate.status === "PENDING" && (
              <>
                <button
                  onClick={() => handleAction("approve")}
                  disabled={actionLoading}
                  className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:opacity-50"
                >
                  Approve Application
                </button>
                <button
                  onClick={() => handleAction("reject")}
                  disabled={actionLoading}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 disabled:opacity-50"
                >
                  Reject Application
                </button>
              </>
            )}
            {affiliate.status === "APPROVED" && (
              <button
                onClick={() => handleAction("suspend")}
                disabled={actionLoading}
                className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 disabled:opacity-50"
              >
                Suspend Affiliate
              </button>
            )}
            {affiliate.status === "SUSPENDED" && (
              <button
                onClick={() => handleAction("reactivate")}
                disabled={actionLoading}
                className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 disabled:opacity-50"
              >
                Reactivate Affiliate
              </button>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-4">
            <p className="text-gray-400 text-sm mb-1">Total Clicks</p>
            <p className="text-2xl font-bold text-white">
              {affiliate.totalClicks}
            </p>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-4">
            <p className="text-gray-400 text-sm mb-1">Conversions</p>
            <p className="text-2xl font-bold text-white">
              {affiliate.totalOrders}
            </p>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-4">
            <p className="text-gray-400 text-sm mb-1">Total Earnings</p>
            <p className="text-2xl font-bold text-green-500">
              ${affiliate.totalEarnings.toFixed(2)}
            </p>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-4">
            <p className="text-gray-400 text-sm mb-1">Pending</p>
            <p className="text-2xl font-bold text-gold-500">
              ${affiliate.pendingEarnings.toFixed(2)}
            </p>
          </div>
        </div>

        {/* Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
            <h2 className="text-lg font-semibold text-white mb-4">
              Affiliate Details
            </h2>
            <dl className="space-y-4">
              <div>
                <dt className="text-gray-400 text-sm">Referral Code</dt>
                <dd className="text-gold-500 font-mono text-lg">
                  {affiliate.referralCode}
                </dd>
              </div>
              <div>
                <dt className="text-gray-400 text-sm">Referral Link</dt>
                <dd className="text-gray-300 text-sm font-mono break-all">
                  https://rpmforex.com/?ref={affiliate.referralCode}
                </dd>
              </div>
              <div>
                <dt className="text-gray-400 text-sm">Joined</dt>
                <dd className="text-gray-300">
                  {new Date(affiliate.createdAt).toLocaleDateString("en-GB", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </dd>
              </div>
            </dl>
          </div>

          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
            <h2 className="text-lg font-semibold text-white mb-4">
              Payment Details
            </h2>
            <dl className="space-y-4">
              <div>
                <dt className="text-gray-400 text-sm">Payment Method</dt>
                <dd className="text-gray-300 capitalize">
                  {affiliate.paymentMethod || "Not set"}
                </dd>
              </div>
              <div>
                <dt className="text-gray-400 text-sm">Payment Email</dt>
                <dd className="text-gray-300">
                  {affiliate.paymentEmail || affiliate.email}
                </dd>
              </div>
              <div>
                <dt className="text-gray-400 text-sm">Paid Out</dt>
                <dd className="text-gray-300">
                  ${affiliate.paidEarnings.toFixed(2)}
                </dd>
              </div>
            </dl>
          </div>
        </div>

        {/* Commission Rate */}
        <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            Commission Rate
          </h2>
          <div className="flex items-center gap-4">
            <input
              type="number"
              min="0"
              max="100"
              step="0.5"
              value={commissionRate}
              onChange={(e) => setCommissionRate(parseFloat(e.target.value))}
              className="w-24 px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white text-center"
            />
            <span className="text-gray-400">%</span>
            <button
              onClick={updateCommission}
              disabled={
                actionLoading || commissionRate === affiliate.commissionRate
              }
              className="px-4 py-2 bg-gold-500 text-navy-900 rounded-lg hover:bg-gold-400 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Update
            </button>
          </div>
          <p className="text-gray-500 text-sm mt-2">
            Current rate: {affiliate.commissionRate}%
          </p>
        </div>
      </div>
    </div>
  );
}
