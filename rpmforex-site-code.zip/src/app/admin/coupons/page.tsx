import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { CouponsManager } from "./CouponsManager";

export default async function CouponsPage() {
  const session = await getSession();

  if (!session) {
    redirect("/admin/login");
  }

  if (session.role !== "SUPER_ADMIN") {
    redirect("/admin");
  }

  const rawCoupons = await prisma.coupon.findMany({
    orderBy: { createdAt: "desc" },
  });

  const coupons = rawCoupons.map((coupon) => ({
    ...coupon,
    discountValue: Number(coupon.discountValue),
    minOrderAmount: coupon.minOrderAmount ? Number(coupon.minOrderAmount) : null,
    createdAt: coupon.createdAt.toISOString(),
    updatedAt: coupon.updatedAt.toISOString(),
    expiresAt: coupon.expiresAt ? coupon.expiresAt.toISOString() : null,
  }));

  return <CouponsManager coupons={coupons} />;
}
