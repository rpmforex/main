"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  Plus,
  Tag,
  Percent,
  Hash,
  Clock,
  CheckCircle,
  XCircle,
  Trash2,
  Edit3,
} from "lucide-react";

interface Coupon {
  id: string;
  code: string;
  description: string | null;
  discountType: "FIXED" | "PERCENTAGE";
  discountValue: number;
  maxUses: number | null;
  usedCount: number;
  minOrderAmount: number | null;
  active: boolean;
  expiresAt: string | null;
  createdAt: string;
  updatedAt: string;
}

interface CouponsManagerProps {
  coupons: Coupon[];
}

const emptyForm = {
  code: "",
  description: "",
  discountType: "FIXED" as "FIXED" | "PERCENTAGE",
  discountValue: "",
  maxUses: "",
  minOrderAmount: "",
  expiresAt: "",
  active: true,
};

export function CouponsManager({ coupons: initialCoupons }: CouponsManagerProps) {
  const router = useRouter();
  const [coupons, setCoupons] = useState(initialCoupons);
  const [selectedCoupon, setSelectedCoupon] = useState<Coupon | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function getStatus(coupon: Coupon): { label: string; color: string } {
    if (!coupon.active) return { label: "Inactive", color: "bg-gray-500/10 text-gray-500" };
    if (coupon.expiresAt && new Date(coupon.expiresAt) < new Date()) return { label: "Expired", color: "bg-red-500/10 text-red-500" };
    if (coupon.maxUses !== null && coupon.usedCount >= coupon.maxUses) return { label: "Maxed Out", color: "bg-yellow-500/10 text-yellow-500" };
    return { label: "Active", color: "bg-green-500/10 text-green-500" };
  }

  function startCreate() {
    setSelectedCoupon(null);
    setIsCreating(true);
    setForm(emptyForm);
    setError("");
  }

  function startEdit(coupon: Coupon) {
    setIsCreating(false);
    setSelectedCoupon(coupon);
    setForm({
      code: coupon.code,
      description: coupon.description || "",
      discountType: coupon.discountType,
      discountValue: coupon.discountValue.toString(),
      maxUses: coupon.maxUses?.toString() || "",
      minOrderAmount: coupon.minOrderAmount?.toString() || "",
      expiresAt: coupon.expiresAt ? coupon.expiresAt.slice(0, 16) : "",
      active: coupon.active,
    });
    setError("");
  }

  async function handleSave() {
    setSaving(true);
    setError("");

    try {
      if (isCreating) {
        const res = await fetch("/api/admin/coupons", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            code: form.code,
            description: form.description || null,
            discountType: form.discountType,
            discountValue: Number(form.discountValue),
            maxUses: form.maxUses ? Number(form.maxUses) : null,
            minOrderAmount: form.minOrderAmount ? Number(form.minOrderAmount) : null,
            expiresAt: form.expiresAt || null,
          }),
        });

        const data = await res.json();
        if (!res.ok) {
          setError(data.error || "Failed to create coupon");
          return;
        }

        router.refresh();
        const newCoupon = {
          ...data.coupon,
          discountValue: Number(data.coupon.discountValue),
          minOrderAmount: data.coupon.minOrderAmount ? Number(data.coupon.minOrderAmount) : null,
        };
        setCoupons([newCoupon, ...coupons]);
        setSelectedCoupon(newCoupon);
        setIsCreating(false);
      } else if (selectedCoupon) {
        const res = await fetch("/api/admin/coupons", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            id: selectedCoupon.id,
            code: form.code,
            description: form.description || null,
            discountType: form.discountType,
            discountValue: Number(form.discountValue),
            maxUses: form.maxUses ? Number(form.maxUses) : null,
            minOrderAmount: form.minOrderAmount ? Number(form.minOrderAmount) : null,
            expiresAt: form.expiresAt || null,
            active: form.active,
          }),
        });

        const data = await res.json();
        if (!res.ok) {
          setError(data.error || "Failed to update coupon");
          return;
        }

        const updated = {
          ...data.coupon,
          discountValue: Number(data.coupon.discountValue),
          minOrderAmount: data.coupon.minOrderAmount ? Number(data.coupon.minOrderAmount) : null,
        };
        setCoupons(coupons.map((c) => (c.id === updated.id ? updated : c)));
        setSelectedCoupon(updated);
      }
    } catch {
      setError("An unexpected error occurred");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(couponId: string) {
    if (!confirm("Are you sure you want to delete this coupon?")) return;

    try {
      const res = await fetch("/api/admin/coupons", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: couponId }),
      });

      if (res.ok) {
        setCoupons(coupons.filter((c) => c.id !== couponId));
        setSelectedCoupon(null);
        setIsCreating(false);
        router.refresh();
      }
    } catch {
      setError("Failed to delete coupon");
    }
  }

  async function toggleActive(coupon: Coupon) {
    try {
      const res = await fetch("/api/admin/coupons", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: coupon.id, active: !coupon.active }),
      });

      if (res.ok) {
        const data = await res.json();
        const updated = {
          ...data.coupon,
          discountValue: Number(data.coupon.discountValue),
          minOrderAmount: data.coupon.minOrderAmount ? Number(data.coupon.minOrderAmount) : null,
        };
        setCoupons(coupons.map((c) => (c.id === updated.id ? updated : c)));
        if (selectedCoupon?.id === updated.id) {
          setSelectedCoupon(updated);
          setForm((prev) => ({ ...prev, active: updated.active }));
        }
      }
    } catch {
      // ignore
    }
  }

  return (
    <div className="min-h-screen pt-8 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link
              href="/admin"
              className="text-gray-400 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-white">Coupons</h1>
              <p className="text-gray-400">{coupons.length} coupon{coupons.length !== 1 ? "s" : ""}</p>
            </div>
          </div>
          <button
            onClick={startCreate}
            className="flex items-center gap-2 bg-gold-500 hover:bg-gold-400 text-navy-950 px-4 py-2 rounded-lg font-semibold transition-colors"
          >
            <Plus className="w-4 h-4" />
            New Coupon
          </button>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Coupon List */}
          <div className="lg:col-span-1 space-y-3">
            {coupons.length === 0 && !isCreating && (
              <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-8 text-center">
                <Tag className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                <p className="text-gray-500">No coupons yet</p>
                <button
                  onClick={startCreate}
                  className="text-gold-500 hover:text-gold-400 text-sm mt-2"
                >
                  Create your first coupon
                </button>
              </div>
            )}
            {coupons.map((coupon) => {
              const status = getStatus(coupon);
              return (
                <button
                  key={coupon.id}
                  onClick={() => startEdit(coupon)}
                  className={`w-full text-left bg-navy-800/50 border rounded-xl p-4 transition-colors ${
                    selectedCoupon?.id === coupon.id
                      ? "border-gold-500"
                      : "border-navy-700 hover:border-navy-600"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono font-bold text-white">{coupon.code}</span>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${status.color}`}>
                      {status.label}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gold-500 font-medium">
                      {coupon.discountType === "FIXED"
                        ? `$${coupon.discountValue.toFixed(2)} off`
                        : `${coupon.discountValue}% off`}
                    </span>
                    <span className="text-gray-500">
                      {coupon.usedCount} used{coupon.maxUses ? ` / ${coupon.maxUses}` : ""}
                    </span>
                  </div>
                  {coupon.description && (
                    <p className="text-gray-500 text-xs mt-1 truncate">{coupon.description}</p>
                  )}
                </button>
              );
            })}
          </div>

          {/* Detail / Form Panel */}
          <div className="lg:col-span-2">
            {!selectedCoupon && !isCreating ? (
              <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-12 text-center">
                <Tag className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-500 text-lg">Select a coupon to edit or create a new one</p>
              </div>
            ) : (
              <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    {isCreating ? (
                      <>
                        <Plus className="w-5 h-5 text-gold-500" />
                        Create Coupon
                      </>
                    ) : (
                      <>
                        <Edit3 className="w-5 h-5 text-gold-500" />
                        Edit Coupon
                      </>
                    )}
                  </h2>
                  {selectedCoupon && (
                    <button
                      onClick={() => handleDelete(selectedCoupon.id)}
                      className="flex items-center gap-1 text-red-400 hover:text-red-300 text-sm"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete
                    </button>
                  )}
                </div>

                {error && (
                  <div className="flex items-center gap-2 text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg p-3 mb-4">
                    <XCircle className="w-4 h-4 flex-shrink-0" />
                    <p className="text-sm">{error}</p>
                  </div>
                )}

                <div className="space-y-4">
                  {/* Code */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      Coupon Code *
                    </label>
                    <div className="flex items-center gap-2">
                      <Hash className="w-4 h-4 text-gray-500" />
                      <input
                        type="text"
                        value={form.code}
                        onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })}
                        placeholder="e.g. SAVE50"
                        className="flex-1 px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent uppercase font-mono"
                      />
                    </div>
                  </div>

                  {/* Description */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      Description (admin only)
                    </label>
                    <input
                      type="text"
                      value={form.description}
                      onChange={(e) => setForm({ ...form, description: e.target.value })}
                      placeholder="e.g. Launch promotion - 50% off"
                      className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                    />
                  </div>

                  {/* Discount Type + Value */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Discount Type *
                      </label>
                      <select
                        value={form.discountType}
                        onChange={(e) => setForm({ ...form, discountType: e.target.value as "FIXED" | "PERCENTAGE" })}
                        className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                      >
                        <option value="FIXED">Fixed Amount ($)</option>
                        <option value="PERCENTAGE">Percentage (%)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        {form.discountType === "FIXED" ? "Amount ($) *" : "Percentage (%) *"}
                      </label>
                      <div className="flex items-center gap-2">
                        {form.discountType === "FIXED" ? (
                          <span className="text-gray-500">$</span>
                        ) : (
                          <Percent className="w-4 h-4 text-gray-500" />
                        )}
                        <input
                          type="number"
                          step={form.discountType === "FIXED" ? "0.01" : "1"}
                          min="0"
                          max={form.discountType === "PERCENTAGE" ? "100" : undefined}
                          value={form.discountValue}
                          onChange={(e) => setForm({ ...form, discountValue: e.target.value })}
                          placeholder={form.discountType === "FIXED" ? "50.00" : "25"}
                          className="flex-1 px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Constraints */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Max Uses (leave blank for unlimited)
                      </label>
                      <input
                        type="number"
                        min="0"
                        value={form.maxUses}
                        onChange={(e) => setForm({ ...form, maxUses: e.target.value })}
                        placeholder="Unlimited"
                        className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Min Order Amount ($)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={form.minOrderAmount}
                        onChange={(e) => setForm({ ...form, minOrderAmount: e.target.value })}
                        placeholder="No minimum"
                        className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  {/* Expiry */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      <Clock className="w-3 h-3 inline mr-1" />
                      Expires At (leave blank for no expiry)
                    </label>
                    <input
                      type="datetime-local"
                      value={form.expiresAt}
                      onChange={(e) => setForm({ ...form, expiresAt: e.target.value })}
                      className="w-full px-3 py-2 bg-navy-900 border border-navy-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                    />
                  </div>

                  {/* Active Toggle (edit only) */}
                  {!isCreating && (
                    <div className="flex items-center justify-between bg-navy-900 rounded-lg p-3 border border-navy-700">
                      <div>
                        <span className="text-white font-medium">Active</span>
                        <p className="text-gray-500 text-xs">Customers can use this coupon</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setForm({ ...form, active: !form.active })}
                        className={`relative w-12 h-6 rounded-full transition-colors ${
                          form.active ? "bg-green-500" : "bg-navy-700"
                        }`}
                      >
                        <span
                          className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                            form.active ? "left-7" : "left-1"
                          }`}
                        />
                      </button>
                    </div>
                  )}

                  {/* Usage Stats (edit only) */}
                  {selectedCoupon && !isCreating && (
                    <div className="bg-navy-900 rounded-lg p-4 border border-navy-700">
                      <h3 className="text-sm font-medium text-gray-400 mb-3">Usage Stats</h3>
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <p className="text-2xl font-bold text-white">{selectedCoupon.usedCount}</p>
                          <p className="text-xs text-gray-500">Times Used</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-white">
                            {selectedCoupon.maxUses ?? "∞"}
                          </p>
                          <p className="text-xs text-gray-500">Max Uses</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-white">
                            {selectedCoupon.maxUses
                              ? Math.max(0, selectedCoupon.maxUses - selectedCoupon.usedCount)
                              : "∞"}
                          </p>
                          <p className="text-xs text-gray-500">Remaining</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Save Button */}
                  <button
                    onClick={handleSave}
                    disabled={saving || !form.code || !form.discountValue}
                    className="w-full flex items-center justify-center gap-2 bg-gold-500 hover:bg-gold-400 text-navy-950 px-6 py-3 rounded-lg font-semibold transition-colors disabled:opacity-50"
                  >
                    {saving ? (
                      "Saving..."
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4" />
                        {isCreating ? "Create Coupon" : "Save Changes"}
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
