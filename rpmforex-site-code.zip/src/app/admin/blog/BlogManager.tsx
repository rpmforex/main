"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  Plus,
  Trash2,
  Search,
  Clock,
  FileText,
  Eye,
  Archive,
  Pencil,
  Upload,
  Loader2,
} from "lucide-react";
import { TipTapEditor } from "@/components/blog/TipTapEditor";
import { SEOPanel } from "@/components/blog/SEOPanel";

interface Post {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  featuredImage: string | null;
  status: string;
  publishedAt: string | null;
  categoryId: string | null;
  category: { id: string; name: string } | null;
  metaTitle: string | null;
  metaDescription: string | null;
  ogImage: string | null;
  canonicalUrl: string | null;
  readingTime: number;
  createdAt: string;
  updatedAt: string;
}

interface Category {
  id: string;
  name: string;
  slug: string;
}

const emptyForm = {
  title: "",
  slug: "",
  content: "",
  excerpt: "",
  featuredImage: "",
  status: "DRAFT",
  publishedAt: "",
  categoryId: "",
  metaTitle: "",
  metaDescription: "",
  ogImage: "",
  canonicalUrl: "",
};

const statusConfig: Record<string, { label: string; color: string; icon: typeof FileText }> = {
  DRAFT: { label: "Draft", color: "bg-yellow-500/20 text-yellow-400", icon: FileText },
  PUBLISHED: { label: "Published", color: "bg-green-500/20 text-green-400", icon: Eye },
  ARCHIVED: { label: "Archived", color: "bg-gray-500/20 text-gray-400", icon: Archive },
};

function generateSlugFromTitle(title: string): string {
  return title
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

export function BlogManager({
  initialPosts,
  categories,
}: {
  initialPosts: Post[];
  categories: Category[];
}) {
  const router = useRouter();
  const [posts, setPosts] = useState(initialPosts);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [slugManual, setSlugManual] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState<"content" | "seo">("content");
  const [filterStatus, setFilterStatus] = useState("");
  const [search, setSearch] = useState("");
  const [uploadingFeatured, setUploadingFeatured] = useState(false);

  const updateForm = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleTitleChange = (title: string) => {
    updateForm("title", title);
    if (isCreating && !slugManual) {
      updateForm("slug", generateSlugFromTitle(title));
    }
  };

  const handleContentChange = useCallback((html: string) => {
    setForm((prev) => ({ ...prev, content: html }));
  }, []);

  const startCreate = () => {
    setSelectedPost(null);
    setIsCreating(true);
    setForm(emptyForm);
    setSlugManual(false);
    setActiveTab("content");
    setError("");
  };

  const startEdit = (post: Post) => {
    setIsCreating(false);
    setSelectedPost(post);
    setForm({
      title: post.title,
      slug: post.slug,
      content: post.content,
      excerpt: post.excerpt || "",
      featuredImage: post.featuredImage || "",
      status: post.status,
      publishedAt: post.publishedAt ? post.publishedAt.slice(0, 16) : "",
      categoryId: post.categoryId || "",
      metaTitle: post.metaTitle || "",
      metaDescription: post.metaDescription || "",
      ogImage: post.ogImage || "",
      canonicalUrl: post.canonicalUrl || "",
    });
    setSlugManual(true);
    setActiveTab("content");
    setError("");
  };

  const handleSave = async () => {
    if (!form.title.trim()) { setError("Title is required"); return; }
    if (!form.content.trim() || form.content === "<p></p>") { setError("Content is required"); return; }
    setSaving(true);
    setError("");

    try {
      const method = isCreating ? "POST" : "PATCH";
      const body = isCreating
        ? { ...form, categoryId: form.categoryId || null, publishedAt: form.publishedAt || null }
        : { id: selectedPost!.id, ...form, categoryId: form.categoryId || null, publishedAt: form.publishedAt || null };

      const res = await fetch("/api/admin/blog", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      const savedPost: Post = {
        ...data.post,
        publishedAt: data.post.publishedAt ?? null,
        createdAt: data.post.createdAt ?? new Date().toISOString(),
        updatedAt: data.post.updatedAt ?? new Date().toISOString(),
      };

      if (isCreating) {
        setPosts([savedPost, ...posts]);
        setIsCreating(false);
        setSelectedPost(savedPost);
        setSlugManual(true);
      } else {
        setPosts(posts.map((p) => (p.id === savedPost.id ? savedPost : p)));
        setSelectedPost(savedPost);
      }

      // Update the slug in form in case it was auto-adjusted for uniqueness
      setForm((prev) => ({ ...prev, slug: savedPost.slug }));
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedPost) return;
    if (!confirm(`Delete "${selectedPost.title}"? This cannot be undone.`)) return;

    try {
      const res = await fetch("/api/admin/blog", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: selectedPost.id }),
      });
      if (!res.ok) throw new Error("Failed to delete");

      setPosts(posts.filter((p) => p.id !== selectedPost.id));
      setSelectedPost(null);
      setIsCreating(false);
      router.refresh();
    } catch {
      setError("Failed to delete post");
    }
  };

  const filteredPosts = posts.filter((post) => {
    if (filterStatus && post.status !== filterStatus) return false;
    if (search) {
      const q = search.toLowerCase();
      return post.title.toLowerCase().includes(q) || post.slug.toLowerCase().includes(q);
    }
    return true;
  });

  const wordCount = form.content.replace(/<[^>]*>/g, "").trim().split(/\s+/).filter(Boolean).length;
  const readingTime = Math.max(1, Math.ceil(wordCount / 200));

  return (
    <div className="min-h-screen bg-navy-950 p-4 md:p-8">
      <div className="max-w-[1600px] mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Link href="/admin" className="text-gray-400 hover:text-white transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-2xl font-bold text-white">Blog Posts</h1>
          <Link
            href="/admin/blog-categories"
            className="ml-auto text-sm text-gold-500 hover:text-gold-400 transition-colors"
          >
            Manage Categories →
          </Link>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Post List */}
          <div className="lg:col-span-1 space-y-3">
            <button
              onClick={startCreate}
              className="w-full flex items-center justify-center gap-2 bg-gold-500 hover:bg-gold-400 text-navy-950 font-semibold py-3 rounded-lg transition-colors"
            >
              <Plus className="w-5 h-5" /> New Post
            </button>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                placeholder="Search posts..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-navy-900 border border-navy-700 rounded-lg pl-10 pr-3 py-2 text-white text-sm placeholder-gray-500 focus:border-gold-500 focus:outline-none"
              />
            </div>

            <div className="flex gap-1">
              {["", "DRAFT", "PUBLISHED", "ARCHIVED"].map((s) => (
                <button
                  key={s}
                  onClick={() => setFilterStatus(s)}
                  className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                    filterStatus === s
                      ? "bg-gold-500 text-navy-950"
                      : "bg-navy-800 text-gray-400 hover:text-white"
                  }`}
                >
                  {s || "All"}
                </button>
              ))}
            </div>

            <div className="space-y-2 max-h-[calc(100vh-280px)] overflow-y-auto">
              {filteredPosts.length === 0 && (
                <p className="text-gray-500 text-center py-8">No posts found</p>
              )}
              {filteredPosts.map((post) => {
                const cfg = statusConfig[post.status] || statusConfig.DRAFT;
                return (
                  <div
                    key={post.id}
                    onClick={() => startEdit(post)}
                    className={`p-3 rounded-xl border cursor-pointer transition-colors ${
                      selectedPost?.id === post.id
                        ? "bg-navy-800/80 border-gold-500"
                        : "bg-navy-800/30 border-navy-700 hover:border-navy-600"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-white text-sm font-medium line-clamp-2">{post.title}</h3>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${cfg.color}`}>
                        {cfg.label}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                      {post.category && <span>{post.category.name}</span>}
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {post.readingTime} min
                      </span>
                      <span>
                        {new Date(post.publishedAt || post.createdAt).toLocaleDateString("en-GB", {
                          day: "numeric",
                          month: "short",
                        })}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Editor Panel */}
          <div className="lg:col-span-2">
            {isCreating || selectedPost ? (
              <div className="bg-navy-800/30 border border-navy-700 rounded-2xl p-6 space-y-4">
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Pencil className="w-5 h-5 text-gold-500" />
                    <span className="text-white font-semibold">
                      {isCreating ? "New Post" : "Edit Post"}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>{wordCount} words</span>
                    <span>{readingTime} min read</span>
                    {selectedPost && (
                      <button
                        onClick={handleDelete}
                        className="p-1.5 text-red-400 hover:text-red-300 hover:bg-red-400/10 rounded-lg transition-colors"
                        title="Delete post"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {error && (
                  <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
                    {error}
                  </div>
                )}

                {/* Tabs */}
                <div className="flex gap-1 bg-navy-900 rounded-lg p-1">
                  <button
                    onClick={() => setActiveTab("content")}
                    className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === "content"
                        ? "bg-navy-700 text-white"
                        : "text-gray-400 hover:text-white"
                    }`}
                  >
                    Content
                  </button>
                  <button
                    onClick={() => setActiveTab("seo")}
                    className={`flex-1 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === "seo"
                        ? "bg-navy-700 text-white"
                        : "text-gray-400 hover:text-white"
                    }`}
                  >
                    SEO
                  </button>
                </div>

                {activeTab === "content" ? (
                  <div className="space-y-4">
                    {/* Title */}
                    <input
                      type="text"
                      value={form.title}
                      onChange={(e) => handleTitleChange(e.target.value)}
                      placeholder="Post title"
                      className="w-full bg-navy-900 border border-navy-700 rounded-lg px-4 py-3 text-white text-xl font-bold placeholder-gray-500 focus:border-gold-500 focus:outline-none"
                    />

                    {/* Slug */}
                    <div className="flex items-center gap-2">
                      <span className="text-gray-500 text-sm">/blog/</span>
                      <input
                        type="text"
                        value={form.slug}
                        onChange={(e) => {
                          setSlugManual(true);
                          updateForm("slug", e.target.value);
                        }}
                        className="flex-1 bg-navy-900 border border-navy-700 rounded-lg px-3 py-1.5 text-gray-300 text-sm focus:border-gold-500 focus:outline-none"
                      />
                    </div>

                    {/* Meta row: category, status, date */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div>
                        <label className="text-xs text-gray-500 block mb-1">Category</label>
                        <select
                          value={form.categoryId}
                          onChange={(e) => updateForm("categoryId", e.target.value)}
                          className="w-full bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white text-sm focus:border-gold-500 focus:outline-none"
                        >
                          <option value="">No category</option>
                          {categories.map((cat) => (
                            <option key={cat.id} value={cat.id}>{cat.name}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 block mb-1">Status</label>
                        <select
                          value={form.status}
                          onChange={(e) => updateForm("status", e.target.value)}
                          className="w-full bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white text-sm focus:border-gold-500 focus:outline-none"
                        >
                          <option value="DRAFT">Draft</option>
                          <option value="PUBLISHED">Published</option>
                          <option value="ARCHIVED">Archived</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 block mb-1">Publish Date</label>
                        <input
                          type="datetime-local"
                          value={form.publishedAt}
                          onChange={(e) => updateForm("publishedAt", e.target.value)}
                          className="w-full bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white text-sm focus:border-gold-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Featured Image */}
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">Featured Image</label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={form.featuredImage}
                          onChange={(e) => updateForm("featuredImage", e.target.value)}
                          placeholder="https://... or upload"
                          className="flex-1 bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white text-sm placeholder-gray-500 focus:border-gold-500 focus:outline-none"
                        />
                        <label className="flex items-center gap-2 px-4 py-2 bg-navy-700 hover:bg-navy-600 text-white text-sm rounded-lg cursor-pointer transition-colors">
                          {uploadingFeatured ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Upload className="w-4 h-4" />
                          )}
                          Upload
                          <input
                            type="file"
                            accept="image/jpeg,image/png,image/webp,image/gif"
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              e.target.value = "";
                              setUploadingFeatured(true);
                              try {
                                const formData = new FormData();
                                formData.append("file", file);
                                const res = await fetch("/api/admin/blog/upload", { method: "POST", body: formData });
                                const data = await res.json();
                                if (!res.ok) throw new Error(data.error);
                                updateForm("featuredImage", data.url);
                              } catch (err) {
                                setError(err instanceof Error ? err.message : "Upload failed");
                              } finally {
                                setUploadingFeatured(false);
                              }
                            }}
                          />
                        </label>
                      </div>
                      {form.featuredImage && (
                        <img
                          src={form.featuredImage}
                          alt="Preview"
                          className="mt-2 h-32 rounded-lg object-cover border border-navy-700"
                          onError={(e) => (e.currentTarget.style.display = "none")}
                        />
                      )}
                    </div>

                    {/* Excerpt */}
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">
                        Excerpt <span className="text-gray-600">(auto-generated if empty)</span>
                      </label>
                      <textarea
                        value={form.excerpt}
                        onChange={(e) => updateForm("excerpt", e.target.value)}
                        rows={2}
                        maxLength={300}
                        placeholder="Brief description for post cards and meta..."
                        className="w-full bg-navy-900 border border-navy-700 rounded-lg px-3 py-2 text-white text-sm placeholder-gray-500 focus:border-gold-500 focus:outline-none resize-none"
                      />
                    </div>

                    {/* Editor */}
                    <TipTapEditor
                      key={selectedPost?.id || "new"}
                      content={form.content}
                      onChange={handleContentChange}
                    />
                  </div>
                ) : (
                  <SEOPanel
                    metaTitle={form.metaTitle}
                    metaDescription={form.metaDescription}
                    ogImage={form.ogImage}
                    canonicalUrl={form.canonicalUrl}
                    slug={form.slug}
                    postTitle={form.title}
                    excerpt={form.excerpt}
                    onChange={(field, value) => updateForm(field, value)}
                  />
                )}

                {/* Save button */}
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="w-full bg-gold-500 hover:bg-gold-400 text-navy-950 font-semibold py-3 rounded-lg transition-colors disabled:opacity-50"
                >
                  {saving
                    ? "Saving..."
                    : isCreating
                    ? form.status === "PUBLISHED"
                      ? "Publish Post"
                      : "Save Draft"
                    : "Update Post"}
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-96 text-gray-500">
                <FileText className="w-12 h-12 mb-3 text-gray-600" />
                <p>Select a post to edit or create a new one</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
