import { Metadata } from "next";
import { Section, SectionHeader } from "@/components/Section";
import { Button } from "@/components/Button";
import {
  ArrowRight,
  BarChart3,
  Eye,
  BadgeCheck,
  Headphones,
  Users,
  RefreshCw,
  Target,
  TrendingUp,
} from "lucide-react";

export const metadata: Metadata = {
  title: "About RPM Forex",
  description:
    "Learn about RPM Forex — who we are, our mission, and why traders trust our automated gold trading system.",
  keywords: [
    "RPM Forex",
    "automated gold trading bot",
    "forex trading",
    "gold trading",
    "trading bot",
    "XAUUSD",
    "expert advisor",
  ],
};

const trustPillars = [
  {
    icon: BarChart3,
    title: "Verified Results",
    description:
      "All trading performance is independently verified on MyFXBook. No inflated claims — just real, auditable data.",
  },
  {
    icon: Eye,
    title: "Full Transparency",
    description:
      "We publish every trade, every result. You can see exactly how our bot performs before you invest a penny.",
  },
  {
    icon: BadgeCheck,
    title: "Money-Back Guarantee",
    description:
      "Every purchase is fully refundable. If you're not satisfied, contact us within 30 days for a complete refund.",
  },
  {
    icon: Headphones,
    title: "Dedicated Support",
    description:
      "Our team is available via email, WhatsApp, and Telegram to help with setup, questions, and ongoing support.",
  },
  {
    icon: Users,
    title: "Growing Community",
    description:
      "Join our active Telegram group where traders share experiences, tips, and results with each other.",
  },
  {
    icon: RefreshCw,
    title: "Continuous Development",
    description:
      "The bot is regularly updated and optimised to adapt to changing market conditions. All updates are free for life.",
  },
];

export default function AboutUsPage() {
  return (
    <>
      {/* Hero */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-navy-900/50 to-navy-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              About <span className="text-gold-500">RPM Forex</span>
            </h1>
            <p className="text-xl text-gray-300">
              Built by traders, for traders. We&apos;re on a mission to make
              professional-grade gold trading accessible to everyone.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <Section>
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <Target className="w-6 h-6 text-gold-500" />
              <span className="text-gold-500 font-semibold uppercase tracking-wide text-sm">
                Our Story
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              From Traders Who Understand the Market
            </h2>
            <div className="space-y-4 text-gray-400 text-lg">
              <p>
                RPM Forex was born out of years of hands-on experience in the
                forex and commodities markets. We know first-hand how
                challenging it can be to trade consistently — the long hours, the
                emotional decisions, and the constant pressure of watching the
                charts.
              </p>
              <p>
                That&apos;s why we built our automated trading system. We wanted
                to create something that could deliver the kind of results
                experienced traders achieve, but without requiring users to be
                glued to their screens 24/7.
              </p>
              <p>
                Today, RPM Forex powers automated gold trading for a growing
                community of traders who trust our system to work for them —
                day and night.
              </p>
            </div>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-6">
              <TrendingUp className="w-6 h-6 text-gold-500" />
              <h3 className="text-xl font-bold text-white">What Drives Us</h3>
            </div>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">Transparency First</span>
                  <p className="text-gray-400 text-sm">
                    Every result verified independently on MyFXBook
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">Accessible to Everyone</span>
                  <p className="text-gray-400 text-sm">
                    No experience required — our bot does the work
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">Risk Management Built-In</span>
                  <p className="text-gray-400 text-sm">
                    Protecting your capital is our top priority
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">Community-Driven</span>
                  <p className="text-gray-400 text-sm">
                    Active Telegram group with real traders helping each other
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </Section>

      {/* Why Trust Us */}
      <Section className="bg-navy-900/50">
        <SectionHeader
          title="Why Traders Trust RPM Forex"
          subtitle="We believe trust is earned, not claimed. Here's how we back it up."
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trustPillars.map((pillar) => (
            <div
              key={pillar.title}
              className="bg-navy-800/50 border border-navy-700 rounded-xl p-6"
            >
              <div className="w-12 h-12 bg-gold-500/10 rounded-lg flex items-center justify-center mb-4">
                <pillar.icon className="w-6 h-6 text-gold-500" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                {pillar.title}
              </h3>
              <p className="text-gray-400">{pillar.description}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA */}
      <Section>
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
            Join the growing community of traders using RPM Forex to automate
            their gold trading. We&apos;re here to help every step of the way.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button href="/buy" size="lg">
              Get RPM Gold Bot <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button href="/contact" variant="secondary" size="lg">
              Contact Us
            </Button>
          </div>
        </div>
      </Section>
    </>
  );
}
