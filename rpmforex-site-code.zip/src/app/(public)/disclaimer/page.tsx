import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Risk Disclaimer",
  description: "Important risk disclaimer for RPM Forex products and services.",
};

export default function DisclaimerPage() {
  return (
    <div className="pt-32 pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-white mb-8">Risk Disclaimer</h1>
        <div className="prose prose-invert prose-gold max-w-none">
          <p className="text-gray-400 mb-6">Last updated: December 2024</p>

          <div className="space-y-8 text-gray-300">
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-6">
              <h2 className="text-xl font-semibold text-red-400 mb-4">Important Risk Warning</h2>
              <p className="text-red-300">
                Trading Derivatives carries a high level of risk to your capital and you should only trade with money you can afford to lose as it can result in the loss of your invested capital in extreme cases. Trading Derivatives may not be suitable for all investors, so please ensure that you fully understand the risks involved and seek independent advice if necessary.
              </p>
            </div>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">Trading Risk Disclosure</h2>
              <p className="mb-4">
                Trading foreign exchange (Forex), commodities, and other financial instruments on margin carries a high level of risk and may not be suitable for all investors. Before deciding to trade, you should carefully consider your investment objectives, level of experience, and risk appetite.
              </p>
              <p>
                The possibility exists that you could sustain a loss of some or all of your initial investment. Therefore, you should not invest money that you cannot afford to lose.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">No Guaranteed Returns</h2>
              <p className="mb-4">
                Past performance is not indicative of future results. The trading results displayed on our website and marketing materials represent historical performance and do not guarantee future results.
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>There is no guarantee that the Bot will produce profits</li>
                <li>Market conditions change and past strategies may not work in the future</li>
                <li>Drawdowns and losing periods are a normal part of trading</li>
                <li>Individual results will vary based on account size, broker, and market conditions</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">Automated Trading Risks</h2>
              <p className="mb-4">
                While automated trading systems (Expert Advisors) can help remove emotional decision-making, they carry specific risks:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Technical failures, internet connectivity issues, or power outages can affect trading</li>
                <li>Broker execution speeds and slippage can impact results</li>
                <li>Market conditions outside the Bot&apos;s designed parameters can cause losses</li>
                <li>Software bugs or updates may affect performance</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">Leverage Warning</h2>
              <p>
                The high degree of leverage that is often obtainable in forex trading can work against you as well as for you. The use of leverage can lead to large losses as well as gains. You must be aware of the risks and be willing to accept them in order to invest in the forex markets.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">Not Financial Advice</h2>
              <p className="mb-4">
                The information provided on this website and through our products is for educational and informational purposes only. It should not be construed as:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Personal financial advice</li>
                <li>Investment recommendations</li>
                <li>An offer or solicitation to buy or sell any financial instrument</li>
                <li>Tax, legal, or accounting advice</li>
              </ul>
              <p className="mt-4">
                We strongly recommend that you seek advice from a qualified financial advisor before making any investment decisions.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">Regulatory Notice</h2>
              <p>
                RPM Forex is not a regulated financial institution. We provide trading software tools only. We do not manage client funds, provide trading signals as investment advice, or offer any form of managed account services.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">Your Responsibility</h2>
              <p>
                By purchasing and using our products, you acknowledge that you have read and understood this disclaimer, and you accept full responsibility for your trading decisions and any resulting profits or losses.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">Contact</h2>
              <p>
                If you have any questions about this disclaimer, please contact us at:
              </p>
              <p className="mt-2">
                Email: <a href="mailto:info@rpmforex.com" className="text-gold-500 hover:text-gold-400">info@rpmforex.com</a>
              </p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
