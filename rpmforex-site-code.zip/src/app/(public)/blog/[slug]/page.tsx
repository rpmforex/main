import { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { Section, SectionHeader } from "@/components/Section";
import { Button } from "@/components/Button";
import { BlogContent } from "@/components/blog/BlogContent";
import { PostCard } from "@/components/blog/PostCard";
import { ArrowRight, ArrowLeft, Clock, Tag } from "lucide-react";

interface PostPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PostPageProps): Promise<Metadata> {
  const { slug } = await params;
  const post = await prisma.blogPost.findUnique({
    where: { slug },
    select: {
      title: true,
      metaTitle: true,
      metaDescription: true,
      excerpt: true,
      ogImage: true,
      featuredImage: true,
      canonicalUrl: true,
      publishedAt: true,
    },
  });

  if (!post) return { title: "Post Not Found" };

  const title = post.metaTitle || post.title;
  const description = post.metaDescription || post.excerpt || "";
  const image = post.ogImage || post.featuredImage;

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      type: "article",
      publishedTime: post.publishedAt?.toISOString(),
      ...(image && { images: [{ url: image, width: 1200, height: 630 }] }),
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      ...(image && { images: [image] }),
    },
    ...(post.canonicalUrl && {
      alternates: { canonical: post.canonicalUrl },
    }),
  };
}

export const revalidate = 60;

export default async function BlogPostPage({ params }: PostPageProps) {
  const { slug } = await params;
  const now = new Date();

  const post = await prisma.blogPost.findUnique({
    where: { slug },
    include: { category: { select: { name: true, slug: true } } },
  });

  if (
    !post ||
    post.status !== "PUBLISHED" ||
    !post.publishedAt ||
    post.publishedAt > now
  ) {
    notFound();
  }

  // Related posts
  const relatedPosts = post.categoryId
    ? await prisma.blogPost.findMany({
        where: {
          status: "PUBLISHED",
          publishedAt: { lte: now },
          categoryId: post.categoryId,
          id: { not: post.id },
        },
        take: 3,
        orderBy: { publishedAt: "desc" },
        select: {
          title: true,
          slug: true,
          excerpt: true,
          featuredImage: true,
          publishedAt: true,
          readingTime: true,
          category: { select: { name: true, slug: true } },
        },
      })
    : [];

  const serializedRelated = relatedPosts.map((p) => ({
    ...p,
    publishedAt: p.publishedAt?.toISOString() ?? null,
  }));

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    description: post.metaDescription || post.excerpt || "",
    image: post.ogImage || post.featuredImage || undefined,
    datePublished: post.publishedAt.toISOString(),
    dateModified: post.updatedAt.toISOString(),
    author: {
      "@type": "Organization",
      name: "RPM Forex",
      url: "https://rpmforex.com",
    },
    publisher: {
      "@type": "Organization",
      name: "RPM Forex",
      logo: {
        "@type": "ImageObject",
        url: "https://rpmforex.com/images/rpm-forex-logo.jpeg",
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": `https://rpmforex.com/blog/${post.slug}`,
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/* Hero */}
      <section className="pt-32 pb-12 bg-gradient-to-b from-navy-900/50 to-navy-950">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link
            href="/blog"
            className="inline-flex items-center gap-1 text-gray-400 hover:text-gold-500 text-sm mb-6 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Blog
          </Link>

          <div className="flex items-center gap-4 mb-4">
            {post.category && (
              <Link
                href={`/blog?category=${post.category.slug}`}
                className="flex items-center gap-1 text-gold-500 text-sm font-medium hover:text-gold-400"
              >
                <Tag className="w-3 h-3" />
                {post.category.name}
              </Link>
            )}
            <span className="flex items-center gap-1 text-gray-500 text-sm">
              <Clock className="w-3 h-3" />
              {post.readingTime} min read
            </span>
          </div>

          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
            {post.title}
          </h1>

          <time
            dateTime={post.publishedAt.toISOString()}
            className="text-gray-400 text-sm"
          >
            {post.publishedAt.toLocaleDateString("en-GB", {
              day: "numeric",
              month: "long",
              year: "numeric",
            })}
          </time>
        </div>
      </section>

      {/* Featured image */}
      {post.featuredImage && (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 -mt-4 mb-8">
          <img
            src={post.featuredImage}
            alt={post.title}
            className="w-full rounded-2xl border border-navy-700"
          />
        </div>
      )}

      {/* Content */}
      <Section className="!pt-4">
        <div className="max-w-4xl mx-auto">
          <BlogContent html={post.content} />
        </div>
      </Section>

      {/* Related posts */}
      {serializedRelated.length > 0 && (
        <Section className="bg-navy-900/50">
          <SectionHeader title="Related Posts" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {serializedRelated.map((related) => (
              <PostCard key={related.slug} post={related} />
            ))}
          </div>
        </Section>
      )}

      {/* CTA */}
      <Section>
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Start Trading?
          </h2>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
            Put these insights into practice with RPM Forex&apos;s automated
            gold trading system.
          </p>
          <Button href="/buy" size="lg">
            Get Started <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </Section>
    </>
  );
}
