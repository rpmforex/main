"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { PostCard } from "@/components/blog/PostCard";
import { BlogPagination } from "@/components/blog/BlogPagination";

interface Post {
  title: string;
  slug: string;
  excerpt: string | null;
  featuredImage: string | null;
  publishedAt: string | null;
  readingTime: number;
  category: { name: string; slug: string } | null;
}

interface BlogListClientProps {
  posts: Post[];
  categories: { name: string; slug: string }[];
  currentCategory: string | null;
  currentPage: number;
  totalPages: number;
}

export function BlogListClient({
  posts,
  categories,
  currentCategory,
  currentPage,
  totalPages,
}: BlogListClientProps) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const setCategory = (slug: string | null) => {
    const params = new URLSearchParams(searchParams.toString());
    if (slug) {
      params.set("category", slug);
    } else {
      params.delete("category");
    }
    params.delete("page");
    const query = params.toString();
    router.push(`/blog${query ? `?${query}` : ""}`);
  };

  return (
    <div>
      {/* Category filters */}
      {categories.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-8">
          <button
            onClick={() => setCategory(null)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              !currentCategory
                ? "bg-gold-500 text-navy-950"
                : "bg-navy-800 text-gray-400 hover:text-white border border-navy-700"
            }`}
          >
            All Posts
          </button>
          {categories.map((cat) => (
            <button
              key={cat.slug}
              onClick={() => setCategory(cat.slug)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                currentCategory === cat.slug
                  ? "bg-gold-500 text-navy-950"
                  : "bg-navy-800 text-gray-400 hover:text-white border border-navy-700"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      )}

      {/* Posts grid */}
      {posts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {posts.map((post) => (
            <PostCard key={post.slug} post={post} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <p className="text-gray-500 text-lg">No posts found</p>
          {currentCategory && (
            <button
              onClick={() => setCategory(null)}
              className="mt-4 text-gold-500 hover:text-gold-400 font-medium"
            >
              View all posts
            </button>
          )}
        </div>
      )}

      {/* Pagination */}
      <BlogPagination currentPage={currentPage} totalPages={totalPages} />
    </div>
  );
}
