import { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { Section } from "@/components/Section";
import { BlogListClient } from "./BlogListClient";

export const metadata: Metadata = {
  title: "Blog",
  description:
    "Forex trading insights, tips, and updates from RPM Forex. Learn about automated gold trading and market analysis.",
  keywords: [
    "RPM Forex blog",
    "forex trading",
    "gold trading",
    "trading bot",
    "automated trading",
    "XAUUSD",
    "expert advisor",
    "RPM Forex",
  ],
};

export const revalidate = 60;

const POSTS_PER_PAGE = 9;

interface BlogPageProps {
  searchParams: Promise<{ page?: string; category?: string }>;
}

export default async function BlogPage({ searchParams }: BlogPageProps) {
  const params = await searchParams;
  const page = Math.max(1, parseInt(params.page || "1"));
  const categorySlug = params.category || null;
  const now = new Date();

  const where = {
    status: "PUBLISHED" as const,
    publishedAt: { lte: now },
    ...(categorySlug && { category: { slug: categorySlug } }),
  };

  const [posts, totalCount, categories] = await Promise.all([
    prisma.blogPost.findMany({
      where,
      orderBy: { publishedAt: "desc" },
      skip: (page - 1) * POSTS_PER_PAGE,
      take: POSTS_PER_PAGE,
      select: {
        title: true,
        slug: true,
        excerpt: true,
        featuredImage: true,
        publishedAt: true,
        readingTime: true,
        category: { select: { name: true, slug: true } },
      },
    }),
    prisma.blogPost.count({ where }),
    prisma.blogCategory.findMany({
      where: {
        posts: {
          some: { status: "PUBLISHED", publishedAt: { lte: now } },
        },
      },
      orderBy: { name: "asc" },
      select: { name: true, slug: true },
    }),
  ]);

  const totalPages = Math.ceil(totalCount / POSTS_PER_PAGE);

  const serializedPosts = posts.map((p) => ({
    ...p,
    publishedAt: p.publishedAt?.toISOString() ?? null,
  }));

  return (
    <>
      <section className="pt-32 pb-16 bg-gradient-to-b from-navy-900/50 to-navy-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              RPM Forex <span className="text-gold-500">Blog</span>
            </h1>
            <p className="text-xl text-gray-300">
              Trading insights, market analysis, and updates from the RPM Forex
              team.
            </p>
          </div>
        </div>
      </section>

      <Section>
        <BlogListClient
          posts={serializedPosts}
          categories={categories}
          currentCategory={categorySlug}
          currentPage={page}
          totalPages={totalPages}
        />
      </Section>
    </>
  );
}
