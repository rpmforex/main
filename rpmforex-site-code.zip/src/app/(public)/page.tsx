import Image from "next/image";
import { Section, SectionHeader } from "@/components/Section";
import { FeatureCard } from "@/components/FeatureCard";
import { Button } from "@/components/Button";
import {
  Shield,
  TrendingUp,
  Clock,
  BarChart3,
  Zap,
  Lock,
  ArrowRight,
  CheckCircle,
  Star,
  Quote,
} from "lucide-react";

const features = [
  {
    icon: TrendingUp,
    title: "Proven Performance",
    description:
      "Verified live trading results with consistent monthly returns. Fully transparent on MyFXBook.",
  },
  {
    icon: Shield,
    title: "Risk Management",
    description:
      "Built-in safeguards with controlled drawdown levels to protect your capital at all times.",
  },
  {
    icon: Clock,
    title: "24/7 Automation",
    description:
      "Set and forget. Our Bot trades around the clock, capturing opportunities while you sleep.",
  },
  {
    icon: BarChart3,
    title: "Gold Specialist",
    description:
      "Focused exclusively on XAUUSD for optimised performance in the gold market.",
  },
  {
    icon: Zap,
    title: "Fast Execution",
    description:
      "Quick trade execution with an average holding time of just 12 minutes per position.",
  },
  {
    icon: Lock,
    title: "Secure Setup",
    description:
      "Your funds stay in your own broker account. Full control, full transparency.",
  },
];

const benefits = [
  "Verified live trading results on MyFXBook",
  "No experience required - fully automated",
  "Works with major MT4 brokers",
  "Dedicated support and setup assistance",
  "Regular updates and optimisations",
];

export default function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-20">
        <div className="absolute inset-0 bg-gradient-to-b from-navy-900/50 to-navy-950" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gold-500/10 via-transparent to-transparent" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="animate-fade-in">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
                Automated{" "}
                <span className="text-gold-500">Gold Trading</span>{" "}
                That Delivers Results
              </h1>
              <p className="text-lg md:text-xl text-gray-300 mb-6 md:mb-8 max-w-xl">
                Professional forex automation with verified performance. Join
                traders achieving consistent returns with RPM Forex&apos;s
                advanced Bot technology.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button href="/buy" size="lg">
                  Buy Bot <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button href="/results" variant="outline" size="lg">
                  View Live Results
                </Button>
              </div>
            </div>

            <div className="relative animate-fade-in" style={{ animationDelay: "0.2s" }}>
              <div className="relative w-full max-w-md mx-auto">
                <div className="absolute inset-0 bg-gold-500/20 blur-3xl rounded-full" />
                <Image
                  src="/images/rpm-forex-logo.jpeg"
                  alt="RPM Forex"
                  width={400}
                  height={400}
                  className="relative rounded-2xl shadow-2xl mx-auto"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <Section>
        <SectionHeader
          title="Why Choose RPM Forex?"
          subtitle="Advanced automation designed for consistent, risk-managed returns"
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <FeatureCard
              key={feature.title}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </Section>

      {/* Benefits Section */}
      <Section className="bg-navy-900/50">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          <div>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4 md:mb-6">
              Start Trading Smarter Today
            </h2>
            <p className="text-gray-400 text-base md:text-lg mb-6 md:mb-8">
              RPM Forex Gold Bot handles the complexity of forex trading so you
              don&apos;t have to. Our automated system analyses the market 24/7,
              executing trades with precision and discipline.
            </p>
            <ul className="space-y-4">
              {benefits.map((benefit) => (
                <li key={benefit} className="flex items-start gap-3">
                  <CheckCircle className="w-6 h-6 text-gold-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-300">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6 md:p-8">
            <h3 className="text-xl md:text-2xl font-bold text-white mb-3 md:mb-4">
              Ready to Get Started?
            </h3>
            <p className="text-gray-400 mb-6">
              Contact our team to learn more about RPM Forex and how our Bot
              can work for you.
            </p>
            <p className="text-gray-300 border border-gold-500/30 bg-gold-500/5 rounded-lg p-4 mb-6">
              We also offer account management, so you do not have to purchase
              or run the bot yourself. Please contact us for details.
            </p>
            <Button href="/contact" size="lg" className="w-full">
              Contact Us <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </Section>

      {/* Testimonials Section */}
      <Section>
        <SectionHeader
          title="What Our Traders Say"
          subtitle="Hear from traders who use RPM Forex every day"
        />
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              quote: "RPM Forex has completely changed the way I trade. I no longer need to sit at my screen all day — the bot handles everything and the results speak for themselves.",
              name: "James T.",
              detail: "RPM Forex user since 2024",
              rating: 5,
            },
            {
              quote: "I was sceptical at first, but after seeing the MyFXBook results I decided to give it a go. Best decision I've made. Consistent returns every month.",
              name: "Sarah M.",
              detail: "RPM Forex user since 2024",
              rating: 5,
            },
            {
              quote: "The setup was simple and the support team was brilliant. I had the bot running within 20 minutes. Highly recommend to anyone looking to automate their trading.",
              name: "David R.",
              detail: "RPM Forex user since 2025",
              rating: 5,
            },
          ].map((testimonial) => (
            <div
              key={testimonial.name}
              className="bg-navy-800/30 border border-navy-700 rounded-2xl p-6 relative"
            >
              <Quote className="w-8 h-8 text-gold-500/20 absolute top-4 right-4" />
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-gold-500 fill-gold-500" />
                ))}
              </div>
              <p className="text-gray-300 mb-6">&ldquo;{testimonial.quote}&rdquo;</p>
              <div>
                <p className="text-white font-semibold">{testimonial.name}</p>
                <p className="text-gray-500 text-sm">{testimonial.detail}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA Section */}
      <Section className="bg-navy-900/50">
        <div className="text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-3 md:mb-4">
            Join the RPM Forex Community
          </h2>
          <p className="text-gray-400 text-base md:text-lg mb-6 md:mb-8 max-w-2xl mx-auto">
            Take the first step towards automated, profitable trading. Our team
            is ready to help you get started.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button href="/contact" size="lg">
              Get Started Today
            </Button>
            <Button href="/about" variant="secondary" size="lg">
              Learn More
            </Button>
          </div>
        </div>
      </Section>
    </>
  );
}
