import { Metadata } from "next";
import { Section } from "@/components/Section";
import { ContactForm } from "./ContactForm";
import { Mail, Send, Facebook, MessageCircle } from "lucide-react";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Get in touch with RPM Forex. Contact our team to learn more about automated gold trading and get started.",
};

export default function ContactPage() {
  return (
    <>
      {/* Hero */}
      <section className="pt-32 pb-8 bg-gradient-to-b from-navy-900/50 to-navy-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Get In <span className="text-gold-500">Touch</span>
            </h1>
            <p className="text-xl text-gray-300">
              Have questions about RPM Forex? Want to get started with
              automated gold trading? Our team is here to help.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <Section className="!pt-6 md:!pt-8">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-white mb-6">
              Send Us a Message
            </h2>
            <ContactForm />
          </div>

          {/* Contact Info */}
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-white mb-6">
                Other Ways to Reach Us
              </h2>
              <p className="text-gray-400 mb-8">
                Prefer a different method of contact? You can also reach us
                through email or our social channels.
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-navy-800/30 border border-navy-700 rounded-xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gold-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-gold-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-1">
                      Email
                    </h3>
                    <p className="text-gray-400 mb-2">
                      Send us an email and we&apos;ll get back to you within 24
                      hours.
                    </p>
                    <a
                      href="mailto:info@rpmforex.com"
                      className="text-gold-500 hover:text-gold-400 font-medium"
                    >
                      info@rpmforex.com
                    </a>
                  </div>
                </div>
              </div>

              <div className="bg-navy-800/30 border border-navy-700 rounded-xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gold-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Send className="w-6 h-6 text-gold-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-1">
                      Telegram
                    </h3>
                    <p className="text-gray-400 mb-3">
                      Connect with us on Telegram for support and updates.
                    </p>
                    <div className="space-y-2">
                      <a
                        href="https://t.me/RPMTRADINCHANNEL"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block text-gold-500 hover:text-gold-400 font-medium"
                      >
                        @RPMTRADINCHANNEL
                        <span className="text-gray-500 font-normal text-sm ml-2">Join our channel</span>
                      </a>
                      <a
                        href="https://t.me/RPMTRADINGGROUPCHAT"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block text-gold-500 hover:text-gold-400 font-medium"
                      >
                        @RPMTRADINGGROUPCHAT
                        <span className="text-gray-500 font-normal text-sm ml-2">Group chat</span>
                      </a>
                      <a
                        href="https://t.me/CharlieRPMDirectSupport"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block text-gold-500 hover:text-gold-400 font-medium"
                      >
                        @CharlieRPMDirectSupport
                        <span className="text-gray-500 font-normal text-sm ml-2">Direct support</span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-navy-800/30 border border-navy-700 rounded-xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gold-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Facebook className="w-6 h-6 text-gold-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-1">
                      Facebook
                    </h3>
                    <p className="text-gray-400 mb-2">
                      Follow us on Facebook for the latest news and updates.
                    </p>
                    <a
                      href="https://www.facebook.com/RPMTrading"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gold-500 hover:text-gold-400 font-medium"
                    >
                      RPM Forex
                    </a>
                  </div>
                </div>
              </div>

              <div className="bg-navy-800/30 border border-navy-700 rounded-xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gold-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MessageCircle className="w-6 h-6 text-gold-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-1">
                      WhatsApp
                    </h3>
                    <p className="text-gray-400 mb-2">
                      Message us on WhatsApp for quick support.
                    </p>
                    <a
                      href="https://wa.me/447346914172"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gold-500 hover:text-gold-400 font-medium"
                    >
                      Chat on WhatsApp
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* FAQ Teaser */}
            <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-2">
                Have Questions?
              </h3>
              <p className="text-gray-400 mb-4">
                Check out our FAQ section on the How It Works page for answers
                to common questions about RPM Forex.
              </p>
              <a
                href="/about#faq"
                className="text-gold-500 hover:text-gold-400 font-medium"
              >
                View FAQs &rarr;
              </a>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
