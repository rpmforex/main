import { Metadata } from "next";

export const metadata: Metadata = {
  title: {
    absolute: "Terms And Conditions | RPM Forex",
  },
  description: "RPM Forex terms and conditions for use of our website and products.",
};

export default function TermsPage() {
  return (
    <div className="pt-32 pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-white mb-8">Terms & Conditions</h1>
        <div className="prose prose-invert prose-gold max-w-none">
          <p className="text-gray-400 mb-6">Last updated: December 2024</p>

          <div className="space-y-8 text-gray-300">
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">1. Agreement to Terms</h2>
              <p>
                By accessing or using the RPM Forex website and purchasing our products, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you may not use our services.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">2. Products and Services</h2>
              <p className="mb-4">
                RPM Forex provides automated trading software (Expert Advisors) for the MetaTrader 4 platform. Our products are:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Digital products delivered electronically</li>
                <li>Licensed for personal use only unless otherwise specified</li>
                <li>Not to be resold, redistributed, or shared</li>
                <li>Subject to the licence terms specified at purchase</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">3. Licence Terms</h2>
              <p className="mb-4">Upon purchase, you receive a limited, non-exclusive, non-transferable licence to:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Use the software on the number of accounts specified in your licence</li>
                <li>Receive updates and bug fixes for the lifetime of the product</li>
                <li>Access customer support via email</li>
              </ul>
              <p className="mt-4">You may not:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Decompile, reverse engineer, or modify the software</li>
                <li>Share, sell, or distribute the software to others</li>
                <li>Use the software for any unlawful purpose</li>
                <li>Exceed the number of licence activations permitted</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">4. Payment and Pricing</h2>
              <p className="mb-4">
                All prices are displayed and charged in US Dollars (USD) and are inclusive of any applicable taxes. We accept payment via:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Credit/Debit cards (via Stripe)</li>
                <li>Bitcoin</li>
                <li>PayPal, Skrill, and Neteller (contact us for details)</li>
              </ul>
              <p className="mt-4">
                Payment must be received in full before product delivery.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">5. Refund Policy</h2>
              <p>
                All purchases are fully refundable. If you are not satisfied with your purchase, contact us within 30 days of purchase at info@rpmforex.com to request a refund. Refunds will be processed using the original payment method.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">6. Delivery</h2>
              <p>
                Products are delivered electronically via email within 24 hours of payment confirmation. You will receive your Bot file and unique licence key to the email address provided during checkout.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">7. No Guarantee of Results</h2>
              <p>
                Past performance is not indicative of future results. While our Bot has demonstrated positive historical performance, we make no guarantees about future trading results. Trading involves substantial risk of loss and is not suitable for all investors.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">8. Limitation of Liability</h2>
              <p>
                To the maximum extent permitted by law, RPM Forex shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including but not limited to loss of profits, trading losses, or data loss, arising from your use of our products.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">9. Intellectual Property</h2>
              <p>
                All content on this website, including text, graphics, logos, and software, is the property of RPM Forex and is protected by copyright and other intellectual property laws.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">10. Governing Law</h2>
              <p>
                These Terms shall be governed by and construed in accordance with the laws of England and Wales. Any disputes shall be subject to the exclusive jurisdiction of the courts of England and Wales.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">11. Changes to Terms</h2>
              <p>
                We reserve the right to modify these Terms at any time. Changes will be effective immediately upon posting to the website. Your continued use of our services constitutes acceptance of the modified Terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">12. Contact</h2>
              <p>
                For questions about these Terms, please contact us at:
              </p>
              <p className="mt-2">
                Email: <a href="mailto:info@rpmforex.com" className="text-gold-500 hover:text-gold-400">info@rpmforex.com</a>
              </p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
