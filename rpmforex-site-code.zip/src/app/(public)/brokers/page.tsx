import { Metadata } from "next";
import Link from "next/link";
import { Section, SectionHeader } from "@/components/Section";
import { Button } from "@/components/Button";
import { ArrowRight, ExternalLink, Server, Building2 } from "lucide-react";

export const metadata: Metadata = {
  title: {
    absolute: "Recommended Brokers and VPS | RPM Forex",
  },
  description:
    "Recommended MT4 brokers and VPS providers for RPM Forex Gold Bot. Find the right broker for your region and trading needs.",
};

const brokers = [
  {
    name: "Roboforex",
    description:
      "This is the broker we use for clients who are looking to trade cent accounts only. They offer accounts to any traders apart from Australian and USA.",
    regions: ["Worldwide (excl. Australia & USA)"],
    accountType: "Cent Accounts",
    link: "https://my.roboforex.com/en/?a=bbfb",
  },
  {
    name: "Vantage Markets",
    description:
      "This is the broker we use for clients who are looking for trading standard accounts on MT4. They also offer cent accounts to certain countries - please contact us for the list.",
    regions: ["Worldwide"],
    accountType: "Standard & Cent Accounts",
    link: "https://www.vantagefx.com/?affid=8737",
  },
  {
    name: "Forex Chief",
    description:
      "This is the broker we use for worldwide clients including USA who wish to trade cent accounts.",
    regions: ["Worldwide (incl. USA)"],
    accountType: "Cent Accounts",
    link: "https://www.forexchief.com/?a=ef7a",
  },
  {
    name: "Blackbull Markets",
    description:
      "This is the broker we use for clients who live in Australia who are looking for trading standard accounts on MT4.",
    regions: ["Australia"],
    accountType: "Standard Accounts",
    link: "https://blackbullmarkets.com/en/live-account/?ib=2100064679",
  },
  {
    name: "FBS",
    description:
      "This is the broker we use for clients who are looking for trading cent accounts who live in Australia.",
    regions: ["Australia"],
    accountType: "Cent Accounts",
    link: "https://fbs.com/?ppu=3447165",
  },
];

const vpsProviders = [
  {
    name: "Chocoping",
    description:
      "If you decide to purchase the Bot and trade your own account, you will require a VPS. We recommend Chocoping for reliable, low-latency forex VPS hosting.",
    link: "https://chocoping.com/processing/aff.php?aff=180&gocart=true",
  },
];

export default function BrokersPage() {
  return (
    <>
      {/* Hero */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-navy-900/50 to-navy-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Recommended <span className="text-gold-500">Brokers & VPS</span>
            </h1>
            <p className="text-xl text-gray-300">
              To run the RPM Forex Gold Bot, you&apos;ll need a compatible MT4
              broker and a reliable VPS. Here are our recommended partners based
              on your region and trading needs.
            </p>
          </div>
        </div>
      </section>

      {/* Brokers Section */}
      <Section>
        <SectionHeader
          title="MT4 Brokers"
          subtitle="Choose a broker based on your location and preferred account type"
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {brokers.map((broker) => (
            <div
              key={broker.name}
              className="bg-navy-800/50 border border-navy-700 rounded-xl p-6 flex flex-col"
            >
              <div className="flex items-start gap-3 mb-4">
                <div className="w-12 h-12 bg-gold-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Building2 className="w-6 h-6 text-gold-500" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white">
                    {broker.name}
                  </h3>
                  <p className="text-gold-500 text-sm">{broker.accountType}</p>
                </div>
              </div>
              <p className="text-gray-400 mb-4 flex-grow">{broker.description}</p>
              <div className="mb-4">
                <span className="text-sm text-gray-500">Available in: </span>
                <span className="text-sm text-gray-300">
                  {broker.regions.join(", ")}
                </span>
              </div>
              <Link
                href={broker.link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-gold-500 hover:bg-gold-400 text-navy-950 px-4 py-3 rounded-lg font-semibold transition-colors w-full"
              >
                Open Account <ExternalLink className="w-4 h-4" />
              </Link>
            </div>
          ))}
        </div>
      </Section>

      {/* VPS Section */}
      <Section className="bg-navy-900/50">
        <SectionHeader
          title="VPS Hosting"
          subtitle="A VPS ensures your Bot runs 24/7 with minimal latency"
        />
        <div className="max-w-2xl mx-auto">
          {vpsProviders.map((vps) => (
            <div
              key={vps.name}
              className="bg-navy-800/50 border border-navy-700 rounded-xl p-6 md:p-8"
            >
              <div className="flex items-start gap-3 md:gap-4 mb-4 md:mb-6">
                <div className="w-12 h-12 md:w-14 md:h-14 bg-gold-500/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Server className="w-6 h-6 md:w-7 md:h-7 text-gold-500" />
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-semibold text-white">
                    {vps.name}
                  </h3>
                  <p className="text-gold-500">Recommended VPS Provider</p>
                </div>
              </div>
              <p className="text-gray-400 text-base md:text-lg mb-6">{vps.description}</p>
              <Link
                href={vps.link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-gold-500 hover:bg-gold-400 text-navy-950 px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Get VPS Hosting <ExternalLink className="w-4 h-4" />
              </Link>
            </div>
          ))}
        </div>
      </Section>

      {/* Why VPS Section */}
      <Section>
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4 md:mb-6">
              Why Do I Need a VPS?
            </h2>
            <p className="text-gray-400 text-base md:text-lg mb-4 md:mb-6">
              A Virtual Private Server (VPS) is essential for running your
              trading Bot effectively. It provides a dedicated, always-on
              environment that ensures your Bot never misses a trading
              opportunity.
            </p>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">24/7 Uptime</span>
                  <p className="text-gray-400 text-sm">
                    Your Bot runs continuously without depending on your home
                    computer
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">Low Latency</span>
                  <p className="text-gray-400 text-sm">
                    Faster trade execution with servers located near broker
                    infrastructure
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">Reliability</span>
                  <p className="text-gray-400 text-sm">
                    No interruptions from power outages or internet issues at
                    home
                  </p>
                </div>
              </li>
            </ul>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6 md:p-8">
            <h3 className="text-lg md:text-xl font-bold text-white mb-3 md:mb-4">Need Help?</h3>
            <p className="text-gray-400 text-sm md:text-base mb-4 md:mb-6">
              Not sure which broker or VPS is right for you? Contact our team
              and we&apos;ll help you choose the best options based on your
              location and trading goals.
            </p>
            <Button href="/contact" size="lg" className="w-full">
              Contact Us <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      </Section>

      {/* CTA Section */}
      <Section className="bg-navy-900/50">
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Start Trading?
          </h2>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
            Once you&apos;ve set up your broker and VPS, you&apos;re ready to
            get the RPM Forex Gold Bot and start automated trading.
          </p>
          <Button href="/buy" size="lg">
            Buy Bot <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </Section>
    </>
  );
}
