import { Metadata } from "next";
import { Section, SectionHeader } from "@/components/Section";
import { Button } from "@/components/Button";
import {
  ArrowRight,
  Download,
  Settings,
  Play,
  LineChart,
  HelpCircle,
  Users,
} from "lucide-react";

export const metadata: Metadata = {
  title: "How RPM Forex Works",
  description:
    "Learn how RPM Forex works including how the RPM Forex Gold Bot helps deliver results for investors.",
  keywords: [
    "how RPM Forex works",
    "forex trading",
    "gold trading",
    "trading bot",
    "automated trading",
    "XAUUSD",
    "expert advisor",
    "RPM Forex",
  ],
};

const steps = [
  {
    number: "01",
    icon: Download,
    title: "Get the Bot",
    description:
      "After purchase of the RPM Forex Gold Bot you'll receive the Bot files and set up instructions via email which will include written and video instructions.",
  },
  {
    number: "02",
    icon: Settings,
    title: "Install & Configure",
    description:
      "Install the Bot on your MT4 platform via a VPS. Our team provides step-by-step guidance and recommended settings.",
  },
  {
    number: "03",
    icon: Play,
    title: "Activate & Trade",
    description:
      "Activate your Bot and let it run. The system monitors the market 24/7 and executes trades automatically.",
  },
  {
    number: "04",
    icon: LineChart,
    title: "Track Results",
    description:
      "Monitor your performance through MT4 and MyFXBook integration. Full transparency on all trades.",
  },
];

const faqs = [
  {
    question: "What is a Trading Bot?",
    answer:
      "A Trading Bot is automated trading software that runs on the MetaTrader platform. It analyses market conditions and executes trades according to its programmed strategy, removing emotion from trading decisions.",
  },
  {
    question: "What broker do I need?",
    answer:
      "RPM Forex Gold Bot works with most MT4 brokers. We recommend brokers with low spreads on XAUUSD and reliable execution. Our team can advise on compatible options.",
  },
  {
    question: "What's the minimum investment?",
    answer:
      "We recommend a minimum starting capital of $1,000 for optimal risk management, though the Bot can technically run on smaller accounts. Proper capitalisation helps achieve the best results.",
  },
  {
    question: "Do I need trading experience?",
    answer:
      "No prior trading experience is required. The Bot handles all trading decisions automatically. We provide full setup support and ongoing assistance.",
  },
  {
    question: "How are results verified?",
    answer:
      "All our trading results are published and verified on MyFXBook, an independent third-party platform. You can view live, real-time performance data at any time.",
  },
  {
    question: "Is my money safe?",
    answer:
      "Your funds remain in your own broker account at all times - we never have access to your capital. The Bot simply connects to execute trades on your behalf.",
  },
  {
    question: "How much can I expect to make per month?",
    answer:
      "4-8% depending on market conditions.",
  },
  {
    question: "Can I compound my account?",
    answer:
      "Yes, we suggest compounding every month.",
  },
  {
    question: "Can I lose all my money if the markets go crazy?",
    answer:
      "No, because the Bot has a setting called 'Equity Protector' which can be set to protect your account from loss.",
  },
];

export default function AboutPage() {
  return (
    <>
      {/* Hero */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-navy-900/50 to-navy-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              How <span className="text-gold-500">RPM Forex</span> Works
            </h1>
            <p className="text-xl text-gray-300">
              Our automated trading system handles the complexity of forex
              trading, delivering consistent results through advanced
              algorithmic strategies focused on gold (XAUUSD).
            </p>
          </div>
        </div>
      </section>

      {/* What Is Section */}
      <Section>
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Automated Gold Trading
            </h2>
            <p className="text-gray-400 text-lg mb-6">
              RPM Forex Gold Bot is a sophisticated automated trading system
              designed specifically for the XAUUSD (gold) market. Using advanced
              algorithms and strict risk management protocols, the Bot identifies
              and executes high-probability trades around the clock.
            </p>
            <p className="text-gray-400 text-lg mb-6">
              Unlike manual trading, our Bot removes emotional decision-making
              from the equation. It follows its programmed strategy with
              precision and discipline, consistently applying proven techniques
              to capture market opportunities.
            </p>
            <div className="flex items-center gap-4 text-gold-500">
              <Users className="w-6 h-6" />
              <span className="font-medium">Trusted by traders worldwide</span>
            </div>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-8">
            <h3 className="text-xl font-bold text-white mb-4">Key Features</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">
                    Gold Market Focus
                  </span>
                  <p className="text-gray-400 text-sm">
                    Optimised specifically for XAUUSD trading
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">
                    Risk Management Built-In
                  </span>
                  <p className="text-gray-400 text-sm">
                    Controlled drawdown with protective stop-losses
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">24/7 Operation</span>
                  <p className="text-gray-400 text-sm">
                    Trades automatically while markets are open
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold-500 rounded-full mt-2" />
                <div>
                  <span className="text-white font-medium">
                    Verified Results
                  </span>
                  <p className="text-gray-400 text-sm">
                    Fully transparent performance on MyFXBook
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </Section>

      {/* Steps Section */}
      <Section className="bg-navy-900/50">
        <SectionHeader
          title="Getting Started"
          subtitle="Four simple steps to begin automated trading with RPM"
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step) => (
            <div
              key={step.number}
              className="bg-navy-800/50 border border-navy-700 rounded-xl p-6 relative"
            >
              <div className="text-gold-500/20 text-6xl font-bold absolute top-4 right-4">
                {step.number}
              </div>
              <div className="relative">
                <div className="w-12 h-12 bg-gold-500/10 rounded-lg flex items-center justify-center mb-4">
                  <step.icon className="w-6 h-6 text-gold-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">
                  {step.title}
                </h3>
                <p className="text-gray-400">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* FAQ Section */}
      <Section>
        <SectionHeader
          title="Frequently Asked Questions"
          subtitle="Everything you need to know about RPM Forex"
        />
        <div className="grid md:grid-cols-2 gap-6">
          {faqs.map((faq) => (
            <div
              key={faq.question}
              className="bg-navy-800/30 border border-navy-700 rounded-xl p-6"
            >
              <div className="flex items-start gap-3">
                <HelpCircle className="w-6 h-6 text-gold-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">
                    {faq.question}
                  </h3>
                  <p className="text-gray-400">{faq.answer}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA Section */}
      <Section className="bg-navy-900/50">
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Start Trading?
          </h2>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
            Contact our team to discuss how RPM Forex can work for you. We&apos;re
            here to answer your questions and help you get started.
          </p>
          <Button href="/contact" size="lg">
            Contact Us <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </Section>
    </>
  );
}
