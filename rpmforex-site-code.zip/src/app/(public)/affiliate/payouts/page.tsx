"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface Affiliate {
  id: string;
  name: string;
  pendingEarnings: number;
  paidEarnings: number;
}

interface Payout {
  id: string;
  amount: number;
  method: string;
  reference: string | null;
  status: "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED";
  createdAt: string;
  processedAt: string | null;
}

export default function AffiliatePayoutsPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [affiliate, setAffiliate] = useState<Affiliate | null>(null);
  const [payouts, setPayouts] = useState<Payout[]>([]);

  const fetchData = useCallback(async () => {
    try {
      const meRes = await fetch("/api/affiliate/me");

      if (!meRes.ok) {
        router.push("/affiliate/login");
        return;
      }

      const meData = await meRes.json();
      setAffiliate(meData.affiliate);

      // For now, payouts would come from another endpoint
      // We'll show a placeholder since we haven't implemented payout API yet
      setPayouts([]);
    } catch {
      router.push("/affiliate/login");
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleLogout = async () => {
    await fetch("/api/affiliate/logout", { method: "POST" });
    router.push("/affiliate/login");
  };

  const getStatusBadge = (status: Payout["status"]) => {
    switch (status) {
      case "COMPLETED":
        return (
          <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
            Completed
          </span>
        );
      case "PROCESSING":
        return (
          <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs rounded-full">
            Processing
          </span>
        );
      case "FAILED":
        return (
          <span className="px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded-full">
            Failed
          </span>
        );
      default:
        return (
          <span className="px-2 py-1 bg-gray-500/20 text-gray-400 text-xs rounded-full">
            Pending
          </span>
        );
    }
  };

  if (loading) {
    return (
      <div className="pt-32 pb-20 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold-500"></div>
      </div>
    );
  }

  if (!affiliate) {
    return null;
  }

  return (
    <div className="pt-32 pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Payouts</h1>
            <p className="text-gray-400">View your payout history</p>
          </div>
          <div className="flex gap-4">
            <Link
              href="/affiliate/dashboard"
              className="px-4 py-2 bg-navy-700 text-white rounded-lg hover:bg-navy-600 transition-colors"
            >
              Back to Dashboard
            </Link>
            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-navy-700 text-gray-400 rounded-lg hover:bg-navy-600 hover:text-white transition-colors"
            >
              Log Out
            </button>
          </div>
        </div>

        {/* Balance Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
            <p className="text-gray-400 text-sm mb-1">Pending Balance</p>
            <p className="text-4xl font-bold text-gold-500">
              ${affiliate.pendingEarnings.toFixed(2)}
            </p>
            <p className="text-gray-500 text-sm mt-2">
              {affiliate.pendingEarnings >= 50
                ? "Eligible for payout"
                : `$${(50 - affiliate.pendingEarnings).toFixed(2)} more to reach minimum`}
            </p>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
            <p className="text-gray-400 text-sm mb-1">Total Paid Out</p>
            <p className="text-4xl font-bold text-green-500">
              ${affiliate.paidEarnings.toFixed(2)}
            </p>
            <p className="text-gray-500 text-sm mt-2">Lifetime payouts</p>
          </div>
        </div>

        {/* Payout Request Info */}
        <div className="bg-gold-500/10 border border-gold-500/30 rounded-2xl p-6 mb-8">
          <h3 className="text-lg font-semibold text-gold-500 mb-2">
            Request a Payout
          </h3>
          <p className="text-gray-400">
            To request a payout, please contact us at{" "}
            <a
              href="mailto:info@rpmforex.com"
              className="text-gold-500 hover:text-gold-400"
            >
              info@rpmforex.com
            </a>
            . Minimum payout amount is $50. We process payouts within 3-5
            business days.
          </p>
        </div>

        {/* Payout History */}
        <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
          <h2 className="text-xl font-semibold text-white mb-6">
            Payout History
          </h2>
          {payouts.length === 0 ? (
            <p className="text-gray-400 text-center py-8">
              No payouts yet. Keep earning to request your first payout!
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-gray-400 text-sm border-b border-navy-700">
                    <th className="pb-4 font-medium">Date</th>
                    <th className="pb-4 font-medium">Amount</th>
                    <th className="pb-4 font-medium">Method</th>
                    <th className="pb-4 font-medium">Reference</th>
                    <th className="pb-4 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-navy-700">
                  {payouts.map((payout) => (
                    <tr key={payout.id} className="text-sm">
                      <td className="py-4 text-gray-300">
                        {new Date(payout.createdAt).toLocaleDateString("en-GB")}
                      </td>
                      <td className="py-4 text-white font-semibold">
                        ${payout.amount.toFixed(2)}
                      </td>
                      <td className="py-4 text-gray-300 capitalize">
                        {payout.method}
                      </td>
                      <td className="py-4 text-gray-400 font-mono text-xs">
                        {payout.reference || "-"}
                      </td>
                      <td className="py-4">{getStatusBadge(payout.status)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
