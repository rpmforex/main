"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface AffiliateStats {
  totalClicks: number;
  totalOrders: number;
  totalEarnings: number;
  pendingEarnings: number;
  paidEarnings: number;
  commissionRate: number;
  recentClicks: number;
  recentConversions: number;
  conversionRate: string;
  monthlyEarnings: number;
}

interface Affiliate {
  id: string;
  email: string;
  name: string;
  referralCode: string;
}

interface Referral {
  id: string;
  createdAt: string;
  converted: boolean;
  convertedAt: string | null;
  commission: number | null;
  landingPage: string | null;
  order: {
    orderRef: string;
    price: number;
    createdAt: string;
  } | null;
}

export default function AffiliateDashboardPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [affiliate, setAffiliate] = useState<Affiliate | null>(null);
  const [stats, setStats] = useState<AffiliateStats | null>(null);
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [copied, setCopied] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const [meRes, statsRes, referralsRes] = await Promise.all([
        fetch("/api/affiliate/me"),
        fetch("/api/affiliate/stats"),
        fetch("/api/affiliate/referrals?limit=10"),
      ]);

      if (!meRes.ok) {
        router.push("/affiliate/login");
        return;
      }

      const meData = await meRes.json();
      const statsData = await statsRes.json();
      const referralsData = await referralsRes.json();

      setAffiliate(meData.affiliate);
      setStats(statsData.stats);
      setReferrals(referralsData.referrals);
    } catch {
      router.push("/affiliate/login");
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleLogout = async () => {
    await fetch("/api/affiliate/logout", { method: "POST" });
    router.push("/affiliate/login");
  };

  const copyReferralLink = () => {
    if (!affiliate) return;
    const link = `https://rpmforex.com/?ref=${affiliate.referralCode}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="pt-32 pb-20 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold-500"></div>
      </div>
    );
  }

  if (!affiliate || !stats) {
    return null;
  }

  return (
    <div className="pt-32 pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">
              Welcome, {affiliate.name}
            </h1>
            <p className="text-gray-400">Affiliate Dashboard</p>
          </div>
          <div className="flex gap-4">
            <Link
              href="/affiliate/payouts"
              className="px-4 py-2 bg-navy-700 text-white rounded-lg hover:bg-navy-600 transition-colors"
            >
              View Payouts
            </Link>
            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-navy-700 text-gray-400 rounded-lg hover:bg-navy-600 hover:text-white transition-colors"
            >
              Log Out
            </button>
          </div>
        </div>

        {/* Referral Link */}
        <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6 mb-8">
          <h2 className="text-lg font-semibold text-white mb-4">
            Your Referral Link
          </h2>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 bg-navy-700 rounded-xl px-4 py-3 font-mono text-sm text-gold-500 overflow-x-auto">
              https://rpmforex.com/?ref={affiliate.referralCode}
            </div>
            <button
              onClick={copyReferralLink}
              className={`px-6 py-3 rounded-xl font-semibold transition-colors ${
                copied
                  ? "bg-green-500 text-white"
                  : "bg-gold-500 text-navy-900 hover:bg-gold-400"
              }`}
            >
              {copied ? "Copied!" : "Copy Link"}
            </button>
          </div>
          <p className="text-gray-500 text-sm mt-3">
            Your referral code: <span className="text-gold-500 font-mono">{affiliate.referralCode}</span>
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
            <p className="text-gray-400 text-sm mb-1">Total Clicks</p>
            <p className="text-3xl font-bold text-white">
              {stats.totalClicks.toLocaleString()}
            </p>
            <p className="text-gray-500 text-xs mt-1">
              {stats.recentClicks} this month
            </p>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
            <p className="text-gray-400 text-sm mb-1">Conversions</p>
            <p className="text-3xl font-bold text-white">{stats.totalOrders}</p>
            <p className="text-gray-500 text-xs mt-1">
              {stats.conversionRate}% rate
            </p>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
            <p className="text-gray-400 text-sm mb-1">Pending Earnings</p>
            <p className="text-3xl font-bold text-gold-500">
              ${stats.pendingEarnings.toFixed(2)}
            </p>
            <p className="text-gray-500 text-xs mt-1">
              ${stats.monthlyEarnings.toFixed(2)} this month
            </p>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
            <p className="text-gray-400 text-sm mb-1">Total Earned</p>
            <p className="text-3xl font-bold text-green-500">
              ${stats.totalEarnings.toFixed(2)}
            </p>
            <p className="text-gray-500 text-xs mt-1">
              ${stats.paidEarnings.toFixed(2)} paid out
            </p>
          </div>
        </div>

        {/* Commission Rate */}
        <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm mb-1">Your Commission Rate</p>
              <p className="text-2xl font-bold text-gold-500">
                {stats.commissionRate}%
              </p>
            </div>
            <div className="text-right">
              <p className="text-gray-400 text-sm mb-1">Minimum Payout</p>
              <p className="text-2xl font-bold text-white">$50</p>
            </div>
          </div>
        </div>

        {/* Recent Referrals */}
        <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6">
          <h2 className="text-xl font-semibold text-white mb-6">
            Recent Referrals
          </h2>
          {referrals.length === 0 ? (
            <p className="text-gray-400 text-center py-8">
              No referrals yet. Share your link to start earning!
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-gray-400 text-sm border-b border-navy-700">
                    <th className="pb-4 font-medium">Date</th>
                    <th className="pb-4 font-medium">Status</th>
                    <th className="pb-4 font-medium">Order</th>
                    <th className="pb-4 font-medium text-right">Commission</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-navy-700">
                  {referrals.map((referral) => (
                    <tr key={referral.id} className="text-sm">
                      <td className="py-4 text-gray-300">
                        {new Date(referral.createdAt).toLocaleDateString(
                          "en-GB"
                        )}
                      </td>
                      <td className="py-4">
                        {referral.converted ? (
                          <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
                            Converted
                          </span>
                        ) : (
                          <span className="px-2 py-1 bg-gray-500/20 text-gray-400 text-xs rounded-full">
                            Click Only
                          </span>
                        )}
                      </td>
                      <td className="py-4 text-gray-300">
                        {referral.order?.orderRef || "-"}
                      </td>
                      <td className="py-4 text-right font-semibold">
                        {referral.commission ? (
                          <span className="text-green-500">
                            ${referral.commission.toFixed(2)}
                          </span>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
