import { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Affiliate Program",
  description:
    "Join the RPM Forex Affiliate Program and earn a flat 30% commission on every sale.",
  keywords: [
    "RPM Forex affiliate program",
    "forex trading",
    "gold trading",
    "trading bot",
    "automated trading",
    "XAUUSD",
    "expert advisor",
    "RPM Forex",
  ],
};

export default function AffiliatePage() {
  return (
    <div className="pt-32 pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero */}
        <div className="text-center mb-10 md:mb-16">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 md:mb-6">
            Earn <span className="text-gold-500">30% Commission</span> on Every
            RPM Forex Sale
          </h1>
          <p className="text-base md:text-xl text-gray-400 max-w-3xl mx-auto mb-6 md:mb-8">
            Join the RPM Forex Affiliate Program and earn a flat 30% on every
            sale by sharing our proven gold trading Bot with your audience.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/affiliate/register"
              className="px-8 py-4 bg-gold-500 text-navy-900 font-bold rounded-xl hover:bg-gold-400 transition-colors text-lg"
            >
              Apply Now
            </Link>
            <Link
              href="/affiliate/login"
              className="px-8 py-4 bg-navy-700 text-white font-semibold rounded-xl hover:bg-navy-600 transition-colors border border-navy-600"
            >
              Affiliate Login
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 mb-10 md:mb-16 max-w-2xl mx-auto">
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6 md:p-8 text-center">
            <p className="text-3xl md:text-4xl font-bold text-gold-500 mb-2">30%</p>
            <p className="text-gray-400">Commission Rate</p>
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6 md:p-8 text-center">
            <p className="text-3xl md:text-4xl font-bold text-gold-500 mb-2">30 Days</p>
            <p className="text-gray-400">Cookie Duration</p>
          </div>
        </div>

        {/* How It Works */}
        <div className="mb-10 md:mb-16">
          <h2 className="text-2xl md:text-3xl font-bold text-white text-center mb-8 md:mb-10">
            How It Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gold-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-gold-500">1</span>
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Sign Up
              </h3>
              <p className="text-gray-400">
                Apply for our affiliate program. We review applications within
                24-48 hours.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gold-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-gold-500">2</span>
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Share Your Link
              </h3>
              <p className="text-gray-400">
                Get your unique referral link and share it with your audience
                via any channel.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gold-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-gold-500">3</span>
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Earn Commission
              </h3>
              <p className="text-gray-400">
                Earn 30% on every sale. Track your earnings in your affiliate
                dashboard.
              </p>
            </div>
          </div>
        </div>

        {/* Benefits */}
        <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-6 md:p-10 lg:p-12 mb-10 md:mb-16">
          <h2 className="text-2xl md:text-3xl font-bold text-white text-center mb-8 md:mb-10">
            Why Join Our Program?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-green-500"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-1">
                  High Commission Rates
                </h3>
                <p className="text-gray-400">
                  Earn 30% on every sale - that&apos;s $149-299 per conversion.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-green-500"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-1">
                  30-Day Cookie
                </h3>
                <p className="text-gray-400">
                  Get credit for sales up to 30 days after the initial click.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-green-500"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-1">
                  Proven Product
                </h3>
                <p className="text-gray-400">
                  Promote a product with verified, transparent trading results.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-green-500"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-1">
                  Real-Time Tracking
                </h3>
                <p className="text-gray-400">
                  Monitor clicks, conversions, and earnings in your dashboard.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-green-500"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-1">
                  Flexible Payouts
                </h3>
                <p className="text-gray-400">
                  Get paid via PayPal, bank transfer, or cryptocurrency.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-green-500"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-1">
                  Dedicated Support
                </h3>
                <p className="text-gray-400">
                  Get help whenever you need it from our affiliate team.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4 md:mb-6">
            Ready to Start Earning?
          </h2>
          <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
            Join hundreds of affiliates already earning commissions with RPM
            Trading. Apply now and start earning within 48 hours.
          </p>
          <Link
            href="/affiliate/register"
            className="inline-block px-10 py-4 bg-gold-500 text-navy-900 font-bold rounded-xl hover:bg-gold-400 transition-colors text-lg"
          >
            Apply Now
          </Link>
        </div>
      </div>
    </div>
  );
}
