import { Metadata } from "next";
import { OrderForm } from "./OrderForm";
import {
  CheckCircle,
  ArrowRight,
  Lock,
  Headphones,
  RefreshCw,
  ShieldCheck,
  CreditCard,
  BadgeCheck,
} from "lucide-react";

export const metadata: Metadata = {
  title: "Buy RPM Forex Gold Bot - Automated Gold Trading",
  description:
    "Purchase the RPM Forex Gold Bot. Automated gold trading with verified results. Start trading smarter today.",
  keywords: [
    "RPM Forex Gold",
    "forex trading",
    "gold trading",
    "trading bot",
    "automated trading",
    "XAUUSD",
    "expert advisor",
    "RPM Forex",
  ],
};

const included = [
  "RPM Forex Gold Bot software + licence key",
  "Setup guide & default settings file",
  "Email support",
  "1-on-1 setup call (TeamViewer / WhatsApp / AnyDesk etc)",
  "Lifetime free updates",
];

const faqs = [
  {
    q: "How quickly can I start trading?",
    a: "Most traders are up and running within 30 minutes. We provide clear setup instructions, and our support team is on hand if you need help.",
  },
  {
    q: "Do I need trading experience?",
    a: "No. The Bot is fully automated. You just need to install it on MT4 and it handles everything else - analysis, entries, exits, and risk management.",
  },
  {
    q: "Which brokers can I use?",
    a: "With our 'Any Broker' option, you can use any MT4 broker worldwide. We also have partner brokers if you'd prefer a recommended setup.",
  },
  {
    q: "Is my capital safe?",
    a: "Your funds stay in your own broker account at all times. The Bot only places trades - it cannot withdraw funds. You have full control.",
  },
  {
    q: "How much can I expect to make per month?",
    a: "4-8% depending on market conditions.",
  },
  {
    q: "Can I compound my account?",
    a: "Yes, we suggest compounding every month.",
  },
  {
    q: "Can I lose all my money if the markets go crazy?",
    a: "No, because the Bot has a setting called 'Equity Protector' which can be set to protect your account from loss.",
  },
];

export default function BuyPage() {
  return (
    <>
      {/* Order Section */}
      <section className="pt-32 pb-12 md:pb-20 bg-navy-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 md:mb-12">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-3 md:mb-4">
              Get Started Today
            </h1>
            <p className="text-base md:text-xl text-gray-400">
              Choose your licence option and start automated trading
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-start max-w-6xl mx-auto">
            {/* What's Included */}
            <div className="bg-navy-800/30 border border-navy-700 rounded-2xl p-6 md:p-8">
              <h3 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-6 flex items-center gap-3">
                <CheckCircle className="w-7 h-7 text-gold-500" />
                Everything You Need
              </h3>

              <ul className="space-y-4 mb-8">
                {included.map((item) => (
                  <li key={item} className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-gold-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-3 h-3 text-gold-500" />
                    </div>
                    <span className="text-gray-300">{item}</span>
                  </li>
                ))}
              </ul>

              {/* Trust Signals */}
              <div className="border-t border-navy-700 pt-6 space-y-4">
                <div className="flex items-center gap-3 text-gray-400">
                  <Lock className="w-5 h-5 text-green-500" />
                  <span>Secure payment via Stripe</span>
                </div>
                <div className="flex items-center gap-3 text-gray-400">
                  <Headphones className="w-5 h-5 text-green-500" />
                  <span>Full setup support included</span>
                </div>
                <div className="flex items-center gap-3 text-gray-400">
                  <RefreshCw className="w-5 h-5 text-green-500" />
                  <span>Free lifetime updates</span>
                </div>
              </div>

              {/* Trust Badges */}
              <div className="mt-6 grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2 bg-navy-900/50 border border-navy-700 rounded-lg p-3">
                  <ShieldCheck className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-300 text-sm font-medium">SSL Secured</span>
                </div>
                <div className="flex items-center gap-2 bg-navy-900/50 border border-navy-700 rounded-lg p-3">
                  <CreditCard className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-300 text-sm font-medium">Visa / Mastercard</span>
                </div>
                <div className="flex items-center gap-2 bg-navy-900/50 border border-navy-700 rounded-lg p-3">
                  <BadgeCheck className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-300 text-sm font-medium">Money-Back Guarantee</span>
                </div>
                <div className="flex items-center gap-2 bg-navy-900/50 border border-navy-700 rounded-lg p-3">
                  <Lock className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-300 text-sm font-medium">Secure Checkout</span>
                </div>
              </div>

              <div className="mt-4 p-4 bg-navy-900/50 border border-navy-700 rounded-lg">
                <p className="text-gray-400 text-sm">
                  We also accept payments using PayPal, bank transfer and crypto.{" "}
                  <a href="mailto:info@rpmforex.com" className="text-gold-500 hover:text-gold-400">
                    Contact us
                  </a>{" "}
                  for details.
                </p>
              </div>
            </div>

            {/* Order Form */}
            <div id="order" className="scroll-mt-24 md:scroll-mt-28">
              <OrderForm />
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-12 md:py-20 bg-navy-900/50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 md:mb-12">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4">
              Common Questions
            </h2>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <div
                key={i}
                className="bg-navy-800/30 border border-navy-700 rounded-xl p-6"
              >
                <h3 className="text-lg font-semibold text-white mb-2">
                  {faq.q}
                </h3>
                <p className="text-gray-400">
                  {faq.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-12 md:py-20 bg-gradient-to-b from-navy-950 to-navy-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white mb-4 md:mb-6">
            Ready to Let Your MT4 <span className="text-gold-500">Work For You?</span>
          </h2>
          <p className="text-base md:text-xl text-gray-400 mb-6 md:mb-8">
            Join traders who&apos;ve already made the switch to automated gold trading.
          </p>
          <a
            href="#order"
            className="inline-flex items-center justify-center gap-2 bg-gold-500 hover:bg-gold-400 text-navy-950 px-8 py-4 md:px-10 md:py-5 rounded-xl font-bold text-lg md:text-xl transition-all hover:scale-105"
          >
            Get RPM Gold Bot Now <ArrowRight className="w-6 h-6" />
          </a>
          <p className="text-gray-500 text-sm mt-6">
            Email delivery • Full support • Lifetime updates
          </p>
        </div>
      </section>
    </>
  );
}
