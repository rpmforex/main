import { Metadata } from "next";
import Link from "next/link";
import { CheckCircle, ArrowRight, Mail, Send, MessageCircle } from "lucide-react";
import { Button } from "@/components/Button";

export const metadata: Metadata = {
  title: "Payment Successful",
  description: "Your payment has been processed successfully.",
};

export default async function SuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string }>;
}) {
  const params = await searchParams;
  const orderRef = params.order;

  return (
    <section className="min-h-screen pt-32 pb-16">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-8 md:p-12">
          <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-500" />
          </div>

          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Payment Successful!
          </h1>

          <p className="text-gray-400 text-lg mb-6">
            Thank you for your purchase. Your payment has been processed
            successfully.
          </p>

          {orderRef && (
            <div className="bg-navy-900 border border-navy-700 rounded-xl p-4 mb-8">
              <p className="text-gray-400 text-sm mb-1">Order Reference</p>
              <p className="text-white font-mono text-lg">{orderRef}</p>
            </div>
          )}

          <div className="bg-gold-500/10 border border-gold-500/20 rounded-xl p-6 mb-8 text-left">
            <h3 className="text-white font-semibold mb-4">What happens next?</h3>
            <p className="text-gray-400 text-sm mb-4">
              Please contact support via email, Telegram, WhatsApp, or live chat and send them your MT4 account number. Our team will then send you the RPM Forex Gold Bot file along with your unique licence key and setup instructions.
            </p>

            <div className="space-y-3">
              <a
                href="https://t.me/CharlieRPMDirectSupport"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 bg-navy-900 rounded-lg hover:bg-navy-800 transition-colors"
              >
                <Send className="w-5 h-5 text-gold-500" />
                <span className="text-white">Telegram Support</span>
              </a>

              <a
                href="https://wa.me/447346914172"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 p-3 bg-navy-900 rounded-lg hover:bg-navy-800 transition-colors"
              >
                <MessageCircle className="w-5 h-5 text-gold-500" />
                <span className="text-white">WhatsApp Support</span>
              </a>

              <a
                href="mailto:info@rpmforex.com"
                className="flex items-center gap-3 p-3 bg-navy-900 rounded-lg hover:bg-navy-800 transition-colors"
              >
                <Mail className="w-5 h-5 text-gold-500" />
                <span className="text-white">Email Support</span>
              </a>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button href="/" variant="secondary">
              Return Home
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
