"use client";

import { useState, useEffect, useCallback, FormEvent, useRef } from "react";
import { Button } from "@/components/Button";
import { ShoppingCart, Copy, CheckCircle, AlertCircle, CreditCard, Tag } from "lucide-react";
import { Turnstile, TurnstileInstance } from "@marsidev/react-turnstile";
import { formatPrice } from "@/lib/currency";

type BrokerOption = "our-brokers" | "any-broker";
type PaymentMethod = "stripe" | "bitcoin";

interface FormState {
  status: "idle" | "loading" | "success" | "error";
  message: string;
  orderRef?: string;
  paymentMethod?: PaymentMethod;
}

const BITCOIN_ADDRESS = "1C6hG3zmipqzQmDpbioWCTHLabheL3EZGY";

const pricingOptions = {
  "our-brokers": {
    label: "RPM Gold — Standard",
    price: 497,
    description:
      "Recommended partner brokers only · Unlimited live MT4 or MT5 licences + 2 demo",
  },
  "any-broker": {
    label: "RPM Gold — Pro",
    price: 997,
    description: "Any broker worldwide · 3 live MT4 or MT5 licences",
  },
};

export function OrderForm() {
  const [selectedOption, setSelectedOption] = useState<BrokerOption>("our-brokers");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("stripe");
  const [formState, setFormState] = useState<FormState>({
    status: "idle",
    message: "",
  });
  const [copied, setCopied] = useState(false);
  const [turnstileToken, setTurnstileToken] = useState<string | null>(null);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const turnstileRef = useRef<TurnstileInstance>(null);
  const [couponCode, setCouponCode] = useState("");
  const [couponState, setCouponState] = useState<{
    status: "idle" | "validating" | "valid" | "invalid";
    message?: string;
    discountAmount?: number;
    finalPrice?: number;
    code?: string;
  }>({ status: "idle" });

  const selectedPricing = pricingOptions[selectedOption];

  // Prices are USD-native and the site is single-currency USD.
  const fmt = (amount: number) => formatPrice(amount, "USD");

  const validateCoupon = useCallback(async (code: string, option: BrokerOption) => {
    if (!code.trim()) return;
    setCouponState({ status: "validating" });
    try {
      const res = await fetch("/api/coupon/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code.trim(), brokerOption: option }),
      });
      const data = await res.json();
      if (data.valid) {
        setCouponState({
          status: "valid",
          message: "Coupon applied!",
          discountAmount: data.discountAmount,
          finalPrice: data.finalPrice,
          code: data.code,
        });
      } else {
        setCouponState({ status: "invalid", message: data.error || "Invalid coupon code" });
      }
    } catch {
      setCouponState({ status: "invalid", message: "Failed to validate coupon" });
    }
  }, []);

  // Re-validate when broker option changes
  useEffect(() => {
    if (couponState.status === "valid" && couponState.code) {
      validateCoupon(couponState.code, selectedOption);
    }
  }, [selectedOption]); // eslint-disable-line react-hooks/exhaustive-deps

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (!turnstileToken && process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY) {
      setFormState({
        status: "error",
        message: "Please complete the security check.",
      });
      return;
    }

    setFormState({ status: "loading", message: "" });

    const form = e.currentTarget;
    const formData = new FormData(form);

    try {
      const response = await fetch("/api/order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: formData.get("name"),
          email: formData.get("email"),
          phone: formData.get("phone"),
          brokerOption: selectedOption,
          brokerOptionLabel: selectedPricing.label,
          price: selectedPricing.price,
          paymentMethod: paymentMethod,
          website: formData.get("website"), // Honeypot field
          turnstileToken,
          couponCode: couponState.status === "valid" ? couponState.code : undefined,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        if (paymentMethod === "stripe" && data.checkoutUrl) {
          // Redirect to Stripe checkout
          window.location.href = data.checkoutUrl;
        } else {
          // Bitcoin - show payment instructions
          setFormState({
            status: "success",
            message: "Order submitted successfully!",
            orderRef: data.orderRef,
            paymentMethod: "bitcoin",
          });
        }
      } else {
        setFormState({
          status: "error",
          message: data.error || "Something went wrong. Please try again.",
        });
      }
    } catch {
      setFormState({
        status: "error",
        message: "Failed to submit order. Please try again later.",
      });
    }
  }

  function copyBitcoinAddress() {
    navigator.clipboard.writeText(BITCOIN_ADDRESS);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  // Success state for Bitcoin - show payment instructions
  if (formState.status === "success" && formState.paymentMethod === "bitcoin") {
    return (
      <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-2">
            Order Submitted!
          </h3>
          <p className="text-gray-400">
            Thank you for your order. Please complete payment below.
          </p>
          {formState.orderRef && (
            <p className="text-sm text-gray-500 mt-2">
              Reference: {formState.orderRef}
            </p>
          )}
        </div>

        <div className="bg-navy-900 border border-navy-700 rounded-xl p-6 mb-6">
          <h4 className="text-lg font-semibold text-white mb-4">
            Payment Details
          </h4>

          <div className="space-y-4">
            <div className="flex justify-between items-center py-3 border-b border-navy-700">
              <span className="text-gray-400">Product</span>
              <span className="text-white font-medium">RPM Forex Gold Bot</span>
            </div>
            <div className="flex justify-between items-center py-3 border-b border-navy-700">
              <span className="text-gray-400">Option</span>
              <span className="text-white font-medium">
                {selectedPricing.label}
              </span>
            </div>
            <div className="flex justify-between items-center py-3">
              <span className="text-gray-400">Total</span>
              <span className="text-2xl font-bold text-gold-500">
                {fmt(selectedPricing.price)}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-gold-500/10 border border-gold-500/20 rounded-xl p-6">
          <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <svg
              className="w-5 h-5 text-gold-500"
              viewBox="0 0 24 24"
              fill="currentColor"
            >
              <path d="M23.638 14.904c-1.602 6.43-8.113 10.34-14.542 8.736C2.67 22.05-1.244 15.525.362 9.105 1.962 2.67 8.475-1.243 14.9.358c6.43 1.605 10.342 8.115 8.738 14.548v-.002zm-6.35-4.613c.24-1.59-.974-2.45-2.64-3.03l.54-2.153-1.315-.33-.525 2.107c-.345-.087-.7-.168-1.053-.25l.53-2.12-1.32-.33-.54 2.16c-.285-.065-.565-.13-.84-.2l-1.815-.45-.35 1.4s.975.225.955.24c.535.136.63.486.615.77l-.62 2.48c.037.01.085.023.137.046l-.14-.035-.865 3.477c-.065.165-.23.41-.605.32.015.02-.96-.24-.96-.24l-.655 1.5 1.71.43.94.235-.54 2.19 1.32.33.54-2.17c.36.1.705.19 1.05.275l-.54 2.14 1.32.33.545-2.19c2.24.427 3.93.255 4.64-1.774.57-1.637-.03-2.58-1.217-3.196.854-.197 1.5-.757 1.67-1.917l-.002.003zm-2.99 4.19c-.405 1.637-3.16.753-4.05.532l.72-2.9c.896.225 3.757.67 3.33 2.37zm.41-4.212c-.37 1.49-2.66.733-3.405.548l.655-2.64c.745.186 3.14.534 2.75 2.084v.01z" />
            </svg>
            Pay with Bitcoin
          </h4>

          <p className="text-gray-400 text-sm mb-4">
            Send the exact amount to the Bitcoin address below. Your order will
            be processed once payment is confirmed.
          </p>

          <div className="bg-navy-900 rounded-lg p-4 mb-4">
            <p className="text-xs text-gray-500 mb-2">Bitcoin Address</p>
            <div className="flex items-center gap-2">
              <code className="text-white text-sm break-all flex-1 font-mono">
                {BITCOIN_ADDRESS}
              </code>
              <button
                onClick={copyBitcoinAddress}
                className="p-2 bg-navy-800 hover:bg-navy-700 rounded-lg transition-colors flex-shrink-0"
                title="Copy address"
              >
                {copied ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <Copy className="w-5 h-5 text-gray-400" />
                )}
              </button>
            </div>
          </div>

          <p className="text-gray-500 text-xs">
            After payment, you&apos;ll receive your Bot file and licence key via
            email within 24 hours. Check your confirmation email for details.
          </p>
        </div>

        <div className="mt-6 text-center">
          <button
            onClick={() => setFormState({ status: "idle", message: "" })}
            className="text-gold-500 hover:text-gold-400 text-sm font-medium"
          >
            Submit another order
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-8">
      <h2 className="text-2xl font-bold text-white mb-6">Order RPM Gold Bot</h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Honeypot field - hidden from humans, visible to bots */}
        <div className="absolute -left-[9999px] opacity-0 h-0 w-0 overflow-hidden" aria-hidden="true">
          <label htmlFor="website">Website</label>
          <input
            type="text"
            id="website"
            name="website"
            tabIndex={-1}
            autoComplete="off"
          />
        </div>

        {/* Broker Option Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-3">
            Bot Broker Option *
          </label>
          <div className="space-y-3">
            {(Object.entries(pricingOptions) as [BrokerOption, typeof pricingOptions["our-brokers"]][]).map(
              ([key, option]) => (
                <label
                  key={key}
                  className={`block cursor-pointer rounded-xl border-2 p-4 transition-all ${
                    selectedOption === key
                      ? "border-gold-500 bg-gold-500/5"
                      : "border-navy-700 hover:border-navy-600"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="brokerOption"
                        value={key}
                        checked={selectedOption === key}
                        onChange={() => setSelectedOption(key)}
                        className="w-4 h-4 text-gold-500 bg-navy-900 border-navy-700 focus:ring-gold-500 focus:ring-offset-navy-900"
                      />
                      <div>
                        <span className="text-white font-medium">
                          {option.label}
                        </span>
                        <p className="text-gray-500 text-sm">
                          {option.description}
                        </p>
                      </div>
                    </div>
                    <span className="text-gold-500 font-bold">
                      {fmt(option.price)}
                    </span>
                  </div>
                </label>
              )
            )}
          </div>
        </div>

        {/* Contact Details */}
        <div>
          <label
            htmlFor="name"
            className="block text-sm font-medium text-gray-300 mb-2"
          >
            Full Name *
          </label>
          <input
            type="text"
            id="name"
            name="name"
            required
            className="w-full px-4 py-3 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent transition-colors"
            placeholder="Your full name"
          />
        </div>

        <div>
          <label
            htmlFor="email"
            className="block text-sm font-medium text-gray-300 mb-2"
          >
            Email Address *
          </label>
          <input
            type="email"
            id="email"
            name="email"
            required
            className="w-full px-4 py-3 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent transition-colors"
            placeholder="your@email.com"
          />
        </div>

        <div>
          <label
            htmlFor="phone"
            className="block text-sm font-medium text-gray-300 mb-2"
          >
            Phone Number (optional)
          </label>
          <input
            type="tel"
            id="phone"
            name="phone"
            className="w-full px-4 py-3 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent transition-colors"
            placeholder="Your phone number"
          />
        </div>

        {/* Payment Method Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-3">
            Payment Method *
          </label>
          <div className="grid grid-cols-2 gap-3">
            <label
              className={`cursor-pointer rounded-xl border-2 p-4 transition-all text-center ${
                paymentMethod === "stripe"
                  ? "border-gold-500 bg-gold-500/5"
                  : "border-navy-700 hover:border-navy-600"
              }`}
            >
              <input
                type="radio"
                name="paymentMethod"
                value="stripe"
                checked={paymentMethod === "stripe"}
                onChange={() => setPaymentMethod("stripe")}
                className="sr-only"
              />
              <CreditCard className="w-6 h-6 mx-auto mb-2 text-gold-500" />
              <span className="text-white font-medium block">Card Payment</span>
              <span className="text-gray-500 text-xs">Visa, Mastercard, etc</span>
            </label>

            <label
              className={`cursor-pointer rounded-xl border-2 p-4 transition-all text-center ${
                paymentMethod === "bitcoin"
                  ? "border-gold-500 bg-gold-500/5"
                  : "border-navy-700 hover:border-navy-600"
              }`}
            >
              <input
                type="radio"
                name="paymentMethod"
                value="bitcoin"
                checked={paymentMethod === "bitcoin"}
                onChange={() => setPaymentMethod("bitcoin")}
                className="sr-only"
              />
              <svg
                className="w-6 h-6 mx-auto mb-2 text-gold-500"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d="M23.638 14.904c-1.602 6.43-8.113 10.34-14.542 8.736C2.67 22.05-1.244 15.525.362 9.105 1.962 2.67 8.475-1.243 14.9.358c6.43 1.605 10.342 8.115 8.738 14.548v-.002zm-6.35-4.613c.24-1.59-.974-2.45-2.64-3.03l.54-2.153-1.315-.33-.525 2.107c-.345-.087-.7-.168-1.053-.25l.53-2.12-1.32-.33-.54 2.16c-.285-.065-.565-.13-.84-.2l-1.815-.45-.35 1.4s.975.225.955.24c.535.136.63.486.615.77l-.62 2.48c.037.01.085.023.137.046l-.14-.035-.865 3.477c-.065.165-.23.41-.605.32.015.02-.96-.24-.96-.24l-.655 1.5 1.71.43.94.235-.54 2.19 1.32.33.54-2.17c.36.1.705.19 1.05.275l-.54 2.14 1.32.33.545-2.19c2.24.427 3.93.255 4.64-1.774.57-1.637-.03-2.58-1.217-3.196.854-.197 1.5-.757 1.67-1.917l-.002.003zm-2.99 4.19c-.405 1.637-3.16.753-4.05.532l.72-2.9c.896.225 3.757.67 3.33 2.37zm.41-4.212c-.37 1.49-2.66.733-3.405.548l.655-2.64c.745.186 3.14.534 2.75 2.084v.01z" />
              </svg>
              <span className="text-white font-medium block">Bitcoin</span>
              <span className="text-gray-500 text-xs">Pay with crypto</span>
            </label>
          </div>
        </div>

        {/* Coupon Code */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Coupon Code (optional)
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={couponCode}
              onChange={(e) => {
                setCouponCode(e.target.value.toUpperCase());
                if (couponState.status !== "idle") setCouponState({ status: "idle" });
              }}
              placeholder="Enter code"
              disabled={couponState.status === "valid"}
              className="flex-1 px-4 py-3 bg-navy-900 border border-navy-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent transition-colors uppercase font-mono disabled:opacity-60"
            />
            {couponState.status === "valid" ? (
              <button
                type="button"
                onClick={() => {
                  setCouponCode("");
                  setCouponState({ status: "idle" });
                }}
                className="px-4 py-3 bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors text-sm font-medium"
              >
                Remove
              </button>
            ) : (
              <button
                type="button"
                onClick={() => validateCoupon(couponCode, selectedOption)}
                disabled={!couponCode.trim() || couponState.status === "validating"}
                className="px-6 py-3 bg-navy-700 hover:bg-navy-600 text-white rounded-lg font-medium transition-colors disabled:opacity-50 text-sm"
              >
                {couponState.status === "validating" ? "..." : "Apply"}
              </button>
            )}
          </div>
          {couponState.status === "valid" && (
            <p className="text-green-400 text-sm mt-2 flex items-center gap-1">
              <Tag className="w-3 h-3" />
              {couponState.message}
              {typeof couponState.discountAmount === "number" &&
                ` You save ${fmt(couponState.discountAmount)}`}
            </p>
          )}
          {couponState.status === "invalid" && (
            <p className="text-red-400 text-sm mt-2">{couponState.message}</p>
          )}
        </div>

        {/* Order Summary */}
        <div className="bg-navy-900 rounded-xl p-4 border border-navy-700">
          {couponState.status === "valid" && couponState.discountAmount ? (
            <div className="space-y-2">
              <div className="flex justify-between items-center text-gray-400">
                <span>Subtotal</span>
                <span className="line-through">{fmt(selectedPricing.price)}</span>
              </div>
              <div className="flex justify-between items-center text-green-400">
                <span>Discount ({couponState.code})</span>
                <span>-{fmt(couponState.discountAmount)}</span>
              </div>
              <div className="border-t border-navy-700 pt-2 flex justify-between items-center">
                <span className="text-gray-400">Total</span>
                <span className="text-2xl font-bold text-white">
                  {fmt(couponState.finalPrice!)}
                </span>
              </div>
            </div>
          ) : (
            <>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Total</span>
                <span className="text-2xl font-bold text-white">
                  {fmt(selectedPricing.price)}
                </span>
              </div>
            </>
          )}
        </div>

        {formState.status === "error" && (
          <div className="flex items-center gap-2 text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg p-4">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p className="text-sm">{formState.message}</p>
          </div>
        )}

        {/* Terms and Conditions */}
        <label className="flex items-start gap-3 cursor-pointer">
          <input
            type="checkbox"
            checked={acceptedTerms}
            onChange={(e) => setAcceptedTerms(e.target.checked)}
            className="mt-1 w-4 h-4 text-gold-500 bg-navy-900 border-navy-700 rounded focus:ring-gold-500 focus:ring-offset-navy-900"
          />
          <span className="text-sm text-gray-400">
            I agree to the{" "}
            <a
              href="/terms"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gold-500 hover:text-gold-400 underline"
            >
              Terms & Conditions
            </a>{" "}
            and{" "}
            <a
              href="/privacy"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gold-500 hover:text-gold-400 underline"
            >
              Privacy Policy
            </a>
          </span>
        </label>

        {process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY && (
          <div className="flex justify-center">
            <Turnstile
              ref={turnstileRef}
              siteKey={process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY}
              onSuccess={setTurnstileToken}
              onError={() => setTurnstileToken(null)}
              onExpire={() => setTurnstileToken(null)}
              options={{
                theme: "dark",
                size: "invisible",
              }}
            />
          </div>
        )}

        <Button
          type="submit"
          size="lg"
          className="w-full"
          disabled={formState.status === "loading" || !acceptedTerms || (!turnstileToken && !!process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY)}
        >
          {formState.status === "loading" ? (
            "Processing..."
          ) : paymentMethod === "stripe" ? (
            <>
              <CreditCard className="mr-2 w-5 h-5" />
              Pay {fmt(couponState.status === "valid" && couponState.finalPrice ? couponState.finalPrice : selectedPricing.price)}
            </>
          ) : (
            <>
              <ShoppingCart className="mr-2 w-5 h-5" />
              Place Order
            </>
          )}
        </Button>

        <p className="text-gray-500 text-xs text-center">
          {paymentMethod === "stripe"
            ? "You'll be redirected to our secure payment page powered by Stripe."
            : "Bitcoin payment instructions will be shown after submission."}
        </p>
      </form>
    </div>
  );
}
