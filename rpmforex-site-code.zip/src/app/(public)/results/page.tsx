import { Metadata } from "next";
import Image from "next/image";
import { Section } from "@/components/Section";
import { Button } from "@/components/Button";
import { ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "RPM Forex Performance Results",
  description:
    "View RPM Forex performance results. Fully transparent performance tracking.",
  keywords: [
    "RPM Forex performance",
    "forex trading",
    "gold trading",
    "trading bot",
    "automated trading",
    "XAUUSD",
    "expert advisor",
    "RPM Forex",
  ],
};

export default function ResultsPage() {
  return (
    <>
      {/* Hero */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-navy-900/50 to-navy-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              View <span className="text-gold-500">2025</span> Results Here
            </h1>
            <p className="text-xl text-gray-300">
              Full transparency is at the core of RPM Forex. See our verified
              performance below.
            </p>
            <div className="pt-8">
              <Button
                href="https://www.myfxbook.com/members/RPM_TRADING_EA/mt4-63376039-rpm-forex-gold/11988160"
                size="lg"
              >
                View Latest Live Results Here on MyFXBook
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Results Images */}
      <Section>
        <div className="space-y-8">
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-4 md:p-6">
            <Image
              src="/images/results-portfolio.jpeg"
              alt="RPM Forex Portfolio Performance 2025"
              width={1200}
              height={600}
              className="w-full rounded-lg"
            />
          </div>
          <div className="bg-navy-800/50 border border-navy-700 rounded-2xl p-4 md:p-6">
            <Image
              src="/images/results-monthly.jpeg"
              alt="RPM Forex Monthly Gains 2025"
              width={1200}
              height={600}
              className="w-full rounded-lg"
            />
          </div>
        </div>
      </Section>

      {/* Risk Disclaimer */}
      <Section className="bg-navy-900/50">
        <div className="bg-navy-800/50 border border-navy-700 rounded-xl p-6 md:p-8">
          <h3 className="text-xl font-semibold text-white mb-4">
            Important Disclaimer
          </h3>
          <p className="text-gray-400 text-sm leading-relaxed">
            Trading foreign exchange on margin carries a high level of risk and
            may not be suitable for all investors. Past performance is not
            indicative of future results. The high degree of leverage can work
            against you as well as for you. Before deciding to trade foreign
            exchange, you should carefully consider your investment objectives,
            level of experience, and risk appetite. The possibility exists that
            you could sustain a loss of some or all of your initial investment
            and therefore you should not invest money that you cannot afford to
            lose.
          </p>
        </div>
      </Section>

      {/* CTA */}
      <Section>
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Impressed by the Results?
          </h2>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
            Get in touch to learn how RPM Forex can help you achieve similar
            results with our automated gold trading system.
          </p>
          <Button href="/contact" size="lg">
            Get Started <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </Section>
    </>
  );
}
