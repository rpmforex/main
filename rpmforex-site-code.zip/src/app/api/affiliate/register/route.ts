import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";
import { prisma } from "@/lib/prisma";
import { createAffiliate } from "@/lib/affiliate-auth";
import {
  affiliateApplicationReceivedEmail,
  adminNewAffiliateEmail,
} from "@/lib/email-templates";
import { checkRateLimit, getClientIp, rateLimitHeaders } from "@/lib/rate-limit";

interface RegisterData {
  name: string;
  email: string;
  password: string;
  paymentEmail?: string;
  paymentMethod?: string;
}

export async function POST(request: NextRequest) {
  try {
    const ip = getClientIp(request.headers);
    const rl = await checkRateLimit(`affiliate_register:${ip}`, {
      windowMs: 60 * 60 * 1000,
      max: 5,
    });
    if (!rl.ok) {
      return NextResponse.json(
        { error: "Too many registrations. Please try again later." },
        { status: 429, headers: rateLimitHeaders(rl) }
      );
    }

    const body: RegisterData = await request.json();
    const { name, email, password, paymentEmail, paymentMethod } = body;

    // Validate required fields
    if (!name || !email || !password) {
      return NextResponse.json(
        { error: "Name, email, and password are required" },
        { status: 400 }
      );
    }

    if (password.length < 8) {
      return NextResponse.json(
        { error: "Password must be at least 8 characters" },
        { status: 400 }
      );
    }

    // Check if email already exists
    const existing = await prisma.affiliate.findUnique({
      where: { email },
    });

    if (existing) {
      return NextResponse.json(
        { error: "An account with this email already exists" },
        { status: 400 }
      );
    }

    // Create affiliate
    const affiliate = await createAffiliate(
      email,
      password,
      name,
      paymentEmail,
      paymentMethod
    );

    // Send emails
    if (process.env.RESEND_API_KEY) {
      const resend = new Resend(process.env.RESEND_API_KEY);

      try {
        await Promise.all([
          // Confirmation to applicant
          resend.emails.send({
            from: "RPM Forex <noreply@rpmforex.com>",
            to: [email],
            replyTo: process.env.CONTACT_EMAIL || "info@rpmforex.com",
            subject: "Affiliate Application Received - RPM Forex",
            html: affiliateApplicationReceivedEmail({ name, email }),
          }),
          // Alert to admin
          resend.emails.send({
            from: "RPM Forex <noreply@rpmforex.com>",
            to: [process.env.CONTACT_EMAIL || "info@rpmforex.com"],
            subject: `New Affiliate Application: ${name}`,
            html: adminNewAffiliateEmail({
              name,
              email,
              paymentEmail,
              paymentMethod,
            }),
          }),
        ]);
      } catch (error) {
        console.error("Failed to send affiliate registration emails:", error);
      }
    }

    return NextResponse.json({
      success: true,
      message:
        "Application submitted successfully! We'll review it and get back to you within 24-48 hours.",
      referralCode: affiliate.referralCode,
    });
  } catch (error) {
    console.error("Affiliate registration error:", error);
    return NextResponse.json(
      { error: "An unexpected error occurred" },
      { status: 500 }
    );
  }
}
