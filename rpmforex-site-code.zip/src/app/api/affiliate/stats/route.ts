import { NextResponse } from "next/server";
import { getAffiliateSession } from "@/lib/affiliate-auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const affiliate = await getAffiliateSession();

    if (!affiliate) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    // Get recent conversions (last 30 days)
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    const recentConversions = await prisma.referral.count({
      where: {
        affiliateId: affiliate.id,
        converted: true,
        convertedAt: { gte: thirtyDaysAgo },
      },
    });

    // Get recent clicks (last 30 days)
    const recentClicks = await prisma.referral.count({
      where: {
        affiliateId: affiliate.id,
        createdAt: { gte: thirtyDaysAgo },
      },
    });

    // Calculate conversion rate
    const conversionRate =
      recentClicks > 0
        ? ((recentConversions / recentClicks) * 100).toFixed(1)
        : "0.0";

    // Get earnings this month
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);

    const monthlyEarnings = await prisma.referral.aggregate({
      where: {
        affiliateId: affiliate.id,
        converted: true,
        convertedAt: { gte: startOfMonth },
      },
      _sum: { commission: true },
    });

    return NextResponse.json({
      stats: {
        totalClicks: affiliate.totalClicks,
        totalOrders: affiliate.totalOrders,
        totalEarnings: Number(affiliate.totalEarnings),
        pendingEarnings: Number(affiliate.pendingEarnings),
        paidEarnings: Number(affiliate.paidEarnings),
        commissionRate: Number(affiliate.commissionRate),
        recentClicks,
        recentConversions,
        conversionRate,
        monthlyEarnings: Number(monthlyEarnings._sum.commission || 0),
      },
    });
  } catch (error) {
    console.error("Get affiliate stats error:", error);
    return NextResponse.json(
      { error: "An unexpected error occurred" },
      { status: 500 }
    );
  }
}
