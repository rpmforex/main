import { NextRequest, NextResponse } from "next/server";
import { trackReferralClick } from "@/lib/referral-tracking";
import { checkRateLimit, getClientIp, rateLimitHeaders } from "@/lib/rate-limit";

export async function POST(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get("code")?.trim().toUpperCase();
    const page = searchParams.get("page");

    if (!code) {
      return NextResponse.json({ error: "No code provided" }, { status: 400 });
    }

    if (!/^[A-Z0-9]{8}$/.test(code)) {
      return NextResponse.json({ error: "Invalid code" }, { status: 400 });
    }

    const ip = getClientIp(request.headers);
    const rl = await checkRateLimit(`affiliate_track_click:${ip}:${code}`, {
      windowMs: 10 * 60 * 1000,
      max: 120,
    });
    if (!rl.ok) {
      return NextResponse.json(
        { error: "Too many requests. Please try again later." },
        { status: 429, headers: rateLimitHeaders(rl) }
      );
    }

    // Use x-client-ip (set by our middleware) or fall back to platform headers
    const ipAddress =
      request.headers.get("x-client-ip") ||
      request.headers.get("x-real-ip") ||
      request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      undefined;

    const userAgent = request.headers.get("user-agent") || undefined;

    const safePage =
      page && page.startsWith("/") && page.length <= 256 ? page : undefined;

    await trackReferralClick(code, ipAddress, userAgent, safePage);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Track click error:", error);
    return NextResponse.json(
      { error: "An unexpected error occurred" },
      { status: 500 }
    );
  }
}
