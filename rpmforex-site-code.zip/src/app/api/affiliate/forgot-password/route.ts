import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";
import { createPasswordResetToken } from "@/lib/affiliate-auth";
import { affiliatePasswordResetEmail } from "@/lib/email-templates";
import { checkRateLimit, getClientIp, rateLimitHeaders } from "@/lib/rate-limit";

// Same generic response whether or not the email exists — prevents
// account enumeration via this endpoint.
const GENERIC_RESPONSE = {
  success: true,
  message:
    "If an account exists with that email, a password reset link has been sent.",
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const email = typeof body.email === "string" ? body.email.trim() : "";

    const ip = getClientIp(request.headers);
    const rl = await checkRateLimit(`affiliate_forgot_password:${ip}`, {
      windowMs: 60 * 60 * 1000,
      max: 5,
    });
    if (!rl.ok) {
      return NextResponse.json(
        { error: "Too many requests. Please try again later." },
        { status: 429, headers: rateLimitHeaders(rl) }
      );
    }

    if (!email) {
      return NextResponse.json(
        { error: "Email is required" },
        { status: 400 }
      );
    }

    const result = await createPasswordResetToken(email);

    // Only send the email if the account actually exists — but always
    // return the same response either way.
    if (result && process.env.RESEND_API_KEY) {
      const baseUrl =
        process.env.NEXT_PUBLIC_BASE_URL ||
        (process.env.NODE_ENV === "development"
          ? "http://localhost:3000"
          : "https://rpmforex.com");

      const resetUrl = `${baseUrl}/affiliate/reset-password?token=${result.token}`;

      try {
        const resend = new Resend(process.env.RESEND_API_KEY);
        await resend.emails.send({
          from: "RPM Forex <noreply@rpmforex.com>",
          to: [result.affiliate.email],
          replyTo: process.env.CONTACT_EMAIL || "info@rpmforex.com",
          subject: "Reset Your Password - RPM Forex Affiliates",
          html: affiliatePasswordResetEmail({
            name: result.affiliate.name,
            resetUrl,
          }),
        });
      } catch (error) {
        console.error("Failed to send password reset email:", error);
      }
    }

    return NextResponse.json(GENERIC_RESPONSE);
  } catch (error) {
    console.error("Affiliate forgot-password error:", error);
    return NextResponse.json(
      { error: "An unexpected error occurred" },
      { status: 500 }
    );
  }
}
