import { NextResponse } from "next/server";
import { getAffiliateSession } from "@/lib/affiliate-auth";

export async function GET() {
  try {
    const affiliate = await getAffiliateSession();

    if (!affiliate) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    return NextResponse.json({
      affiliate: {
        id: affiliate.id,
        email: affiliate.email,
        name: affiliate.name,
        referralCode: affiliate.referralCode,
        commissionRate: Number(affiliate.commissionRate),
        totalClicks: affiliate.totalClicks,
        totalOrders: affiliate.totalOrders,
        totalEarnings: Number(affiliate.totalEarnings),
        pendingEarnings: Number(affiliate.pendingEarnings),
        paidEarnings: Number(affiliate.paidEarnings),
      },
    });
  } catch (error) {
    console.error("Get affiliate error:", error);
    return NextResponse.json(
      { error: "An unexpected error occurred" },
      { status: 500 }
    );
  }
}
