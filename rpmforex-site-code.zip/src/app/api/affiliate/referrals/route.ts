import { NextRequest, NextResponse } from "next/server";
import { getAffiliateSession } from "@/lib/affiliate-auth";
import { prisma } from "@/lib/prisma";

export async function GET(request: NextRequest) {
  try {
    const affiliate = await getAffiliateSession();

    if (!affiliate) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");
    const filter = searchParams.get("filter") || "all"; // all, converted, pending

    const skip = (page - 1) * limit;

    // Build filter conditions
    const where: {
      affiliateId: string;
      converted?: boolean;
    } = {
      affiliateId: affiliate.id,
    };

    if (filter === "converted") {
      where.converted = true;
    } else if (filter === "pending") {
      where.converted = false;
    }

    // Get referrals with order info
    const [referrals, total] = await Promise.all([
      prisma.referral.findMany({
        where,
        include: {
          order: {
            select: {
              orderRef: true,
              price: true,
              createdAt: true,
            },
          },
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
      }),
      prisma.referral.count({ where }),
    ]);

    return NextResponse.json({
      referrals: referrals.map((r: typeof referrals[number]) => ({
        id: r.id,
        createdAt: r.createdAt,
        converted: r.converted,
        convertedAt: r.convertedAt,
        commission: r.commission ? Number(r.commission) : null,
        landingPage: r.landingPage,
        order: r.order
          ? {
              orderRef: r.order.orderRef,
              price: Number(r.order.price),
              createdAt: r.order.createdAt,
            }
          : null,
      })),
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error("Get affiliate referrals error:", error);
    return NextResponse.json(
      { error: "An unexpected error occurred" },
      { status: 500 }
    );
  }
}
