import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import {
  affiliateApprovedEmail,
  affiliateRejectedEmail,
} from "@/lib/email-templates";

export async function GET(request: NextRequest) {
  const auth = await requirePermission("affiliates");
  if (!auth.authorized) return auth.response;

  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");
  const page = parseInt(searchParams.get("page") || "1");
  const limit = parseInt(searchParams.get("limit") || "20");

  const skip = (page - 1) * limit;

  const where = status
    ? { status: status as "PENDING" | "APPROVED" | "REJECTED" | "SUSPENDED" }
    : {};

  const [affiliates, total] = await Promise.all([
    prisma.affiliate.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip,
      take: limit,
      select: {
        id: true,
        email: true,
        name: true,
        referralCode: true,
        status: true,
        commissionRate: true,
        totalClicks: true,
        totalOrders: true,
        totalEarnings: true,
        pendingEarnings: true,
        paidEarnings: true,
        createdAt: true,
      },
    }),
    prisma.affiliate.count({ where }),
  ]);

  return NextResponse.json({
    affiliates: affiliates.map((a: typeof affiliates[number]) => ({
      ...a,
      commissionRate: Number(a.commissionRate),
      totalEarnings: Number(a.totalEarnings),
      pendingEarnings: Number(a.pendingEarnings),
      paidEarnings: Number(a.paidEarnings),
    })),
    pagination: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit),
    },
  });
}

export async function PATCH(request: NextRequest) {
  const auth = await requirePermission("affiliates");
  if (!auth.authorized) return auth.response;

  const { id, action, commissionRate } = await request.json();

  if (!id) {
    return NextResponse.json(
      { error: "Affiliate ID required" },
      { status: 400 }
    );
  }

  const affiliate = await prisma.affiliate.findUnique({
    where: { id },
  });

  if (!affiliate) {
    return NextResponse.json({ error: "Affiliate not found" }, { status: 404 });
  }

  // Handle different actions
  if (action === "approve") {
    await prisma.affiliate.update({
      where: { id },
      data: { status: "APPROVED" },
    });

    // Send approval email
    if (process.env.RESEND_API_KEY) {
      const resend = new Resend(process.env.RESEND_API_KEY);
      try {
        await resend.emails.send({
          from: "RPM Forex <noreply@rpmforex.com>",
          to: [affiliate.email],
          replyTo: process.env.CONTACT_EMAIL || "info@rpmforex.com",
          subject: "Your Affiliate Application Has Been Approved!",
          html: affiliateApprovedEmail({
            name: affiliate.name,
            email: affiliate.email,
            referralCode: affiliate.referralCode,
          }),
        });
      } catch (err) {
        console.error("Failed to send approval email:", err);
      }
    }

    return NextResponse.json({ success: true, message: "Affiliate approved" });
  }

  if (action === "reject") {
    await prisma.affiliate.update({
      where: { id },
      data: { status: "REJECTED" },
    });

    // Send rejection email
    if (process.env.RESEND_API_KEY) {
      const resend = new Resend(process.env.RESEND_API_KEY);
      try {
        await resend.emails.send({
          from: "RPM Forex <noreply@rpmforex.com>",
          to: [affiliate.email],
          replyTo: process.env.CONTACT_EMAIL || "info@rpmforex.com",
          subject: "Affiliate Application Update",
          html: affiliateRejectedEmail({
            name: affiliate.name,
            email: affiliate.email,
          }),
        });
      } catch (err) {
        console.error("Failed to send rejection email:", err);
      }
    }

    return NextResponse.json({ success: true, message: "Affiliate rejected" });
  }

  if (action === "suspend") {
    await prisma.affiliate.update({
      where: { id },
      data: { status: "SUSPENDED" },
    });
    return NextResponse.json({ success: true, message: "Affiliate suspended" });
  }

  if (action === "reactivate") {
    await prisma.affiliate.update({
      where: { id },
      data: { status: "APPROVED" },
    });
    return NextResponse.json({
      success: true,
      message: "Affiliate reactivated",
    });
  }

  if (action === "updateCommission" && commissionRate !== undefined) {
    await prisma.affiliate.update({
      where: { id },
      data: { commissionRate },
    });
    return NextResponse.json({
      success: true,
      message: "Commission rate updated",
    });
  }

  return NextResponse.json({ error: "Invalid action" }, { status: 400 });
}
