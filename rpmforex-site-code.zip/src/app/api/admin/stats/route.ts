import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requirePermission } from "@/lib/auth";

export async function GET() {
  const auth = await requirePermission("stats");
  if (!auth.authorized) return auth.response;

  const [
    totalOrders,
    pendingPayments,
    paidOrders,
    totalRevenue,
    unreadContacts,
  ] = await Promise.all([
    prisma.order.count(),
    prisma.order.count({ where: { paymentStatus: "PENDING" } }),
    prisma.order.count({ where: { paymentStatus: "PAID" } }),
    prisma.order.aggregate({
      where: { paymentStatus: "PAID" },
      _sum: { price: true },
    }),
    prisma.contactSubmission.count({ where: { read: false } }),
  ]);

  return NextResponse.json({
    totalOrders,
    pendingPayments,
    paidOrders,
    totalRevenue: totalRevenue._sum.price || 0,
    unreadContacts,
  });
}
