import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import {
  generateSlug,
  ensureUniqueSlug,
  calculateReadingTime,
  sanitizeContent,
  generateExcerpt,
} from "@/lib/blog";

export async function GET(request: NextRequest) {
  const auth = await requirePermission("blog");
  if (!auth.authorized) return auth.response;

  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");

  const where = status ? { status: status as "DRAFT" | "PUBLISHED" | "ARCHIVED" } : {};

  const posts = await prisma.blogPost.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { category: { select: { id: true, name: true } } },
  });

  return NextResponse.json({ posts });
}

export async function POST(request: NextRequest) {
  const auth = await requirePermission("blog");
  if (!auth.authorized) return auth.response;

  const data = await request.json();

  if (!data.title?.trim()) {
    return NextResponse.json({ error: "Title is required" }, { status: 400 });
  }
  if (!data.content?.trim()) {
    return NextResponse.json({ error: "Content is required" }, { status: 400 });
  }

  const baseSlug = data.slug?.trim() ? generateSlug(data.slug) : generateSlug(data.title);
  const slug = await ensureUniqueSlug(prisma, baseSlug);
  const content = sanitizeContent(data.content);
  const readingTime = calculateReadingTime(content);
  const excerpt = data.excerpt?.trim() || generateExcerpt(content);

  let publishedAt = data.publishedAt ? new Date(data.publishedAt) : null;
  if (data.status === "PUBLISHED" && !publishedAt) {
    publishedAt = new Date();
  }

  const post = await prisma.blogPost.create({
    data: {
      title: data.title.trim(),
      slug,
      content,
      excerpt,
      featuredImage: data.featuredImage?.trim() || null,
      status: data.status || "DRAFT",
      publishedAt,
      categoryId: data.categoryId || null,
      metaTitle: data.metaTitle?.trim() || null,
      metaDescription: data.metaDescription?.trim() || null,
      ogImage: data.ogImage?.trim() || null,
      canonicalUrl: data.canonicalUrl?.trim() || null,
      readingTime,
    },
    include: { category: { select: { id: true, name: true } } },
  });

  revalidatePath("/blog");
  return NextResponse.json({ post });
}

export async function PATCH(request: NextRequest) {
  const auth = await requirePermission("blog");
  if (!auth.authorized) return auth.response;

  const data = await request.json();

  if (!data.id) return NextResponse.json({ error: "ID is required" }, { status: 400 });
  if (data.title !== undefined && !data.title?.trim()) {
    return NextResponse.json({ error: "Title cannot be empty" }, { status: 400 });
  }

  const updateData: Record<string, unknown> = {};

  if (data.title !== undefined) updateData.title = data.title.trim();

  if (data.slug !== undefined) {
    const baseSlug = generateSlug(data.slug);
    updateData.slug = await ensureUniqueSlug(prisma, baseSlug, data.id);
  }

  if (data.content !== undefined) {
    updateData.content = sanitizeContent(data.content);
    updateData.readingTime = calculateReadingTime(updateData.content as string);
    if (!data.excerpt?.trim()) {
      updateData.excerpt = generateExcerpt(updateData.content as string);
    }
  }

  if (data.excerpt !== undefined) updateData.excerpt = data.excerpt.trim() || null;
  if (data.featuredImage !== undefined) updateData.featuredImage = data.featuredImage.trim() || null;
  if (data.status !== undefined) updateData.status = data.status;
  if (data.categoryId !== undefined) updateData.categoryId = data.categoryId || null;
  if (data.metaTitle !== undefined) updateData.metaTitle = data.metaTitle.trim() || null;
  if (data.metaDescription !== undefined) updateData.metaDescription = data.metaDescription.trim() || null;
  if (data.ogImage !== undefined) updateData.ogImage = data.ogImage.trim() || null;
  if (data.canonicalUrl !== undefined) updateData.canonicalUrl = data.canonicalUrl.trim() || null;

  if (data.publishedAt !== undefined) {
    updateData.publishedAt = data.publishedAt ? new Date(data.publishedAt) : null;
  }

  // Auto-set publishedAt when transitioning to PUBLISHED
  if (data.status === "PUBLISHED" && !data.publishedAt) {
    const existing = await prisma.blogPost.findUnique({
      where: { id: data.id },
      select: { publishedAt: true },
    });
    if (!existing?.publishedAt) {
      updateData.publishedAt = new Date();
    }
  }

  const post = await prisma.blogPost.update({
    where: { id: data.id },
    data: updateData,
    include: { category: { select: { id: true, name: true } } },
  });

  revalidatePath("/blog");
  revalidatePath(`/blog/${post.slug}`);
  return NextResponse.json({ post });
}

export async function DELETE(request: NextRequest) {
  const auth = await requirePermission("blog");
  if (!auth.authorized) return auth.response;

  const { id } = await request.json();
  if (!id) return NextResponse.json({ error: "ID is required" }, { status: 400 });

  const post = await prisma.blogPost.findUnique({ where: { id }, select: { slug: true } });
  await prisma.blogPost.delete({ where: { id } });

  revalidatePath("/blog");
  if (post) revalidatePath(`/blog/${post.slug}`);
  return NextResponse.json({ success: true });
}
