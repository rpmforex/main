import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requirePermission } from "@/lib/auth";

export async function GET() {
  const auth = await requirePermission("contacts");
  if (!auth.authorized) return auth.response;

  const contacts = await prisma.contactSubmission.findMany({
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ contacts });
}

export async function PATCH(request: NextRequest) {
  const auth = await requirePermission("contacts");
  if (!auth.authorized) return auth.response;

  const { id, read } = await request.json();

  if (!id) {
    return NextResponse.json({ error: "ID required" }, { status: 400 });
  }

  const contact = await prisma.contactSubmission.update({
    where: { id },
    data: { read },
  });

  return NextResponse.json({ contact });
}

export async function DELETE(request: NextRequest) {
  const auth = await requirePermission("contacts");
  if (!auth.authorized) return auth.response;

  const { id } = await request.json();

  if (!id) {
    return NextResponse.json({ error: "ID required" }, { status: 400 });
  }

  await prisma.contactSubmission.delete({
    where: { id },
  });

  return NextResponse.json({ success: true });
}
