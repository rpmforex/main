import { NextRequest, NextResponse } from "next/server";
import { requirePermission } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { generateSlug } from "@/lib/blog";

export async function GET() {
  const auth = await requirePermission("blog-categories");
  if (!auth.authorized) return auth.response;

  const categories = await prisma.blogCategory.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { posts: true } } },
  });

  return NextResponse.json({ categories });
}

export async function POST(request: NextRequest) {
  const auth = await requirePermission("blog-categories");
  if (!auth.authorized) return auth.response;

  const { name, description } = await request.json();

  if (!name?.trim()) {
    return NextResponse.json({ error: "Name is required" }, { status: 400 });
  }

  const slug = generateSlug(name);

  const existing = await prisma.blogCategory.findUnique({ where: { slug } });
  if (existing) {
    return NextResponse.json({ error: "A category with this name already exists" }, { status: 400 });
  }

  const category = await prisma.blogCategory.create({
    data: { name: name.trim(), slug, description: description?.trim() || null },
  });

  return NextResponse.json({ category });
}

export async function PATCH(request: NextRequest) {
  const auth = await requirePermission("blog-categories");
  if (!auth.authorized) return auth.response;

  const { id, name, description } = await request.json();

  if (!id) return NextResponse.json({ error: "ID is required" }, { status: 400 });
  if (!name?.trim()) return NextResponse.json({ error: "Name is required" }, { status: 400 });

  const slug = generateSlug(name);

  const existing = await prisma.blogCategory.findUnique({ where: { slug } });
  if (existing && existing.id !== id) {
    return NextResponse.json({ error: "A category with this name already exists" }, { status: 400 });
  }

  const category = await prisma.blogCategory.update({
    where: { id },
    data: { name: name.trim(), slug, description: description?.trim() || null },
  });

  return NextResponse.json({ category });
}

export async function DELETE(request: NextRequest) {
  const auth = await requirePermission("blog-categories");
  if (!auth.authorized) return auth.response;

  const { id } = await request.json();
  if (!id) return NextResponse.json({ error: "ID is required" }, { status: 400 });

  const postCount = await prisma.blogPost.count({ where: { categoryId: id } });

  await prisma.blogCategory.delete({ where: { id } });

  return NextResponse.json({ success: true, uncategorizedPosts: postCount });
}
