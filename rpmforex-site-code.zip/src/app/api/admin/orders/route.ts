import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";
import { prisma } from "@/lib/prisma";
import { requirePermission } from "@/lib/auth";
import { convertReferral, reverseReferralConversion } from "@/lib/referral-tracking";
import { affiliateNewConversionEmail } from "@/lib/email-templates";

export async function GET(request: NextRequest) {
  const auth = await requirePermission("orders");
  if (!auth.authorized) return auth.response;

  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");
  const paymentStatus = searchParams.get("paymentStatus");

  const where: Record<string, unknown> = {};
  if (status) where.status = status;
  if (paymentStatus) where.paymentStatus = paymentStatus;

  const orders = await prisma.order.findMany({
    where,
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ orders });
}

export async function PATCH(request: NextRequest) {
  const auth = await requirePermission("orders");
  if (!auth.authorized) return auth.response;

  const { id, ...data } = await request.json();

  if (!id) {
    return NextResponse.json({ error: "Order ID required" }, { status: 400 });
  }

  // Get current order state
  const currentOrder = await prisma.order.findUnique({
    where: { id },
    include: { referral: true },
  });

  if (!currentOrder) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }

  // Handle status updates with timestamps
  const updateData: Record<string, unknown> = { ...data };

  if (data.paymentStatus === "PAID" && !data.paidAt) {
    updateData.paidAt = new Date();
    // If no paidAmount provided, default to original price
    if (!data.paidAmount && !currentOrder.paidAmount) {
      updateData.paidAmount = Number(currentOrder.price);
    }
  }
  if (data.status === "SHIPPED" && !data.shippedAt) {
    updateData.shippedAt = new Date();
  }
  if (data.status === "DELIVERED" && !data.deliveredAt) {
    updateData.deliveredAt = new Date();
  }

  const order = await prisma.order.update({
    where: { id },
    data: updateData,
  });

  // Handle affiliate commission on payment status change
  if (data.paymentStatus && data.paymentStatus !== currentOrder.paymentStatus) {
    // Payment marked as PAID - convert affiliate referral
    // Use paidAmount (actual received) for commission calculation
    if (data.paymentStatus === "PAID" && currentOrder.affiliateCode && !currentOrder.referral) {
      const orderAmount = order.paidAmount ? Number(order.paidAmount) : Number(order.price);
      const conversionResult = await convertReferral(
        order.id,
        orderAmount,
        currentOrder.affiliateCode
      );

      // Send affiliate notification
      if (conversionResult && process.env.RESEND_API_KEY) {
        const resend = new Resend(process.env.RESEND_API_KEY);
        try {
          await resend.emails.send({
            from: "RPM Forex <noreply@rpmforex.com>",
            to: [conversionResult.affiliate.email],
            replyTo: process.env.CONTACT_EMAIL || "info@rpmforex.com",
            subject: `New Referral Sale! - $${conversionResult.commission.toFixed(2)} Commission`,
            html: affiliateNewConversionEmail({
              affiliateName: conversionResult.affiliate.name,
              orderRef: order.orderRef,
              orderAmount: orderAmount,
              commission: conversionResult.commission,
              totalPending: Number(conversionResult.affiliate.pendingEarnings) + conversionResult.commission,
            }),
          });
        } catch (err) {
          console.error("Failed to send affiliate conversion email:", err);
        }
      }
    }

    // Payment marked as REFUNDED - reverse affiliate commission
    if (data.paymentStatus === "REFUNDED" && currentOrder.referral) {
      await reverseReferralConversion(order.id);
      console.log(`Reversed affiliate commission for order ${order.orderRef}`);
    }
  }

  return NextResponse.json({ order });
}

export async function DELETE(request: NextRequest) {
  const auth = await requirePermission("orders");
  if (!auth.authorized) return auth.response;

  const { id } = await request.json();

  if (!id) {
    return NextResponse.json({ error: "Order ID required" }, { status: 400 });
  }

  const order = await prisma.order.findUnique({ where: { id } });

  if (!order) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }

  if (order.paymentStatus !== "PENDING" || order.status !== "PENDING") {
    return NextResponse.json(
      { error: "Only pending orders can be deleted" },
      { status: 400 }
    );
  }

  await prisma.order.delete({ where: { id } });

  return NextResponse.json({ success: true });
}
