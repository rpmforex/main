import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requirePermission } from "@/lib/auth";

export async function GET() {
  const auth = await requirePermission("coupons");
  if (!auth.authorized) return auth.response;

  const coupons = await prisma.coupon.findMany({
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ coupons });
}

export async function POST(request: NextRequest) {
  const auth = await requirePermission("coupons");
  if (!auth.authorized) return auth.response;

  const body = await request.json();
  const { code, description, discountType, discountValue, maxUses, minOrderAmount, expiresAt } = body;

  if (!code || !discountType || discountValue === undefined) {
    return NextResponse.json({ error: "Code, discount type, and value are required" }, { status: 400 });
  }

  const normalizedCode = code.trim().toUpperCase();

  if (!/^[A-Z0-9\-]+$/.test(normalizedCode)) {
    return NextResponse.json({ error: "Code must be alphanumeric (hyphens allowed)" }, { status: 400 });
  }

  if (discountType !== "FIXED" && discountType !== "PERCENTAGE") {
    return NextResponse.json({ error: "Invalid discount type" }, { status: 400 });
  }

  const value = Number(discountValue);
  if (value <= 0) {
    return NextResponse.json({ error: "Discount value must be greater than 0" }, { status: 400 });
  }

  if (discountType === "PERCENTAGE" && value > 100) {
    return NextResponse.json({ error: "Percentage cannot exceed 100" }, { status: 400 });
  }

  // Check for duplicate code
  const existing = await prisma.coupon.findUnique({ where: { code: normalizedCode } });
  if (existing) {
    return NextResponse.json({ error: "A coupon with this code already exists" }, { status: 400 });
  }

  const coupon = await prisma.coupon.create({
    data: {
      code: normalizedCode,
      description: description || null,
      discountType,
      discountValue: value,
      maxUses: maxUses ? Number(maxUses) : null,
      minOrderAmount: minOrderAmount ? Number(minOrderAmount) : null,
      expiresAt: expiresAt ? new Date(expiresAt) : null,
    },
  });

  return NextResponse.json({ coupon });
}

export async function PATCH(request: NextRequest) {
  const auth = await requirePermission("coupons");
  if (!auth.authorized) return auth.response;

  const body = await request.json();
  const { id, ...updates } = body;

  if (!id) {
    return NextResponse.json({ error: "ID required" }, { status: 400 });
  }

  // Normalize code if provided
  if (updates.code) {
    updates.code = updates.code.trim().toUpperCase();
    if (!/^[A-Z0-9\-]+$/.test(updates.code)) {
      return NextResponse.json({ error: "Code must be alphanumeric (hyphens allowed)" }, { status: 400 });
    }
  }

  if (updates.discountType && updates.discountType !== "FIXED" && updates.discountType !== "PERCENTAGE") {
    return NextResponse.json({ error: "Invalid discount type" }, { status: 400 });
  }

  if (updates.discountValue !== undefined) {
    const value = Number(updates.discountValue);
    if (value <= 0) {
      return NextResponse.json({ error: "Discount value must be greater than 0" }, { status: 400 });
    }
    if (updates.discountType === "PERCENTAGE" && value > 100) {
      return NextResponse.json({ error: "Percentage cannot exceed 100" }, { status: 400 });
    }
    updates.discountValue = value;
  }

  // Convert optional fields
  if (updates.maxUses !== undefined) {
    updates.maxUses = updates.maxUses ? Number(updates.maxUses) : null;
  }
  if (updates.minOrderAmount !== undefined) {
    updates.minOrderAmount = updates.minOrderAmount ? Number(updates.minOrderAmount) : null;
  }
  if (updates.expiresAt !== undefined) {
    updates.expiresAt = updates.expiresAt ? new Date(updates.expiresAt) : null;
  }

  const coupon = await prisma.coupon.update({
    where: { id },
    data: updates,
  });

  return NextResponse.json({ coupon });
}

export async function DELETE(request: NextRequest) {
  const auth = await requirePermission("coupons");
  if (!auth.authorized) return auth.response;

  const { id } = await request.json();

  if (!id) {
    return NextResponse.json({ error: "ID required" }, { status: 400 });
  }

  await prisma.coupon.delete({ where: { id } });

  return NextResponse.json({ success: true });
}
