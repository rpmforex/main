import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requirePermission, hashPassword } from "@/lib/auth";

export async function GET() {
  const auth = await requirePermission("users");
  if (!auth.authorized) return auth.response;

  const users = await prisma.adminUser.findMany({
    select: { id: true, email: true, name: true, role: true, isActive: true, createdAt: true },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ users });
}

export async function POST(request: NextRequest) {
  const auth = await requirePermission("users");
  if (!auth.authorized) return auth.response;

  const body = await request.json();
  const { email, password, name, role } = body;

  if (!email || !password || !name) {
    return NextResponse.json({ error: "Name, email, and password are required" }, { status: 400 });
  }

  if (password.length < 8) {
    return NextResponse.json({ error: "Password must be at least 8 characters" }, { status: 400 });
  }

  if (!["SUPER_ADMIN", "BLOG_MANAGER"].includes(role)) {
    return NextResponse.json({ error: "Invalid role" }, { status: 400 });
  }

  const existing = await prisma.adminUser.findUnique({ where: { email: email.toLowerCase() } });
  if (existing) {
    return NextResponse.json({ error: "A user with this email already exists" }, { status: 400 });
  }

  const hashedPassword = await hashPassword(password);
  const user = await prisma.adminUser.create({
    data: { email: email.toLowerCase(), password: hashedPassword, name, role },
    select: { id: true, email: true, name: true, role: true, isActive: true, createdAt: true },
  });

  return NextResponse.json({ user });
}

export async function PATCH(request: NextRequest) {
  const auth = await requirePermission("users");
  if (!auth.authorized) return auth.response;

  const body = await request.json();
  const { id, email, name, role, isActive, password } = body;

  if (!id) {
    return NextResponse.json({ error: "User ID is required" }, { status: 400 });
  }

  // Prevent self-modification of role/active status
  if (id === auth.session.id) {
    if (role && role !== auth.session.role) {
      return NextResponse.json({ error: "You cannot change your own role" }, { status: 400 });
    }
    if (isActive === false) {
      return NextResponse.json({ error: "You cannot deactivate yourself" }, { status: 400 });
    }
  }

  // If demoting a SUPER_ADMIN, ensure at least one active SUPER_ADMIN remains
  if (role && role !== "SUPER_ADMIN") {
    const target = await prisma.adminUser.findUnique({ where: { id } });
    if (target?.role === "SUPER_ADMIN") {
      const superAdminCount = await prisma.adminUser.count({
        where: { role: "SUPER_ADMIN", isActive: true, id: { not: id } },
      });
      if (superAdminCount === 0) {
        return NextResponse.json({ error: "Cannot demote the last Super Admin" }, { status: 400 });
      }
    }
  }

  // Check email uniqueness if changing
  if (email) {
    const existing = await prisma.adminUser.findFirst({
      where: { email: email.toLowerCase(), id: { not: id } },
    });
    if (existing) {
      return NextResponse.json({ error: "A user with this email already exists" }, { status: 400 });
    }
  }

  const updateData: Record<string, unknown> = {};
  if (name) updateData.name = name;
  if (email) updateData.email = email.toLowerCase();
  if (role) updateData.role = role;
  if (typeof isActive === "boolean") updateData.isActive = isActive;
  if (password) {
    if (password.length < 8) {
      return NextResponse.json({ error: "Password must be at least 8 characters" }, { status: 400 });
    }
    updateData.password = await hashPassword(password);
  }

  const user = await prisma.adminUser.update({
    where: { id },
    data: updateData,
    select: { id: true, email: true, name: true, role: true, isActive: true, createdAt: true },
  });

  return NextResponse.json({ user });
}

export async function DELETE(request: NextRequest) {
  const auth = await requirePermission("users");
  if (!auth.authorized) return auth.response;

  const { id } = await request.json();

  if (!id) {
    return NextResponse.json({ error: "User ID is required" }, { status: 400 });
  }

  if (id === auth.session.id) {
    return NextResponse.json({ error: "You cannot delete yourself" }, { status: 400 });
  }

  // Ensure at least one active SUPER_ADMIN remains
  const target = await prisma.adminUser.findUnique({ where: { id } });
  if (target?.role === "SUPER_ADMIN") {
    const superAdminCount = await prisma.adminUser.count({
      where: { role: "SUPER_ADMIN", isActive: true, id: { not: id } },
    });
    if (superAdminCount === 0) {
      return NextResponse.json({ error: "Cannot delete the last Super Admin" }, { status: 400 });
    }
  }

  await prisma.adminUser.delete({ where: { id } });
  return NextResponse.json({ success: true });
}
