import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { Resend } from "resend";
import { prisma } from "@/lib/prisma";
import { getStripe } from "@/lib/stripe";
import { validateForm } from "@/lib/spam-detection";
import { orderConfirmationEmail, adminNewOrderEmail } from "@/lib/email-templates";
import { checkRateLimit, getClientIp, rateLimitHeaders } from "@/lib/rate-limit";

interface OrderData {
  name: string;
  email: string;
  phone?: string;
  brokerOption: string;
  paymentMethod: "stripe" | "bitcoin";
  turnstileToken?: string;
  website?: string; // Honeypot field
  couponCode?: string;
}

// Server-side pricing - NEVER trust client-provided prices.
// Prices are USD-native (charged in USD). Keys are stable internal ids:
// "our-brokers" = Standard tier, "any-broker" = Pro tier.
const PRICING: Record<string, { label: string; price: number }> = {
  "our-brokers": { label: "RPM Gold — Standard", price: 497 },
  "any-broker": { label: "RPM Gold — Pro", price: 997 },
};

function generateOrderRef(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `RPM-${timestamp}-${random}`;
}

async function verifyTurnstile(token: string, remoteip?: string): Promise<boolean> {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) {
    // In production, fail closed if Turnstile is not configured
    if (process.env.NODE_ENV === "production") {
      console.error("Turnstile secret key not configured in production");
      return false;
    }
    console.warn("Turnstile secret key not configured (dev mode)");
    return true;
  }

  try {
    const response = await fetch(
      "https://challenges.cloudflare.com/turnstile/v0/siteverify",
      {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          secret,
          response: token,
          ...(remoteip ? { remoteip } : {}),
        }).toString(),
      }
    );
    const data = await response.json();
    return data.success;
  } catch (error) {
    console.error("Turnstile verification failed:", error);
    return false;
  }
}

export async function POST(request: NextRequest) {
  try {
    const ip = getClientIp(request.headers);
    const rl = await checkRateLimit(`order:${ip}`, {
      windowMs: 15 * 60 * 1000,
      max: 10,
    });
    if (!rl.ok) {
      return NextResponse.json(
        { error: "Too many requests. Please try again later." },
        { status: 429, headers: rateLimitHeaders(rl) }
      );
    }

    const body: OrderData = await request.json();
    const { name, email, phone, brokerOption, paymentMethod, turnstileToken, website, couponCode } = body;

    // Validate required fields
    if (!name || !email || !brokerOption || !paymentMethod) {
      return NextResponse.json(
        { error: "Please fill in all required fields" },
        { status: 400 }
      );
    }

    // Validate broker option and get SERVER-SIDE pricing (never trust client price)
    const pricing = PRICING[brokerOption];
    if (!pricing) {
      return NextResponse.json(
        { error: "Invalid broker option selected" },
        { status: 400 }
      );
    }
    const price = pricing.price;
    const brokerOptionLabel = pricing.label;

    // Run comprehensive spam and validation checks
    const validation = validateForm({
      name,
      email,
      phone,
      honeypot: website, // Hidden honeypot field
    });

    // Check for validation errors
    if (Object.keys(validation.errors).length > 0) {
      const firstError = Object.values(validation.errors)[0];
      return NextResponse.json(
        { error: firstError },
        { status: 400 }
      );
    }

    // Block spam submissions for orders (don't silently accept like contact form)
    if (validation.isSpam) {
      console.warn("Spam order detected:", {
        name,
        email,
        score: validation.spamScore,
        reasons: validation.spamReasons,
      });
      return NextResponse.json(
        { error: "Unable to process your order. Please contact us directly." },
        { status: 400 }
      );
    }

    // Require Turnstile verification when configured
    if (process.env.TURNSTILE_SECRET_KEY || process.env.NODE_ENV === "production") {
      if (!turnstileToken) {
        return NextResponse.json(
          { error: "Security verification required. Please complete the captcha." },
          { status: 400 }
        );
      }
      const remoteip = request.headers
        .get("x-forwarded-for")
        ?.split(",")[0]
        ?.trim();
      const isValid = await verifyTurnstile(turnstileToken, remoteip);
      if (!isValid) {
        return NextResponse.json(
          { error: "Security verification failed. Please try again." },
          { status: 400 }
        );
      }
    }

    const orderRef = generateOrderRef();

    // Check for affiliate referral cookie
    const cookieStore = await cookies();
    const affiliateCookieValue = cookieStore.get("rpm_affiliate")?.value?.trim().toUpperCase();
    const affiliateCode =
      affiliateCookieValue && /^[A-Z0-9]{8}$/.test(affiliateCookieValue)
        ? affiliateCookieValue
        : null;

    // Validate and apply coupon if provided
    let discountAmount = 0;
    let validatedCouponCode: string | null = null;

    if (couponCode && typeof couponCode === "string") {
      const coupon = await prisma.coupon.findUnique({
        where: { code: couponCode.trim().toUpperCase() },
      });

      if (coupon && coupon.active) {
        const notExpired = !coupon.expiresAt || coupon.expiresAt > new Date();
        const notMaxed = coupon.maxUses === null || coupon.usedCount < coupon.maxUses;
        const meetsMinimum = !coupon.minOrderAmount || price >= Number(coupon.minOrderAmount);

        if (notExpired && notMaxed && meetsMinimum) {
          if (coupon.discountType === "FIXED") {
            discountAmount = Number(coupon.discountValue);
          } else {
            discountAmount = Math.round((price * Number(coupon.discountValue)) / 100 * 100) / 100;
          }
          // Cap discount - ensure final price is at least $0.50
          discountAmount = Math.min(discountAmount, price - 0.5);
          discountAmount = Math.max(0, discountAmount);
          validatedCouponCode = coupon.code;

          // Increment usage count atomically
          await prisma.coupon.update({
            where: { id: coupon.id },
            data: { usedCount: { increment: 1 } },
          });
        }
      }
    }

    const finalPrice = price - discountAmount;

    // Create order in database
    const order = await prisma.order.create({
      data: {
        orderRef,
        name,
        email,
        phone: phone || null,
        brokerOption,
        brokerLabel: brokerOptionLabel,
        price,
        paidAmount: finalPrice,
        discountCode: validatedCouponCode,
        discountAmount: discountAmount > 0 ? discountAmount : null,
        paymentMethod: paymentMethod === "stripe" ? "STRIPE" : "BITCOIN",
        paymentStatus: "PENDING",
        status: "PENDING",
        affiliateCode: affiliateCode || null,
      },
    });

    // If Stripe payment, create checkout session
    if (paymentMethod === "stripe") {
      if (!process.env.STRIPE_SECRET_KEY) {
        return NextResponse.json(
          { error: "Payment system not configured" },
          { status: 500 }
        );
      }

      // Only use allowlisted base URL - never trust request origin
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || (process.env.NODE_ENV === "development" ? "http://localhost:3000" : null);
      if (!baseUrl) {
        console.error("NEXT_PUBLIC_BASE_URL not configured in production");
        return NextResponse.json(
          { error: "Payment system configuration error" },
          { status: 500 }
        );
      }

      const session = await getStripe().checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: "RPM Forex Gold Bot",
                description: validatedCouponCode
                  ? `${brokerOptionLabel} (Coupon: ${validatedCouponCode})`
                  : brokerOptionLabel,
              },
              unit_amount: Math.round(finalPrice * 100),
            },
            quantity: 1,
          },
        ],
        mode: "payment",
        success_url: `${baseUrl}/buy/success?session_id={CHECKOUT_SESSION_ID}&order=${orderRef}`,
        cancel_url: `${baseUrl}/buy?cancelled=true`,
        customer_email: email,
        metadata: {
          orderId: order.id,
          orderRef: orderRef,
          customerName: name,
          affiliateCode: affiliateCode || "",
          couponCode: validatedCouponCode || "",
        },
        payment_intent_data: {
          metadata: {
            orderId: order.id,
            orderRef: orderRef,
            customerName: name,
            affiliateCode: affiliateCode || "",
            couponCode: validatedCouponCode || "",
          },
        },
      });

      // Update order with Stripe session ID
      await prisma.order.update({
        where: { id: order.id },
        data: { stripeSessionId: session.id },
      });

      return NextResponse.json({
        success: true,
        orderRef,
        checkoutUrl: session.url,
      });
    }

    // Bitcoin payment - send confirmation emails
    // Note: Affiliate conversion happens when admin marks payment as received
    await sendOrderEmails(order, "bitcoin", affiliateCode);

    return NextResponse.json({
      success: true,
      orderRef,
      message: "Order submitted successfully",
    });
  } catch (error) {
    console.error("Order submission error:", error);
    return NextResponse.json(
      { error: "An unexpected error occurred" },
      { status: 500 }
    );
  }
}

async function sendOrderEmails(
  order: {
    orderRef: string;
    name: string;
    email: string;
    phone: string | null;
    brokerLabel: string;
    price: unknown;
    paidAmount: unknown;
    discountCode: string | null;
    discountAmount: unknown;
  },
  paymentType: "bitcoin" | "stripe",
  affiliateCode?: string | null
) {
  if (!process.env.RESEND_API_KEY) {
    console.log("Resend not configured, skipping emails");
    return;
  }

  const resend = new Resend(process.env.RESEND_API_KEY);
  const priceNum = Number(order.price);
  const paidAmountNum = order.paidAmount ? Number(order.paidAmount) : null;
  const discountAmountNum = order.discountAmount ? Number(order.discountAmount) : null;

  const emailData = {
    orderRef: order.orderRef,
    customerName: order.name,
    email: order.email,
    phone: order.phone,
    product: "RPM Forex Gold Bot",
    option: order.brokerLabel,
    price: priceNum,
    paidAmount: paidAmountNum,
    discountCode: order.discountCode,
    discountAmount: discountAmountNum,
    paymentMethod: paymentType,
    affiliateCode: affiliateCode || undefined,
  };

  try {
    await Promise.all([
      resend.emails.send({
        from: "RPM Forex <noreply@rpmforex.com>",
        to: [process.env.CONTACT_EMAIL || "info@rpmforex.com"],
        subject: `New Bot Order: ${order.orderRef} - $${priceNum.toFixed(2)} (${paymentType === "bitcoin" ? "Bitcoin" : "Stripe"})`,
        html: adminNewOrderEmail(emailData),
      }),
      resend.emails.send({
        from: "RPM Forex <noreply@rpmforex.com>",
        to: [order.email],
        replyTo: process.env.CONTACT_EMAIL || "info@rpmforex.com",
        subject: `Your RPM Forex Order Confirmation - ${order.orderRef}`,
        html: orderConfirmationEmail(emailData),
      }),
    ]);
  } catch (error) {
    console.error("Failed to send order emails:", error);
  }
}
