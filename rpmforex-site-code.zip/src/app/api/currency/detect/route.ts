import { NextRequest, NextResponse } from "next/server";
import { getCurrencyFromCountry, getExchangeRates } from "@/lib/currency";

export const runtime = "edge";

/**
 * Detect the visitor's currency from Vercel geolocation headers and
 * return it together with the current (daily-cached) exchange rates.
 */
export async function GET(request: NextRequest) {
  // Vercel sets this header at the edge; absent locally -> defaults to GBP
  const country = request.headers.get("x-vercel-ip-country") || undefined;

  const currency = getCurrencyFromCountry(country);
  const rates = await getExchangeRates();

  return NextResponse.json({
    currency,
    country,
    rates,
  });
}
