import { NextRequest, NextResponse } from "next/server";
import { getStripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import { Resend } from "resend";
import Stripe from "stripe";
import {
  paymentConfirmedEmail,
  adminPaymentReceivedEmail,
  affiliateNewConversionEmail,
} from "@/lib/email-templates";
import { convertReferral } from "@/lib/referral-tracking";

export async function POST(request: NextRequest) {
  const body = await request.text();
  const signature = request.headers.get("stripe-signature");

  if (!signature) {
    return NextResponse.json({ error: "Missing signature" }, { status: 400 });
  }

  let event: Stripe.Event;

  try {
    event = getStripe().webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    console.error("Webhook signature verification failed:", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;

    const orderId = session.metadata?.orderId;
    const orderRef = session.metadata?.orderRef;
    const affiliateCode = session.metadata?.affiliateCode;

    if (orderId) {
      // Get receipt URL from the payment intent's charge
      let receiptUrl: string | null = null;
      const paymentIntentId = session.payment_intent as string;

      if (paymentIntentId) {
        try {
          const paymentIntent = await getStripe().paymentIntents.retrieve(paymentIntentId, {
            expand: ['latest_charge'],
          });
          const charge = paymentIntent.latest_charge as Stripe.Charge;
          receiptUrl = charge?.receipt_url || null;
        } catch (err) {
          console.error("Failed to fetch receipt URL:", err);
        }
      }

      // Get actual paid amount from Stripe as verification
      const stripePaidAmount = session.amount_total ? session.amount_total / 100 : null;

      // Update order payment status
      // Discount fields (discountCode, discountAmount, paidAmount) are already set at order creation
      // Only update them from Stripe if they weren't set server-side (fallback for legacy orders)
      const existingOrder = await prisma.order.findUnique({ where: { id: orderId } });
      const order = await prisma.order.update({
        where: { id: orderId },
        data: {
          paymentStatus: "PAID",
          stripePaymentId: paymentIntentId,
          stripeReceiptUrl: receiptUrl,
          paidAt: new Date(),
          // Only set paidAmount from Stripe if not already set by server-side coupon
          ...(existingOrder && !existingOrder.paidAmount && stripePaidAmount
            ? { paidAmount: stripePaidAmount }
            : {}),
        },
      });

      // Handle affiliate conversion if applicable
      // Use paid amount (after discount) for commission calculation
      if (affiliateCode) {
        const orderAmount = order.paidAmount ? Number(order.paidAmount) : Number(order.price);
        const conversionResult = await convertReferral(
          orderId,
          orderAmount,
          affiliateCode
        );

        // Send affiliate conversion notification
        if (conversionResult && process.env.RESEND_API_KEY) {
          const resend = new Resend(process.env.RESEND_API_KEY);
          try {
            await resend.emails.send({
              from: "RPM Forex <noreply@rpmforex.com>",
              to: [conversionResult.affiliate.email],
              replyTo: process.env.CONTACT_EMAIL || "info@rpmforex.com",
              subject: `New Referral Sale! - $${conversionResult.commission.toFixed(2)} Commission`,
              html: affiliateNewConversionEmail({
                affiliateName: conversionResult.affiliate.name,
                orderRef: order.orderRef,
                orderAmount: orderAmount,
                commission: conversionResult.commission,
                totalPending: Number(conversionResult.affiliate.pendingEarnings) + conversionResult.commission,
              }),
            });
          } catch (err) {
            console.error("Failed to send affiliate conversion email:", err);
          }
        }
      }

      // Send confirmation emails
      await sendPaymentConfirmationEmails(order, receiptUrl);

      console.log(`Order ${orderRef} marked as paid via Stripe`);
    }
  }

  return NextResponse.json({ received: true });
}

async function sendPaymentConfirmationEmails(order: {
  orderRef: string;
  name: string;
  email: string;
  brokerLabel: string;
  price: unknown;
  paidAmount: unknown;
  discountCode: string | null;
  discountAmount: unknown;
}, receiptUrl: string | null) {
  if (!process.env.RESEND_API_KEY) return;

  const resend = new Resend(process.env.RESEND_API_KEY);
  const priceNum = Number(order.price);
  const paidAmountNum = order.paidAmount ? Number(order.paidAmount) : null;
  const discountAmountNum = order.discountAmount ? Number(order.discountAmount) : null;

  const emailData = {
    orderRef: order.orderRef,
    customerName: order.name,
    email: order.email,
    product: "RPM Forex Gold Bot",
    option: order.brokerLabel,
    price: priceNum,
    paidAmount: paidAmountNum,
    discountCode: order.discountCode,
    discountAmount: discountAmountNum,
    paymentMethod: "stripe" as const,
    receiptUrl,
  };

  try {
    await Promise.all([
      resend.emails.send({
        from: "RPM Forex <noreply@rpmforex.com>",
        to: [order.email],
        replyTo: process.env.CONTACT_EMAIL || "info@rpmforex.com",
        subject: `Payment Confirmed - ${order.orderRef}`,
        html: paymentConfirmedEmail(emailData),
      }),
      resend.emails.send({
        from: "RPM Forex <noreply@rpmforex.com>",
        to: [process.env.CONTACT_EMAIL || "info@rpmforex.com"],
        subject: `💰 Payment Received: ${order.orderRef} - $${(paidAmountNum ?? priceNum).toFixed(2)}`,
        html: adminPaymentReceivedEmail(emailData),
      }),
    ]);
  } catch (error) {
    console.error("Failed to send payment confirmation emails:", error);
  }
}
