import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";
import { prisma } from "@/lib/prisma";
import { validateForm } from "@/lib/spam-detection";
import { contactConfirmationEmail, adminContactEmail } from "@/lib/email-templates";
import { checkRateLimit, getClientIp, rateLimitHeaders } from "@/lib/rate-limit";

interface ContactFormData {
  name: string;
  email: string;
  phone?: string;
  message: string;
  turnstileToken?: string;
  website?: string; // Honeypot field
}

async function verifyTurnstile(token: string, remoteip?: string): Promise<boolean> {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) {
    // In production, fail closed if Turnstile is not configured
    if (process.env.NODE_ENV === "production") {
      console.error("Turnstile secret key not configured in production");
      return false;
    }
    console.warn("Turnstile secret key not configured (dev mode)");
    return true;
  }

  try {
    const response = await fetch(
      "https://challenges.cloudflare.com/turnstile/v0/siteverify",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          secret,
          response: token,
          ...(remoteip ? { remoteip } : {}),
        }).toString(),
      }
    );

    const data = await response.json();
    return data.success;
  } catch (error) {
    console.error("Turnstile verification failed:", error);
    return false;
  }
}

export async function POST(request: NextRequest) {
  try {
    const ip = getClientIp(request.headers);
    const rl = await checkRateLimit(`contact:${ip}`, {
      windowMs: 10 * 60 * 1000,
      max: 10,
    });
    if (!rl.ok) {
      return NextResponse.json(
        { error: "Too many requests. Please try again later." },
        { status: 429, headers: rateLimitHeaders(rl) }
      );
    }

    const body: ContactFormData = await request.json();
    const { name, email, phone, message, turnstileToken, website } = body;

    // Validate required fields
    if (!name || !email || !message) {
      return NextResponse.json(
        { error: "Please fill in all required fields" },
        { status: 400 }
      );
    }

    // Run comprehensive spam and validation checks
    const validation = validateForm({
      name,
      email,
      phone,
      message,
      honeypot: website, // Hidden honeypot field
    });

    // Check for validation errors
    if (Object.keys(validation.errors).length > 0) {
      const firstError = Object.values(validation.errors)[0];
      return NextResponse.json(
        { error: firstError },
        { status: 400 }
      );
    }

    // Check if flagged as spam
    if (validation.isSpam) {
      console.warn("Spam detected:", {
        name,
        email,
        score: validation.spamScore,
        reasons: validation.spamReasons,
      });
      // Return success to not tip off spammers, but don't process
      return NextResponse.json(
        { success: true, message: "Message sent successfully" },
        { status: 200 }
      );
    }

    // Require Turnstile verification when configured
    if (process.env.TURNSTILE_SECRET_KEY || process.env.NODE_ENV === "production") {
      if (!turnstileToken) {
        return NextResponse.json(
          { error: "Security verification required. Please complete the captcha." },
          { status: 400 }
        );
      }
      const remoteip = request.headers
        .get("x-forwarded-for")
        ?.split(",")[0]
        ?.trim();
      const isValid = await verifyTurnstile(turnstileToken, remoteip);
      if (!isValid) {
        return NextResponse.json(
          { error: "Security verification failed. Please try again." },
          { status: 400 }
        );
      }
    }

    // Save to database
    await prisma.contactSubmission.create({
      data: {
        name,
        email,
        phone: phone || null,
        message,
      },
    });

    // Send emails via Resend (if configured)
    if (process.env.RESEND_API_KEY) {
      const resend = new Resend(process.env.RESEND_API_KEY);

      try {
        await Promise.all([
          // Admin notification
          resend.emails.send({
            from: "RPM Forex <noreply@rpmforex.com>",
            to: [process.env.CONTACT_EMAIL || "info@rpmforex.com"],
            replyTo: email,
            subject: `New Contact Form Submission from ${name}`,
            html: adminContactEmail({ name, email, phone, message }),
          }),
          // Customer confirmation
          resend.emails.send({
            from: "RPM Forex <noreply@rpmforex.com>",
            to: [email],
            replyTo: process.env.CONTACT_EMAIL || "info@rpmforex.com",
            subject: `We've received your message - RPM Forex`,
            html: contactConfirmationEmail(name),
          }),
        ]);
      } catch (error) {
        console.error("Failed to send contact emails:", error);
      }
    }

    return NextResponse.json(
      { success: true, message: "Message sent successfully" },
      { status: 200 }
    );
  } catch (error) {
    console.error("Contact form error:", error);
    return NextResponse.json(
      { error: "An unexpected error occurred" },
      { status: 500 }
    );
  }
}
