import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { checkRateLimit, getClientIp, rateLimitHeaders } from "@/lib/rate-limit";

// USD-native prices. Keys are stable internal ids:
// "our-brokers" = Standard tier, "any-broker" = Pro tier.
const PRICING: Record<string, number> = {
  "our-brokers": 497,
  "any-broker": 997,
};

export async function POST(request: NextRequest) {
  const ip = getClientIp(request.headers);
  const rl = await checkRateLimit(`coupon:${ip}`, {
    windowMs: 15 * 60 * 1000,
    max: 30,
  });
  if (!rl.ok) {
    return NextResponse.json(
      { error: "Too many requests. Please try again later." },
      { status: 429, headers: rateLimitHeaders(rl) }
    );
  }

  const { code, brokerOption } = await request.json();

  if (!code || typeof code !== "string") {
    return NextResponse.json({ valid: false, error: "Coupon code required" });
  }

  const orderPrice = PRICING[brokerOption];
  if (!orderPrice) {
    return NextResponse.json({ valid: false, error: "Invalid broker option" });
  }

  const coupon = await prisma.coupon.findUnique({
    where: { code: code.trim().toUpperCase() },
  });

  if (!coupon) {
    return NextResponse.json({ valid: false, error: "Invalid coupon code" });
  }

  if (!coupon.active) {
    return NextResponse.json({ valid: false, error: "This coupon is no longer active" });
  }

  if (coupon.expiresAt && coupon.expiresAt < new Date()) {
    return NextResponse.json({ valid: false, error: "This coupon has expired" });
  }

  if (coupon.maxUses !== null && coupon.usedCount >= coupon.maxUses) {
    return NextResponse.json({ valid: false, error: "This coupon has reached its usage limit" });
  }

  if (coupon.minOrderAmount && orderPrice < Number(coupon.minOrderAmount)) {
    return NextResponse.json({
      valid: false,
      error: `This coupon requires a minimum order of $${Number(coupon.minOrderAmount).toFixed(2)}`,
    });
  }

  // Calculate discount
  let discountAmount: number;
  if (coupon.discountType === "FIXED") {
    discountAmount = Number(coupon.discountValue);
  } else {
    discountAmount = Math.round((orderPrice * Number(coupon.discountValue)) / 100 * 100) / 100;
  }

  // Cap discount - ensure final price is at least $0.50 (Stripe minimum)
  discountAmount = Math.min(discountAmount, orderPrice - 0.5);
  discountAmount = Math.max(0, discountAmount);
  const finalPrice = orderPrice - discountAmount;

  return NextResponse.json({
    valid: true,
    code: coupon.code,
    discountType: coupon.discountType,
    discountValue: Number(coupon.discountValue),
    discountAmount,
    originalPrice: orderPrice,
    finalPrice,
  });
}
