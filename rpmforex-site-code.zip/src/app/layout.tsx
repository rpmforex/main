import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { GoogleAnalytics } from "@next/third-parties/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://rpmforex.com"),
  title: {
    default: "RPM Forex | Automated Gold Trading Bot",
    template: "%s | RPM Forex",
  },
  description:
    "Professional automated gold trading with verified results. 140%+ gains with controlled risk. Join RPM Forex today.",
  keywords: [
    "automated gold trading bot",
    "forex trading",
    "gold trading",
    "trading bot",
    "XAUUSD",
    "expert advisor",
    "RPM Forex",
  ],
  authors: [{ name: "RPM Forex" }],
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
  },
  manifest: "/site.webmanifest",
  openGraph: {
    type: "website",
    locale: "en_GB",
    url: "https://rpmforex.com",
    siteName: "RPM Forex",
    title: "RPM Forex | Automated Gold Trading Bot",
    description:
      "Professional automated gold trading with verified results. 140%+ gains with controlled risk.",
    images: [
      {
        url: "/images/rpm-gold2.jpeg",
        width: 1200,
        height: 630,
        alt: "RPM Forex Gold Bot",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "RPM Forex | Automated Gold Trading Bot",
    description:
      "Professional automated gold trading with verified results. 140%+ gains with controlled risk.",
    images: ["/images/rpm-gold2.jpeg"],
  },
  robots: {
    index: true,
    follow: true,
  },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": "https://rpmforex.com/#organization",
      name: "RPM Forex",
      url: "https://rpmforex.com",
      logo: {
        "@type": "ImageObject",
        url: "https://rpmforex.com/images/rpm-forex-logo.jpeg",
      },
      contactPoint: {
        "@type": "ContactPoint",
        email: "info@rpmforex.com",
        contactType: "customer service",
      },
      sameAs: [],
    },
    {
      "@type": "WebSite",
      "@id": "https://rpmforex.com/#website",
      url: "https://rpmforex.com",
      name: "RPM Forex",
      publisher: {
        "@id": "https://rpmforex.com/#organization",
      },
    },
    {
      "@type": "SoftwareApplication",
      name: "RPM Forex Gold Bot",
      description:
        "Professional automated gold trading Expert Advisor for MetaTrader 4 with verified 140%+ returns.",
      applicationCategory: "FinanceApplication",
      operatingSystem: "Windows",
      offers: {
        "@type": "Offer",
        price: "497.00",
        priceCurrency: "USD",
        availability: "https://schema.org/InStock",
      },
      aggregateRating: {
        "@type": "AggregateRating",
        ratingValue: "4.8",
        ratingCount: "50",
      },
    },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body className={`${inter.variable} antialiased`}>
        {children}
      </body>
      <GoogleAnalytics gaId="G-7QQ131Z420" />
    </html>
  );
}
