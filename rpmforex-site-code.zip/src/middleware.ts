import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

const AFFILIATE_COOKIE_NAME = "rpm_affiliate";
const COOKIE_DURATION_DAYS = 30;

// Validate referral code format: 8 uppercase alphanumeric characters
function isValidReferralCode(code: string): boolean {
  return /^[A-Z0-9]{8}$/.test(code);
}

export function middleware(request: NextRequest) {
  const response = NextResponse.next();
  const { searchParams } = request.nextUrl;

  // Check for referral code in URL
  const refCode = searchParams.get("ref")?.trim().toUpperCase();

  // Validate referral code format before accepting
  if (refCode && isValidReferralCode(refCode)) {
    // Set affiliate cookie (httpOnly since client JS doesn't need to read it)
    const maxAge = COOKIE_DURATION_DAYS * 24 * 60 * 60;

    response.cookies.set({
      name: AFFILIATE_COOKIE_NAME,
      value: refCode,
      maxAge,
      path: "/",
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
    });

    // Track the click via API (fire and forget)
    // Use x-real-ip (Vercel) with fallback to x-forwarded-for
    const trackUrl = new URL("/api/affiliate/track-click", request.url);
    trackUrl.searchParams.set("code", refCode);
    trackUrl.searchParams.set("page", request.nextUrl.pathname);

    const clientIp = request.headers.get("x-real-ip")
      || request.headers.get("x-forwarded-for")?.split(",")[0]?.trim()
      || "";

    fetch(trackUrl.toString(), {
      method: "POST",
      headers: {
        "x-client-ip": clientIp,
        "user-agent": request.headers.get("user-agent") || "",
      },
    }).catch(() => {
      // Silently ignore tracking errors
    });
  }

  return response;
}

export const config = {
  matcher: [
    // Match all paths except API, static files, etc.
    "/((?!api|_next/static|_next/image|favicon.ico|images|.*\\.png$|.*\\.jpg$|.*\\.ico$).*)",
  ],
};
