# RPM Forex - Affiliate System & Email Notifications Plan

## Overview
Build a complete affiliate tracking system with comprehensive email notifications for all user interactions.

---

## 1. Database Schema

### New Models to Add to `prisma/schema.prisma`:

```prisma
// Affiliate accounts
model Affiliate {
  id              String   @id @default(cuid())
  email           String   @unique
  password        String
  name            String
  paymentEmail    String?  // PayPal/payment email
  paymentMethod   String?  // paypal, bank, crypto
  referralCode    String   @unique
  commissionRate  Decimal  @default(20) @db.Decimal(5, 2) // percentage
  status          AffiliateStatus @default(PENDING)

  // Stats (denormalized for performance)
  totalClicks     Int      @default(0)
  totalOrders     Int      @default(0)
  totalEarnings   Decimal  @default(0) @db.Decimal(10, 2)
  pendingEarnings Decimal  @default(0) @db.Decimal(10, 2)
  paidEarnings    Decimal  @default(0) @db.Decimal(10, 2)

  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  referrals       Referral[]
  payouts         Payout[]
}

// Track referral clicks and conversions
model Referral {
  id           String   @id @default(cuid())
  affiliateId  String
  affiliate    Affiliate @relation(fields: [affiliateId], references: [id])

  // Visitor info
  ipAddress    String?
  userAgent    String?
  landingPage  String?

  // Conversion
  orderId      String?  @unique
  order        Order?   @relation(fields: [orderId], references: [id])
  converted    Boolean  @default(false)
  commission   Decimal? @db.Decimal(10, 2)

  createdAt    DateTime @default(now())
  convertedAt  DateTime?
}

// Affiliate payouts
model Payout {
  id           String   @id @default(cuid())
  affiliateId  String
  affiliate    Affiliate @relation(fields: [affiliateId], references: [id])

  amount       Decimal  @db.Decimal(10, 2)
  method       String   // paypal, bank, crypto
  reference    String?  // transaction ID
  status       PayoutStatus @default(PENDING)
  notes        String?

  createdAt    DateTime @default(now())
  processedAt  DateTime?
}

enum AffiliateStatus {
  PENDING
  APPROVED
  REJECTED
  SUSPENDED
}

enum PayoutStatus {
  PENDING
  PROCESSING
  COMPLETED
  FAILED
}
```

### Update Order Model:
Add relation to Referral for tracking which orders came from affiliates.

---

## 2. Affiliate System Features

### 2.1 Public Pages
- `/affiliate` - Affiliate program landing/signup page
- `/affiliate/login` - Affiliate login
- `/affiliate/register` - Registration form
- `/affiliate/dashboard` - Stats, links, earnings (protected)
- `/affiliate/payouts` - Payout history (protected)

### 2.2 Referral Tracking Flow
1. Visitor clicks affiliate link: `rpmforex.com/?ref=ABC123`
2. Middleware detects `ref` param, sets cookie (30 days)
3. Cookie stored: `rpm_affiliate=ABC123`
4. On order creation, check for cookie
5. If found, create Referral record linked to order
6. Calculate commission based on affiliate's rate
7. Update affiliate stats

### 2.3 Affiliate Dashboard Features
- Unique referral link with copy button
- Stats: clicks, conversions, conversion rate
- Earnings: pending, paid, total
- Recent referrals table
- Payout request (optional)

### 2.4 Admin Features (`/admin/affiliates`)
- List all affiliates with stats
- Approve/reject pending affiliates
- View affiliate details and referrals
- Process payouts
- Adjust commission rates

---

## 3. Email Templates System

### 3.1 Create Reusable Email Template Component
Location: `src/lib/email-templates.ts`

Base template with RPM Forex branding:
- Dark navy background (#0a1628)
- Gold accents (#d4a84b)
- Consistent header/footer
- Responsive design

### 3.2 Email Types Needed

#### Customer Emails:
1. **Order Confirmation** (existing - enhance)
   - Order details, what's next
   - Receipt link for Stripe payments

2. **Payment Confirmed** (existing - enhance)
   - Thank you, payment received
   - Next steps for delivery

3. **Order Delivered**
   - EA file delivered
   - Setup instructions link
   - Support contact

4. **Contact Form Confirmation**
   - Thank you for reaching out
   - Expected response time

#### Admin Emails:
1. **New Order Alert**
   - Customer details
   - Order details
   - Payment status
   - Affiliate info (if referred)

2. **Payment Received Alert**
   - Quick summary
   - Action required

3. **New Contact Submission**
   - Message content
   - Reply link

4. **New Affiliate Application**
   - Applicant details
   - Approve/reject links

#### Affiliate Emails:
1. **Application Received**
   - Thank you, under review

2. **Application Approved**
   - Welcome, login link
   - Referral link
   - Getting started tips

3. **Application Rejected**
   - Sorry message
   - Contact for questions

4. **New Referral Conversion**
   - Order details
   - Commission earned
   - Current balance

5. **Payout Processed**
   - Amount sent
   - Method used
   - Transaction reference

---

## 4. Implementation Order

### Phase 1: Email Templates Foundation
- [ ] Create base email template component
- [ ] Create all email template functions
- [ ] Update existing order/contact emails to use new templates
- [ ] Test email rendering

### Phase 2: Database & Core
- [ ] Add Affiliate, Referral, Payout models to schema
- [ ] Add Referral relation to Order model
- [ ] Run Prisma migration
- [ ] Create affiliate auth library (JWT like admin)

### Phase 3: Affiliate Public Pages
- [ ] Create affiliate landing page
- [ ] Create affiliate registration page
- [ ] Create affiliate login page
- [ ] Create affiliate dashboard page
- [ ] Create affiliate payouts page

### Phase 4: Referral Tracking
- [ ] Create middleware for ref param detection
- [ ] Implement cookie setting/reading
- [ ] Update order creation to check for affiliate cookie
- [ ] Create referral record on order
- [ ] Calculate and store commission

### Phase 5: Admin Affiliate Management
- [ ] Create admin affiliates list page
- [ ] Create affiliate detail/edit page
- [ ] Create payout management page
- [ ] Add affiliate stats to admin dashboard

### Phase 6: Email Integration
- [ ] Wire up all affiliate emails
- [ ] Add affiliate info to order admin emails
- [ ] Test full flow

---

## 5. API Routes Needed

### Affiliate Auth:
- `POST /api/affiliate/register` - Create new affiliate application
- `POST /api/affiliate/login` - Affiliate login
- `POST /api/affiliate/logout` - Affiliate logout
- `GET /api/affiliate/me` - Get current affiliate

### Affiliate Dashboard:
- `GET /api/affiliate/stats` - Get affiliate stats
- `GET /api/affiliate/referrals` - Get referral history
- `GET /api/affiliate/payouts` - Get payout history
- `POST /api/affiliate/payout-request` - Request payout (optional)

### Admin:
- `GET /api/admin/affiliates` - List all affiliates
- `PATCH /api/admin/affiliates` - Update affiliate (approve/reject/suspend)
- `GET /api/admin/affiliates/[id]` - Get affiliate details
- `POST /api/admin/payouts` - Process payout
- `GET /api/admin/payouts` - List all payouts

---

## 6. File Structure

```
src/
├── app/
│   ├── (public)/
│   │   └── affiliate/
│   │       ├── page.tsx          # Landing/info page
│   │       ├── register/
│   │       │   └── page.tsx      # Registration form
│   │       ├── login/
│   │       │   └── page.tsx      # Login form
│   │       ├── dashboard/
│   │       │   └── page.tsx      # Dashboard (protected)
│   │       └── payouts/
│   │           └── page.tsx      # Payout history (protected)
│   │
│   ├── admin/
│   │   └── affiliates/
│   │       ├── page.tsx          # Affiliates list
│   │       ├── [id]/
│   │       │   └── page.tsx      # Affiliate detail
│   │       └── payouts/
│   │           └── page.tsx      # Manage payouts
│   │
│   └── api/
│       ├── affiliate/
│       │   ├── register/route.ts
│       │   ├── login/route.ts
│       │   ├── logout/route.ts
│       │   ├── me/route.ts
│       │   ├── stats/route.ts
│       │   ├── referrals/route.ts
│       │   └── payouts/route.ts
│       │
│       └── admin/
│           ├── affiliates/route.ts
│           └── payouts/route.ts
│
├── lib/
│   ├── email-templates.ts        # All email templates
│   ├── affiliate-auth.ts         # Affiliate JWT auth
│   └── referral-tracking.ts      # Cookie/tracking utils
│
└── middleware.ts                  # Ref param detection
```

---

## 7. Commission Structure

Default: **20% commission** on all referred sales

Example:
- Sale price: £495
- Commission: £99
- Sale price: £744
- Commission: £148.80

Admin can adjust per-affiliate rates.

---

## 8. Cookie Strategy

- Cookie name: `rpm_affiliate`
- Cookie value: Affiliate referral code
- Duration: 30 days
- HttpOnly: false (needs JS access for SPA)
- Secure: true (production)
- SameSite: Lax

---

## 9. Security Considerations

- Affiliate passwords hashed with bcrypt
- JWT tokens for affiliate auth (separate from admin)
- Rate limiting on registration
- Email verification (optional, can add later)
- IP logging for click fraud detection
- Duplicate click prevention (1 per IP per 24h)

---

## Notes

- Keep affiliate system separate from admin auth
- Affiliates cannot access admin panel
- All monetary values stored as Decimal
- Commission calculated at order time, not payout time
- Payouts are manual (admin processes them)
