# Post–Go‑Live Checklist (5–10 minutes)

Use this immediately after switching traffic to production.

## 1) Confirm The Deployment Is The One You Expect

- Check Vercel Deployment → **Production** points at the correct commit.
- Hit these pages in an incognito window:
  - `/`
  - `/buy`
  - `/contact`
  - `/affiliate`
  - `/admin/login` (should load, but not auto-login)

## 2) Verify Critical Env Vars Are Present (No Surprises)

In Vercel → Project → Settings → Environment Variables (Production):

- `DATABASE_URL`
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `RESEND_API_KEY` (if emails should send)
- `CONTACT_EMAIL`
- `TURNSTILE_SECRET_KEY` (captcha enforcement)
- `NEXT_PUBLIC_BASE_URL` (Stripe redirect base; must be your real domain)
- `ADMIN_JWT_SECRET`
- Rate limiting (shared store):
  - `KV_REST_API_URL`
  - `KV_REST_API_TOKEN`

## 3) Check Security Headers (CSP/HSTS/etc)

From your machine (replace `https://YOUR_DOMAIN`):

```bash
curl -sI https://YOUR_DOMAIN | rg -i "content-security-policy|strict-transport-security|x-content-type-options|x-frame-options|referrer-policy|permissions-policy"
```

Expected:
- `Content-Security-Policy` present (or `...Report-Only` if you set `CSP_REPORT_ONLY=true`).
- `Strict-Transport-Security` present on HTTPS in production.

## 4) Smoke Test Payments + Webhooks

### Stripe Checkout
- Place a test order via `/buy` → Stripe checkout → complete payment.
- Confirm:
  - You land on `/buy/success`.
  - The order is marked `PAID` in admin.

### Stripe Webhook Verification
- In Stripe Dashboard → Developers → Webhooks:
  - Check recent webhook deliveries are **200 OK**.
  - If failures: confirm `STRIPE_WEBHOOK_SECRET` and that the endpoint is correct.

## 5) Confirm Turnstile Is Enforced

- Submit `/contact` without completing Turnstile:
  - Expect a 400 with “Security verification required…”.
- Submit with Turnstile completed:
  - Expect success and the record saved.

## 6) Confirm Rate Limiting Is Working (Shared Store)

### Admin login brute-force should 429

```bash
for i in {1..20}; do
  curl -s -o /dev/null -w "%{http_code}\n" \
    -H "content-type: application/json" \
    -d '{"email":"test@example.com","password":"wrong"}' \
    https://YOUR_DOMAIN/api/admin/login
done
```

Expected: after a handful of attempts, you start seeing `429`.

If you never see `429`, double-check `KV_REST_API_URL` and `KV_REST_API_TOKEN` are set in **Production** and you redeployed.

## 7) Confirm Referral Tracking Is Sanitized

- Visit `/?ref=AAAAAAAA` and confirm it doesn’t error.
- Visit `/?ref=<script>` and confirm it does not set tracking (no error, no tracking).

## 8) Watch Logs For The First 30 Minutes

- Vercel → Logs:
  - Look for spikes in `429`, `400`, `401`, `500`.
  - Investigate repeated errors from:
    - Stripe webhook handler
    - Turnstile verification
    - Prisma/DB connectivity

## 9) Quick Rollback Plan

- Know the last-good production deployment in Vercel.
- If something breaks:
  - Revert production to last-good deployment.
  - Check webhook deliveries (Stripe) and rate limiting (KV).

